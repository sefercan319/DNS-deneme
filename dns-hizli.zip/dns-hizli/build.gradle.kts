// Sürümler burada tek yerde (Ekim 2026'da resmî belgelerden doğrulanan uyumlu üçlü):
//   AGP 8.13.2  -> en az Gradle 8.13, JDK 17, compileSdk 36'ya kadar; R8'i Kotlin 2.3'ü destekler
//   Kotlin 2.3.21 -> AGP 8.2.2–9.0.0, Gradle 7.6.3–9.3.0 ile resmen uyumlu
// Güncelleme için: https://developer.android.com/build/releases/about-agp
// (AGP 9'a geçiş "yerleşik Kotlin" göçü gerektirir; bkz. OKUBENI.md "Geliştirme önerileri".)
plugins {
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.3.21" apply false
}
