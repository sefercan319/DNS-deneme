#!/usr/bin/env python3
"""
Katalogdaki DNS sunucularını canlı olarak doğrular (yalnızca Python standart kütüphanesi).

  python3 tools/catalog_check.py            # tabloyu yazdırır; bir birincil adres yanıt vermezse çıkış kodu 1
  python3 tools/catalog_check.py --tries 5  # her adrese 5 sorgu

Her sunucu için birincil ve ikincil adrese gerçek bir UDP/53 sorgusu (A kaydı) gönderir; yanıtın kimliği tutuyorsa,
RCODE=0 ise ve en az bir cevap içeriyorsa "tamam" sayar. Düz DNS'e yanıt vermeyen sunucularda (katalogda
`plain = false`, ör. Mullvad) bu adım atlanır. Ayrıca DoT (TCP/853, TLS, sertifika adı denetimiyle) üzerinden de bir
sorgu gönderir (--dot-yok ile kapatılır). Gecikme, denemelerin ortancasıdır. Ayrıca katalogun kendi
tutarlılığını denetler: yinelenen kimlik/adres, geçersiz IPv4.

Katalog (app/src/main/java/app/dnshizli/core/Catalog.kt) değişince yayından önce çalıştırın: eski ya da değişmiş bir
adres, kullanıcıda "sunucu yanıt vermedi" hatası olarak görünür.

UYARI (yakalama denetimi): bazı ağlar (şirket ağları, bazı ISS'ler, kum havuzları) UDP/53 trafiğini kendi çözümleyicisine
yönlendirir; o zaman her adres "tamam" görünür ama gerçek sunucuya hiç ulaşılmamıştır. Araç bunu anlamak için Cloudflare'in
`whoami.cloudflare` (CH TXT) sorgusunu kullanır: gerçek 1.1.1.1 buna istemcinin IP'sini döner. Cevap gelmezse sonuçlara
güvenilmez ve araç çıkış kodu 3 ile biter (--yine-de ile yok sayılabilir).
"""
import argparse
import ssl
import os
import re
import socket
import statistics
import struct
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATALOG = os.path.join(ROOT, "app", "src", "main", "java", "app", "dnshizli", "core", "Catalog.kt")
NAMES = ["example.com", "wikipedia.org", "iana.org"]

# s("id", "Marka", null|Variant.X, "birincil", null|"ikincil", etiketler, null|"dot", null|"doh"[, dot2 = "…"][, plain = false])
ENTRY = re.compile(
    r'^\s*s\("([^"]+)",\s*"([^"]+)",\s*(null|Variant\.\w+),\s*"([^"]+)",\s*(null|"[^"]+"),\s*'
    r'(?:FP|setOf\([^)]*\)),\s*(null|"[^"]+"),\s*(null|"[^"]+")(.*)$')


def _opt(v):
    return None if v == "null" else v.strip('"')


def load_catalog():
    out = []
    with open(CATALOG, encoding="utf-8") as f:
        for line in f:
            m = ENTRY.match(line)
            if m:
                rest = m.group(8)
                d2 = re.search(r'dot2\s*=\s*"([^"]+)"', rest)
                variant = None if m.group(3) == "null" else m.group(3).split(".")[1].lower()
                out.append({
                    "id": m.group(1),
                    "name": m.group(2) + (" (" + variant + ")" if variant else ""),
                    "primary": m.group(4),
                    "secondary": _opt(m.group(5)),
                    "dot": _opt(m.group(6)),
                    "dot2": d2.group(1) if d2 else None,
                    "doh": _opt(m.group(7)),
                    "plain": not re.search(r'plain\s*=\s*false', rest),
                })
    return out


def build_query(name, txid):
    q = b"".join(bytes([len(x)]) + x.encode() for x in name.split(".")) + b"\0" + struct.pack(">HH", 1, 1)
    return struct.pack(">HHHHHH", txid, 0x0100, 1, 0, 0, 0) + q


def dot_query(ip, host, name, txid, timeout):
    """DoT (RFC 7858): IP'ye TCP/853, SNI ve sertifika adı = host. -> ms (TLS el sıkışması hariç) ya da hata metni."""
    ctx = ssl.create_default_context()
    try:
        raw = socket.create_connection((ip, 853), timeout=timeout)
    except OSError as e:
        return "bağlanamadı (%s)" % e.__class__.__name__
    try:
        with ctx.wrap_socket(raw, server_hostname=host) as s:
            s.settimeout(timeout)
            pkt = build_query(name, txid)
            t = time.perf_counter()
            s.sendall(struct.pack(">H", len(pkt)) + pkt)
            buf = b""
            while len(buf) < 2 or len(buf) < 2 + struct.unpack(">H", buf[:2])[0]:
                chunk = s.recv(4096)
                if not chunk:
                    return "bağlantı kapandı"
                buf += chunk
            ms = (time.perf_counter() - t) * 1000
            data = buf[2:]
            if struct.unpack(">H", data[:2])[0] != txid:
                return "kimlik tutmadı"
            flags, _, an = struct.unpack(">HHH", data[2:8])
            if (flags & 0xF) != 0 or an < 1:
                return "boş/hatalı cevap"
            return ms
    except ssl.SSLCertVerificationError:
        return "SERTİFİKA ADI TUTMADI"
    except (OSError, ssl.SSLError) as e:
        return "TLS hatası (%s)" % e.__class__.__name__
    finally:
        raw.close()


def is_ipv4(s):
    p = s.split(".")
    return len(p) == 4 and all(x.isdigit() and len(x) <= 3 and 0 <= int(x) <= 255 for x in p)


def raw_query(ip, name, txid, timeout, qtype=1, qclass=1):
    """-> (ms, bayrak, cevap_sayısı) ya da None (yanıt yok / kimlik tutmadı)."""
    q = b"".join(bytes([len(x)]) + x.encode() for x in name.split(".")) + b"\0" + struct.pack(">HH", qtype, qclass)
    pkt = struct.pack(">HHHHHH", txid, 0x0100, 1, 0, 0, 0) + q
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        t = time.perf_counter()
        s.sendto(pkt, (ip, 53))
        data, _ = s.recvfrom(1500)
        ms = (time.perf_counter() - t) * 1000
    except OSError:
        return None
    finally:
        s.close()
    if len(data) < 12 or struct.unpack(">H", data[:2])[0] != txid:
        return None
    flags, _, an = struct.unpack(">HHH", data[2:8])
    return ms, flags, an


def query(ip, name, txid, timeout):
    r = raw_query(ip, name, txid, timeout)
    if r is None:
        return None
    ms, flags, an = r
    ok = bool(flags & 0x8000) and (flags & 0xF) == 0 and an >= 1
    return ms if ok else None


def intercepted(timeout):
    """True: UDP/53 trafiği yakalanıyor (gerçek 1.1.1.1 `whoami.cloudflare` CH TXT sorgusuna cevap verir)."""
    for _ in range(2):
        r = raw_query("1.1.1.1", "whoami.cloudflare", (os.getpid() + 31) & 0xFFFF, timeout, qtype=16, qclass=3)
        if r is not None and (r[1] & 0xF) == 0 and r[2] >= 1:
            return False
    return True


def probe(ip, tries, timeout):
    times = []
    for i in range(tries):
        ms = query(ip, NAMES[i % len(NAMES)], (os.getpid() + i * 7919) & 0xFFFF, timeout)
        if ms is not None:
            times.append(ms)
    return times


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tries", type=int, default=3)
    ap.add_argument("--timeout", type=float, default=2.0)
    ap.add_argument("--dot-yok", action="store_true", help="DoT denetimini atla")
    ap.add_argument("--yine-de", action="store_true", help="yakalama uyarısına rağmen çıkış kodunu 3 yapma")
    args = ap.parse_args()

    cat = load_catalog()
    problems = []
    if len(cat) < 5:
        print("Katalog okunamadı: %s" % CATALOG)
        return 2
    ids = [c["id"] for c in cat]
    for d in {i for i in ids if ids.count(i) > 1}:
        problems.append("yinelenen kimlik: " + d)
    seen = {}
    for c in cat:
        for k in ("primary", "secondary"):
            a = c[k]
            if a is None:
                continue
            if not is_ipv4(a):
                problems.append("%s: geçersiz IPv4 %s" % (c["id"], a))
            if a in seen:
                problems.append("%s ve %s aynı adresi kullanıyor: %s" % (c["id"], seen[a], a))
            seen[a] = c["id"]

        if not c["plain"] and not (c["dot"] or c["doh"]):
            problems.append("%s: düz DNS kapalı ama DoT/DoH da yok" % c["id"])
        if c["doh"] and not c["doh"].startswith("https://"):
            problems.append("%s: DoH adresi https:// ile başlamıyor" % c["id"])

    print("%-26s %-16s %-10s %-16s %-10s %-22s" % ("sunucu", "birincil", "ms", "ikincil", "ms", "DoT"))
    bad_primary = 0
    bad_secondary = 0
    bad_dot = 0
    for c in cat:
        if c["plain"]:
            p = probe(c["primary"], args.tries, args.timeout)
            s = probe(c["secondary"], args.tries, args.timeout) if c["secondary"] else None
            pm = ("%.0f" % statistics.median(p)) if p else "YANIT YOK"
            if not p:
                bad_primary += 1
            if c["secondary"] is None:
                sm = "-"
            elif s:
                sm = "%.0f" % statistics.median(s)
            else:
                sm = "YANIT YOK"
                bad_secondary += 1
        else:
            pm, sm = "(düz yok)", "-"
        dm = "-"
        if c["dot"] and not args.dot_yok:
            r = dot_query(c["primary"], c["dot"], NAMES[0], (os.getpid() + 101) & 0xFFFF, args.timeout + 2)
            if isinstance(r, str) and c["dot2"]:
                r2 = dot_query(c["primary"], c["dot2"], NAMES[0], (os.getpid() + 103) & 0xFFFF, args.timeout + 2)
                if not isinstance(r2, str):
                    r = r2
            if isinstance(r, str):
                dm = r
                bad_dot += 1
            else:
                dm = "%.0f ms" % r
        print("%-26s %-16s %-10s %-16s %-10s %-22s" % (c["name"], c["primary"], pm, c["secondary"] or "-", sm, dm))

    for p in problems:
        print("SORUN:", p)
    print("\n%d sunucu; birincil yanıtsız: %d, ikincil yanıtsız: %d, DoT sorunlu: %d, katalog sorunu: %d"
          % (len(cat), bad_primary, bad_secondary, bad_dot, len(problems)))
    if intercepted(args.timeout):
        print("\nUYARI: Bu ağda UDP/53 trafiği yakalanıyor olabilir (Cloudflare'in whoami.cloudflare sorgusu cevapsız kaldı).")
        print("       Yukarıdaki \"tamam\" sonuçları gerçek sunuculara ulaşıldığını KANITLAMAZ. Aracı normal bir ev/mobil ağında çalıştırın.")
        if not args.yine_de:
            return 3
    return 1 if (bad_primary or bad_dot or problems) else 0


if __name__ == "__main__":
    sys.exit(main())
