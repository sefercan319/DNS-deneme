# DNS Hızlı — Gizlilik Politikası

> **Bu bir şablondur.** Köşeli parantezli yerleri kendi bilgilerinle doldur, herkese açık bir adrese koy (GitHub Pages, kendi siten…)
> ve bu adresi Play Console'daki "Gizlilik politikası" alanına gir. Hukuki tavsiye değildir; gerekirse bir uzmana danış.
> Uygulama bir şeyi değiştirirse (ör. analitik eklenirse) bu metni de güncelle.

**Son güncelleme:** [GG.AA.YYYY]
**Geliştirici:** [Adın ya da şirket adın] · **İletişim:** [e-posta adresin]

## Kısaca

- Hesap açmazsın, kişisel bilgi vermezsin.
- Uygulama kişisel veri **toplamaz, saklamaz, satmaz, paylaşmaz**. Reklam ve analitik içermez.
- Girdiğin sitelerin adlarını (DNS sorgularını) **kaydetmez**. Bu sorgular, **senin seçtiğin DNS sağlayıcısına** gönderilir (aşağıya bak).

## Uygulama ne yapar?

DNS Hızlı, telefonundaki DNS sorgularını (bir site adının numarasını sormayı) sen seçtiğin herkese açık bir DNS sunucusuna
(ör. Cloudflare, Google, Quad9, AdGuard) yönlendirir. Bunu yapmak için Android'in VPN arayüzünü (`VpnService`) **yerel olarak** kullanır.
Bu bir VPN hizmeti değildir: trafiğin bir VPN sunucusuna gönderilmez; yalnızca DNS sorguları seçtiğin sunucuya iletilir, diğer tüm
trafik normal yolundan devam eder.

## Hangi veriye erişir, ne yapar?

| Veri | Ne olur |
|------|---------|
| DNS sorguları (girdiğin sitelerin adları) | VPN arayüzü üzerinden alınır ve seçtiğin DNS sağlayıcısına iletilir. Varsayılan olarak **şifreli** gider (DNS-over-TLS ya da DNS-over-HTTPS); ayarlardan şifrelemeyi kapatırsan ya da şifreli bağlantı kurulamazsa **şifresiz (düz DNS, UDP/53)** gider ve uygulama bunu gösterir. Uygulama sorguları **kaydetmez**, kendi sunucusuna **göndermez**, kimseyle paylaşmaz. |
| Sağlayıcının sunucu adı | Şifreli bağlantı kurmak için sağlayıcının kendi sunucu adı (ör. `dns.quad9.net`) bir kez o sağlayıcının düz DNS'ine sorulur. Bu sorgu senin gezdiğin siteler hakkında bilgi içermez. |
| Ölçüm geçmişi, günlük sorgu sayıları (son 7 gün), son kullanılan ve gizlenen sunucular | Yalnızca cihazında saklanır. Site adı içermez. |
| Ayarları dışa aktarma | Yalnızca **sen** "Dışa aktar" dersen ayarların kısa bir metin olarak panoya kopyalanır; nereye yapıştıracağın senin kararındır. Site adı içermez. |
| Ana ekran widget'ı | Yalnızca bağlantı durumu, sunucu adı ve protokolü gösterir. |
| Ayarların (tema, favoriler, son sunucu, anahtarlar) | Yalnızca cihazında, uygulamanın özel alanında saklanır. Cihazdan çıkmaz. |
| Toplam sayaçlar (sorgu sayısı, önbellek isabeti, bağlı kalma süresi) | Yalnızca cihazında, sayı olarak saklanır; hangi siteye ait olduğu tutulmaz. |
| Bağlantı geçmişi, sunucu kullanım süreleri, veri trafiği | Son 30 bağlantı oturumunun sunucusu, yöntemi, süresi, sorgu sayısı ve bitiş nedeni; sunucu başına süre; gönderilen/alınan toplam bayt. Yalnızca cihazında saklanır; site adı içermez; Ayarlar'dan silinebilir. |
| Bağlantı testi | "Bağlantıyı test et" dendiğinde rastgele bir ad, bilerek DNSSEC'i bozuk bir test adı ve bilinen bir reklam adı seçtiğin DNS sağlayıcısına sorulur (kişisel veri içermez). Sonuç yalnızca ekranda gösterilir. |
| Son çökme notu | Uygulama beklenmedik biçimde kapanırsa hata türünün kısa özeti cihazında tutulur ve yalnızca sen "tanılama raporunu paylaş" dersen rapora girer. |
| Yedekleme | Android yedeklemesi ve cihazdan cihaza aktarım **kapalıdır**: ayarların bulut yedeğine girmez. |
| Tanılama günlüğü | Yalnızca bağlantı olayları ("bağlandı", "yedek sunucuya geçildi"…) ve yalnızca bellekte tutulur; uygulama kapanınca silinir. Site adı ve kişisel veri içermez. Onu **sen** paylaşmayı seçmedikçe hiçbir yere gitmez. |

## Üçüncü taraflar: DNS sağlayıcıları

Seçtiğin DNS sağlayıcısı (Cloudflare, Google, Quad9, AdGuard, Control D, OpenDNS, Mullvad, DNS.SB, DNS4EU, UncensoredDNS,
CleanBrowsing) sorgularını görür ve **kendi gizlilik politikasına** göre işler. Bu politikalar bizim denetimimizde değildir;
tercih etmeden önce ilgili sağlayıcının internet sitesindeki politikayı okumanı öneririz. Şifreleme açıkken ağdaki üçüncü kişiler
(ör. Wi-Fi sahibi, internet operatörü) sorguların içeriğini göremez, ancak hangi DNS sağlayıcısına bağlandığını görebilir.
Şifreleme kapalıyken bu kişiler sorguları da görebilir.

## İzinler ve nedenleri

- **VPN (Android'in VPN izni / `BIND_VPN_SERVICE`)**: DNS sorgularını yönlendirmek için yerel arayüzü kurar. Sen onay vermeden açılmaz.
- **İnternet, ağ durumu**: DNS sunucularına ulaşmak, hız ölçmek ve Wi-Fi ↔ mobil veri geçişini fark etmek için.
- **Önplan hizmeti**: bağlantı açıkken Android'in zorunlu tuttuğu bildirimi göstermek için.
- **Açılışta başlatma (`RECEIVE_BOOT_COMPLETED`)**: yalnızca "Telefon açılınca bağlan" ayarını açarsan kullanılır.
- **Bildirimler (Android 13+)**: bağlantı bildirimi ve (açarsan) "bağlantı koptu" uyarısı için; vermezsen uygulama yine çalışır.

Uygulama konum, kişi, mikrofon, kamera, depolama gibi hiçbir kişisel veri iznine ihtiyaç duymaz.

## Çocuklar

Uygulama çocuklara yönelik değildir ve bilerek hiçbir kişiden veri toplamaz.

## Verilerini silmek

Uygulamanın cihazındaki tüm verisi (ayarlar, sayaçlar) uygulamayı kaldırdığında silinir. Geliştirici tarafında saklanan bir verin yoktur.

## Değişiklikler

Bu politika değişirse bu sayfada yeni tarihle yayınlanır.

## İletişim

Sorular için: [e-posta adresin]
