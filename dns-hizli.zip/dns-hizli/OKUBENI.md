# DNS Hızlı — Okubeni

Popüler, bilinen herkese açık DNS sunucularını (Cloudflare, Google, Quad9, AdGuard…) tek listede toplayan ve
**tek dokunuşla** bağlanan, sade ve akışkan (Frutiger Aero) bir Android uygulaması. Telefonda yerel bir VPN arayüzü
açar; yalnızca DNS sorguları seçilen sunucuya gider, diğer tüm trafik normal yolundan devam eder. Kullanıcı kendi DNS'ini
ekleyemez (bilinçli: yalnızca bilinen sunucular).

- **Dil / araçlar:** Kotlin 2.3 · AGP 8.13.2 · Gradle 8.13 · minSdk 26 (Android 8.0) · hedef/derleme SDK 36 · **dış bağımlılık yok.**
- **Özellikler:** `OZELLIKLER.md` (40 özellik, hangisinin nasıl doğrulandığıyla birlikte).
- **Gizlilik politikası şablonu:** `GIZLILIK.md` · **Mağaza metni:** `store/magaza_metni.md`.

> **Dürüst durum özeti.** Çekirdek mantık (DNS yönlendirici, önbellek, yedek sunucu, ağ kuralları, model ve tüm arayüz sahnesi)
> bilgisayarda **908 otomatik kontrolle** sınandı ve geçti. Android'e özgü kısım (VPN servisi/tüneli, bildirim, karo, açılışta
> bağlanma, erişilebilirlik sağlayıcısı, etkinlik) yazıldı ve Android 34/35/36 API taslaklarına karşı derlendi; **bir telefonda
> ya da emülatörde çalıştırılmadı.** Gradle derlemesi (AGP/R8/kaynak işleme) de bu ortamda çalıştırılamadı (Google sunucularına
> erişim yok). Önizleme görselleri cihaz ekran görüntüsü değil, aynı çizim kodunun bilgisayarda üretilmiş halidir.
> Yani: ilk denemede küçük hatalar çıkması normaldir; aşağıdaki "İlk cihaz denemesi" listesi tam bunun için.

## 1. Derleme ve çalıştırma

1. **Android Studio**'nun güncel sürümünü kur. `File → Open` ile bu klasörü aç. İlk senkronizasyon internetten Gradle 8.13,
   Android Gradle Plugin ve Kotlin eklentisini indirir. Studio eksik SDK parçalarını ("Android SDK Platform 36",
   "Build-Tools 35.0.0") kendisi önerir: **Install** de.
2. Telefonda *Geliştirici seçenekleri → USB hata ayıklama* açık olsun; ▶ **Run** ile yükle.
3. Komut satırı: `./gradlew assembleDebug` (APK: `app/build/outputs/apk/debug/`), `./gradlew installDebug` (bağlı cihaza yükler).
   JDK 17+ gerekir (Studio'nun gömülü JDK'sı yeter). `gradlew` çalışmazsa (sarmalayıcı jar'ı burada çalıştırılamadı) kurulu
   bir Gradle ile `gradle wrapper --gradle-version 8.13` komutu onu yeniden üretir; Studio de kendisi onarır.

Bir sürüm sayısı Studio'da "güncelle" diye çıkarsa sorun yok: tüm sürümler tek yerde — kök `build.gradle.kts` (AGP, Kotlin),
`gradle/wrapper/gradle-wrapper.properties` (Gradle).

## 2. Testler (Android gerekmez)

```
./run-tests.sh            # hepsi: çekirdek, çizim, model, arayüz, rastgele kullanım (~10 sn; derleme ~1 dk)
./run-tests.sh core ui    # seçili gruplar: core gfx model ui monkey
./run-tests.sh alloc      # kare başına bellek ayırma raporu
./run-tests.sh previews   # tasarım önizlemesi PNG'leri (previews/)
```

Gerekenler: JDK 17+ ve `kotlinc` (kotlinlang.org/docs/command-line.html). Testler gerçek UDP soketleri üzerinden sahte bir DNS
sunucusuyla yönlendiriciyi uçtan uca dener; arayüzü ise ekransız bir çizim yüzeyine çizip erişilebilirlik etiketleri üzerinden
"siyah kutu" olarak kullanır. `selftest/MonkeyTest.kt` yüzlerce rastgele dokunuş/ayar/boyut dizisiyle çökme arar.

`tools/catalog_check.py` katalogdaki her sunucuya **gerçek** bir DNS sorgusu gönderip adreslerin hâlâ yanıt verdiğini kontrol
eder (`python3 tools/catalog_check.py`). Katalog değiştikçe ve her yayından önce çalıştır. Araç, ağın DNS trafiğini yakalayıp
yakalamadığını da denetler ve yakalıyorsa sonuçlara güvenmemeni söyler (bu sandbox'ta tam böyleydi: AdGuard bile reklam alan
adını engellemedi; bu yüzden katalog adresleri **burada canlı doğrulanamadı**, sen kendi ağında çalıştır).

## 3. İlk cihaz denemesi kontrol listesi

Android kısmı hiç çalıştırılmadığı için ilk telefon denemesinde sırayla şunlara bak. Takılırsan `adb logcat` ve uygulamanın
**Ayarlar → Tanılama günlüğü** ekranı nedeni genellikle gösterir.

1. Uygulama açılıyor mu, arka plan gökyüzü rengi ve küre çiziliyor mu? (Açılmazsa: logcat'te `AndroidRuntime`.)
2. Küreye dokun → ilk açılış bilgilendirmesi → "Anladım, devam et" → Android'in VPN izni penceresi → "Tamam" → küre dolup **Bağlı**.
3. Gerçekten kullanılıyor mu? Tarayıcıda `https://one.one.one.one/help/` aç (Cloudflare seçiliyse "Connected to 1.1.1.1: Yes"
   demeli; "DoH: No" olması normaldir, bu uygulama düz DNS kullanır) ya da `dnsleaktest.com` ("Extended test") dene. Listeden başka
   bir sunucuya dokunup sonucun değiştiğini gör.
4. Tarayıcıda *Güvenli DNS* (Chrome → Ayarlar → Gizlilik ve güvenlik → Güvenli DNS kullan) ve Android *Özel DNS* ayarının
   "Otomatik/Kapalı" olduğundan emin ol; yoksa sistem sorguları bu yönlendirmeyi atlayabilir (yardım sayfasında da yazar).
5. Bildirimdeki **Kes** düğmesi, hızlı ayarlar kutucuğu (düzenle → "DNS Hızlı"), uygulama simgesine uzun basınca çıkan kısayollar.
6. Wi-Fi ↔ mobil veri geçişi ve uçak modu aç/kapa: bağlantı toparlıyor mu? Ayarlardan "Wi-Fi sunucusu" farklı seçilince geçişte
   sunucu değişiyor mu?
7. Bağlıyken başka bir VPN uygulaması başlat: bu uygulama "sistem tarafından kapatıldı" göstermeli (ya da bağlanamazken
   "Başka bir VPN açık olabilir").
8. Ayarlar → "Telefon açılınca bağlan" açık + telefonu yeniden başlat; ayrıca uygulamayı **zorla durdur** ve sonra aç.
9. TalkBack açıkken ana ekranı ve ayarları gez: küre, satırlar, kaydırıcı ve anahtarlar okunuyor mu, kaydırma çalışıyor mu?
10. Pil/bellek: bir gün bağlı bırak; *Ayarlar → Pil → Uygulama kullanımı*. (Beklenti: boştayken neredeyse sıfır.)
11. Gece teması, tema geçişi animasyonu, düşük güç modu, büyük yazı boyutu (sistem ayarından) ve yatay/tablet görünümü.

## 4. Google Play'e yayın

Aşağıdakiler Ekim 2026'da resmî Google belgelerinden okunarak yazıldı; kurallar değişebilir, Play Console'daki güncel metin esastır.
Hukuki tavsiye değildir.

1. **Uygulama kimliği.** `app/build.gradle.kts` üstündeki `val appId = "app.dnshizli"` satırını kendi benzersiz kimliğinle
   değiştir (ör. `com.seninadin.dnshizli`; `com.example.*` olmaz). Yalnızca bu satır değişir: kod paketi aynı kalır, kısayollar
   kimliği oradan alır. Yayından sonra kimlik **değiştirilemez**.
2. **Hedef API.** Play, 31 Ağustos 2026'dan beri yeni uygulama ve güncellemelerde **API 36** (Android 16) ister
   (uzatma talebi 1 Kasım 2026'ya kadar). Proje 36'ya ayarlı; her yıl bir üst sürüme çıkman gerekecek.
3. **İmza.** Bir kez yükleme anahtarı üret ve **yedekle** (kaybedersen güncelleme yayınlayamazsın):
   ```
   keytool -genkeypair -v -keystore dnshizli-upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
   `keystore.properties.example` dosyasını `keystore.properties` olarak kopyalayıp doldur (git'e girmez). Play Console'da
   *Play Uygulama İmzalama* açık kalsın.
4. **Paket.** `./gradlew bundleRelease` → `app/build/outputs/bundle/release/app-release.aab`. Her yüklemede `versionCode`'u artır
   (`app/build.gradle.kts`).
5. **Kişisel geliştirici hesabı** (13 Kasım 2023'ten sonra açıldıysa) üretime çıkmadan önce **en az 12 test kullanıcısıyla
   kesintisiz 14 gün kapalı test** ister; kuruluş hesaplarında bu şart yoktur.
6. **Play Console → Uygulama içeriği** (hepsi zorunlu):
   - **Gizlilik politikası** URL'si: `GIZLILIK.md` şablonunu doldurup herkese açık bir adrese koy (GitHub Pages, kendi siten…).
   - **Reklamlar:** Yok. **Uygulama erişimi:** kısıtlama yok. **Hedef kitle:** çocuklara yönelik değil. İçerik derecelendirme anketi.
   - **Veri güvenliği:** Uygulama kendi adına veri toplamaz/kaydetmez. Ancak DNS sorgularının (alan adları) kullanıcının seçtiği
     DNS sağlayıcısına gittiğini göz önünde bulundur; bunu forma ve politikaya açıkça yazmak en güvenli yoldur (formu nasıl
     işaretleyeceğin senin kararındır).
   - **VPN hizmeti beyanı.** Politika, `VpnService`'i yalnızca VPN'i çekirdek işlevi olan uygulamalara (ve sayılan istisnalara)
     izin verir, mağaza sayfasında kullanımını belgelemeni, uygulama içinde **açık bilgilendirme + onay** göstermeni (ilk açılış
     bilgilendirmesi bunu karşılar) ve formda kısa bir kullanım videosu (≤ 90 sn) ile bilgilendirme videosu vermeni ister. Bu
     uygulamada VPN çekirdek işlevdir: *yerel* VPN arayüzü yalnızca DNS yönlendirmek içindir. Not: politika ayrıca cihazdan VPN
     tünel ucuna verinin **şifrelenmesini** ister; bu uygulamanın uzak bir tünel ucu yoktur ama DNS sorguları şifresizdir
     (düz DNS). İncelemede sorulabilir; formda durumu olduğu gibi anlat. Reddedilirse en sağlam çözüm şifreli DNS (DoH/DoT)
     eklemektir (bkz. öneriler).
   - **Önplan hizmeti beyanı** (hedef Android 14+ olduğu için): hizmet türü `systemExempted`; Android belgeleri bunu VPN
     uygulamaları (Ayarlar → Ağ ve internet → VPN üzerinden kurulanlar) için açıkça izinli sayar. Formda tür/kullanım için
     VPN ile ilgili seçeneği seç; video: uygulamayı aç → küreye dokun → izni ver → bağlı + bildirim.
7. **Mağaza girişi:** `store/magaza_metni.md` (kısa/uzun açıklama; VPN kullanımı belgelendi). Görseller: `store/ikon-512.png`,
   `store/one-cikan-gorsel-1024x500.png`. Ekran görüntüsünü **kendi telefonundan** al; `previews/` içindekiler çizim önizlemesidir.

## 5. Bilinen sınırlar (dürüstçe)

- **Düz DNS (UDP/53).** Sorgular şifresiz gider. Bazı ağlar (operatör, okul/şirket ağı) 53. porttaki trafiği kendi sunucusuna
  yönlendirebilir; o zaman seçilen sunucunun etkisi görünmez. DNS ile erişim engelini aşmak isteyen kullanıcılar için düz DNS
  çoğu zaman yetmez; bunun çözümü DoH/DoT'tur (öneri #1).
- **Yalnızca IPv4 üzerinden DNS taşıma**; TCP/53 yok. Çok büyük (UDP'ye sığmayan) cevaplar istemci tarafında yeniden denemede
  sorun çıkarabilir. IPv6-only/DNS64 ağlarda (bazı operatörler) herkese açık DNS'ler DNS64 yapmadığı için bağlantı sorunu olabilir.
- **Tek VPN kuralı.** Android aynı anda yalnızca bir VPN'e izin verir; başka VPN açıkken bu uygulama bağlanamaz.
- **Atlayanlar.** Android'in belirli bir sunucu adına sabitlenmiş "Özel DNS"i ve tarayıcıların/uygulamaların kendi DoH'u bu
  yönlendirmeyi kullanmaz (kullanıcı dostu uyarı yardım sayfasındadır).
- **Önbellek boyutu** bağlanırken uygulanır (ayarı değiştirince bir sonraki bağlantıda). **Ağ kuralı** ağ değişiminde ve kullanıcı
  sunucu seçmeden başlayan bağlanmalarda (açılış, kutucuk) uygulanır; listeden elle seçim her zaman kuralın önündedir.
- **Dil:** yalnızca Türkçe (metinler `ui/Strings.kt` içinde tek yerde). **Klavye/harici donanımla gezinti** yok (dokunmatik + TalkBack var).
- Çizim kodu sistemin standart bileşenlerini kullanmadığı için metin seçme gibi sistem davranışları yoktur; bunun karşılığı
  küçük bellek ve tam tasarım kontrolüdür.

## 6. Geliştirme önerileri (öncelik sırasıyla)

1. **Şifreli DNS (DoH / DoT).** En değerli ek: gizliliği artırır, ağ yakalamasını aşar, Play'in VPN/şifreleme sorularını rahatlatır.
   Nasıl: `DnsForwarder` içindeki "yukarı akış" kısmını bir arayüze ayır; DoT için `SSLSocket` (853), DoH için `HttpsURLConnection`
   — ikisi de bağımlılıksız. Katalogda sunucu başına `dohUrl`/`dotHost` alanı ekle (Cloudflare, Google, Quad9, AdGuard hepsi sunar).
2. **İngilizce (ve başka diller).** `Strings` nesnesini bir arayüze çevirip `Locale`'e göre seç; Play'de erişimi çok artırır.
3. **TCP/53 ve IPv6.** Tünelde küçük bir TCP durum makinesi ve IPv6 adres/yol; "çok büyük cevap" ve DNS64 sınırlarını kaldırır.
4. **Uygulama bazlı ayırma** (`addAllowedApplication` / `addDisallowedApplication`): hangi uygulamalar bu DNS'i kullansın.
   Güçlü ama arayüzü karmaşıklaştırır; "karmaşıklıktan kaçın" ilkesine karşı bir seçimdir.
5. **Katalog güncelleme.** Sunucu listesini uygulama güncellemesi beklemeden yenilemek (imzalı küçük bir JSON). Ağ erişimi ve
   gizlilik dengesi getirir; basit tutmak için her sürümde `tools/catalog_check.py` çalıştırıp katalogu elle güncellemek yeterli olabilir.
6. **Gelir (isteğe bağlı).** Reklamsız kalıp tek seferlik "destekçi" satın alımı (Play Billing; bir bağımlılık ekler) en uyumlu yol.
   Gelir beklentisi vaat etmiyorum; bu tür araçlarda indirme/gelir genellikle düşüktür.
7. **Cihaz testi otomasyonu.** Tüneli, bildirimi ve karoyu enstrümantasyon testleriyle (UiAutomator) sına; yayından önce Play
   Console'un *ön başlatma raporu* ve gerçek cihazlarla elle deneme.
8. **AGP 9 / yerleşik Kotlin göçü.** AGP 8.13 son 8.x hattıdır; Studio "yükselt" önerdiğinde resmî göç kılavuzunu izle.
9. **Küçük iyileştirmeler:** ana ekran widget'ı, sunucu başına son 24 saat gecikme eğrisi, "bağlantı koparsa bildir" seçeneği.

## 7. Nasıl genişletilir?

| İstek | Nerede |
|-------|--------|
| Sunucu ekle/çıkar | `core/Catalog.kt` (tek satır); sonra `python3 tools/catalog_check.py` |
| Tema ekle | `core/Themes.kt` (`Themes.all` listesine bir `AeroTheme`); kontrast testleri otomatik kapsar |
| Yeni ayar | `core/Settings.kt` (alan + kodlama) → `ui/Pages.kt` `SettingsPage` (bir satır) → `ui/Strings.kt` |
| Metin/dil | `ui/Strings.kt` |
| Servis davranışı | `platform/DnsVpnService.kt` (komutlar tek iş parçacığında sıralanır; iptal numarası `cancelGen`) |
| Yeni ekran | `ui/Pages.kt` (`ScrollPage`'den türet) + `Scene.kt` gezinti |

## 8. Klasör yapısı

```
app/src/main/java/app/dnshizli/
  core/       saf Kotlin: DNS yönlendirici/önbellek/paketler, katalog, ayarlar, tema ve çizim sanatı (Android'siz test edilir)
  ui/         saf Kotlin: model + sahne (kendi çizdiğimiz arayüz: düğümler, sayfalar, paneller, animasyon)
  platform/   Android: VpnService + tünel, ağ izleme, bildirim, hızlı ayar karosu, açılış alıcısı, etkinlik, SceneView/AndroidGfx
app/src/main/res/   simgeler (uyarlanabilir + temalı), tema, kısayollar
selftest/     JVM testleri (908 kontrol), önizleme üreticisi
tools/        catalog_check.py (canlı katalog doğrulaması)
store/        Play mağaza metni ve görselleri
previews/     tasarım önizlemeleri (PNG)
```

Mimari neden böyle: arayüz Android bileşenleriyle değil, kendi küçük sahne kitaplığımızla çizilir. Böylece (1) AndroidX/Compose
bağımlılığı olmaz, APK ve bellek küçük kalır, (2) tüm arayüz mantığı bilgisayarda ekransız test edilebilir, (3) Frutiger Aero cam/sıvı
görünüm her cihazda birebir aynıdır. Bedeli: erişilebilirlik ve geri hareketi gibi sistem entegrasyonlarını biz bağlarız (bağlandı,
ama cihazda sınanmadı — yukarıdaki kontrol listesi).

## 9. Sorun giderme

- *Senkronizasyon "Could not resolve …"*: internet/proxy ayarını kontrol et; ilk senkronizasyon indirme yapar.
- *"SDK location not found"*: Studio `local.properties` oluşturur; komut satırında `ANDROID_HOME` ayarla.
- *"Failed to find Build Tools / Platform 36"*: SDK Manager'dan yükle.
- *Bağlanamadı: "VPN arayüzü açılamadı"*: başka bir VPN açık ya da sistem izni geri alınmış; Ayarlar → "Sistem VPN ayarları".
- *Bağlı görünüyor ama etkisi yok*: yukarıda "Atlayanlar"a bak (Özel DNS / tarayıcı güvenli DNS).
