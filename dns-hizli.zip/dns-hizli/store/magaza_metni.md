# Google Play mağaza metni (Türkçe) — taslak

Play Console → *Mağaza girişi*. Sınırlar parantez içinde. Köşeli yerleri doldur.

## Uygulama adı (en çok 30 karakter)
DNS Hızlı

## Kısa açıklama (en çok 80 karakter)
Popüler DNS sunucularına tek dokunuşla, şifreli bağlan. Sade, hafif, reklamsız.

## Tam açıklama (en çok 4000 karakter)
DNS Hızlı, Cloudflare, Google, Quad9, AdGuard gibi bilinen herkese açık DNS sunucularını tek listede toplar ve tek dokunuşla bağlanmanı sağlar.

Küreye dokun, bağlan. Başka bir sunucuya dokun, kesintisiz geç. Hepsi bu.

NELER VAR
• 26 popüler DNS sunucusu: hızlı, gizlilik odaklı, reklam engelleyen, aile filtreli ve güvenlik odaklı seçenekler
• Şifreli DNS: DNS-over-TLS (DoT) ve DNS-over-HTTPS (DoH), otomatik seçim
• Tek dokunuşla bağlan ve bağlıyken tüneli koparmadan sunucu değiştir
• Hız ölçümü: en iyi, ortanca ve kayıp; ölçüm geçmişi grafiği; listeyi aşağı çekerek ölç
• Engellenen sorgu sayacı, haftalık kullanım grafiği
• Duraklat (5 / 15 / 60 dk), kendiliğinden devam
• Ana ekran widget'ı, küreye uzun basınca hızlı seçim
• Favoriler, kategori süzgeçleri, hıza göre sıralama
• Otomatik yedek sunucu: seçtiğin sunucu yanıt vermezse yedeğine geçer
• Wi-Fi ve mobil veri için ayrı sunucu seç
• Hızlı ayarlar kutucuğu, bildirimden kes / sonraki sunucu, uygulama kısayolları
• Son kullanılanlar, sunucu gizleme, sıkı liste, ayarları dışa/içe aktarma
• İsteğe bağlı: uygulama açılınca ya da telefon açılınca otomatik bağlan
• Bağlantıyı test et: DNS çalışıyor mu, DNSSEC doğrulanıyor mu, reklam engelleniyor mu
• Sıkı şifreleme, şifresize düşünce uyarı ve kendiliğinden şifreliye dönüş, kopunca otomatik yeniden bağlanma
• Bağlantı geçmişi, sunucu başına kullanım süresi, veri trafiği

SADE VE AKICI TASARIM
• Şeffaf cam yüzeyler ve akışkan animasyonlarla Frutiger Aero esintili arayüz
• 12 tema (AMOLED, Sakura, Bal, Kuzey ışığı ve duvar kâğıdından türeyen tema dahil), otomatik ya da saate göre koyu mod, ayarlanabilir cam şeffaflığı, kabarcıklar ve animasyon düzeyi
• Düşük güç modu, sade görünüm, yüksek kontrast, uygulama içi yazı boyutu; erişilebilirlik (TalkBack)
• 12 dil: Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська

HAFİF
• Arka planda çok az kaynak kullanır: ekran kapalıyken sürekli çalışan bir döngü yoktur
• Küçük boyut, harici kütüphane yok

GİZLİLİK
• Hesap yok, reklam yok, analitik yok
• Uygulama sorgu adlarını kaydetmez ve kendi adına hiçbir yere göndermez
• DNS sorguların seçtiğin sağlayıcıya varsayılan olarak şifreli (DoT/DoH) iletilir; şifrelemeyi kapatırsan düz DNS kullanılır. Sağlayıcının kendi gizlilik politikası geçerlidir

VPN ARAYÜZÜNÜN KULLANIMI (Android VpnService)
DNS Hızlı, DNS sorgularını seçtiğin sunucuya yönlendirmek için Android'in VPN arayüzünü (VpnService) yerel olarak kullanır. Bu, uzak bir VPN hizmeti değildir: trafiğin bir VPN sunucusuna gönderilmez; yalnızca DNS sorguları seçtiğin sunucuya iletilir, diğer tüm trafik normal yolundan devam eder. Uygulama, ilk bağlanışta bunu açıkça bildirir ve Android'in VPN izni penceresi onayını ister.

BİLMEN GEREKENLER
• Android aynı anda yalnızca bir VPN'e izin verir; başka bir VPN uygulaması açıkken bu uygulama bağlanamaz.
• Bazı tarayıcıların "güvenli DNS" ayarı ve Android'in belirli bir sunucu adına sabitlenmiş "Özel DNS" ayarı kendi sunucusunu kullandığı için bu yönlendirmeyi atlayabilir; "Otomatik" ya da "Kapalı" bırakman yeterli.
• Şifreleme kapalıyken bazı ağlar (operatör, okul, şirket) DNS trafiğini kendi sunucusuna yönlendirebilir.

## Yenilikler (sürüm notu)
• Dört yeni dil (Bahasa Indonesia, Tiếng Việt, Polski, Українська), üç yeni tema, duvar kâğıdı teması
• Bağlantı testi, sıkı şifreleme, yedek sunucu, otomatik yeniden bağlanma, bağlantı geçmişi
• Sahte DNS cevaplarına karşı ek denetimler, daha sağlam şifreli bağlantı ve önbellek
(Diğer diller için mağaza metnini Play Console'da "Çeviri ekle" ile gir; uygulama 12 dilde.)

## Kategori ve etiketler
Kategori: Araçlar. Etiketler: ağ, DNS, hız, gizlilik.

## İletişim
E-posta: [e-posta adresin] · Gizlilik politikası URL: [yayınladığın adres]

## Görseller
- Simge: `ikon-512.png` (512×512)
- Öne çıkan görsel: `one-cikan-gorsel-1024x500.png` (1024×500)
- Ekran görüntüleri: **kendi telefonundan** al (en az 2, tercihen 4–8): bağlı ana ekran, sunucu listesi, ayarlar/temalar,
  sunucu ayrıntısı. `previews/` klasöründeki dosyalar çizim önizlemesidir; mağazada gerçek ekran görüntüsü kullan.

## Veri güvenliği formu için not
Uygulama kendi adına veri toplamaz/saklamaz. Yine de DNS sorgularının (alan adları) kullanıcının seçtiği DNS sağlayıcısına iletildiğini
formu doldururken değerlendir ve politikada açıkça yaz (bkz. `OKUBENI.md` §4).
