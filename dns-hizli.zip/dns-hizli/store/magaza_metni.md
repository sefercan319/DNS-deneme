# Google Play mağaza metni (Türkçe) — taslak

Play Console → *Mağaza girişi*. Sınırlar parantez içinde. Köşeli yerleri doldur.

## Uygulama adı (en çok 30 karakter)
DNS Hızlı

## Kısa açıklama (en çok 80 karakter)
Popüler DNS sunucularına tek dokunuşla bağlan. Sade, hafif, reklamsız.

## Tam açıklama (en çok 4000 karakter)
DNS Hızlı, Cloudflare, Google, Quad9, AdGuard gibi bilinen herkese açık DNS sunucularını tek listede toplar ve tek dokunuşla bağlanmanı sağlar.

Küreye dokun, bağlan. Başka bir sunucuya dokun, kesintisiz geç. Hepsi bu.

NELER VAR
• 21 popüler DNS sunucusu: hızlı, gizlilik odaklı, reklam engelleyen, aile filtreli ve güvenlik odaklı seçenekler
• Tek dokunuşla bağlan ve bağlıyken tüneli koparmadan sunucu değiştir
• Hız ölçümü: tüm sunucuların gecikmesini ölç, en hızlıya tek dokunuşla bağlan
• Favoriler, kategori süzgeçleri, hıza göre sıralama
• Otomatik yedek sunucu: seçtiğin sunucu yanıt vermezse yedeğine geçer
• Wi-Fi ve mobil veri için ayrı sunucu seç
• Hızlı ayarlar kutucuğu, bildirimden kes, uygulama kısayolları
• İsteğe bağlı: uygulama açılınca ya da telefon açılınca otomatik bağlan

SADE VE AKICI TASARIM
• Şeffaf cam yüzeyler ve akışkan animasyonlarla Frutiger Aero esintili arayüz
• 6 tema, otomatik açık/koyu mod, ayarlanabilir cam şeffaflığı, kabarcıklar ve animasyon düzeyi
• Düşük güç modu; erişilebilirlik (TalkBack) ve büyük yazı desteği

HAFİF
• Arka planda çok az kaynak kullanır: ekran kapalıyken sürekli çalışan bir döngü yoktur
• Küçük boyut, harici kütüphane yok

GİZLİLİK
• Hesap yok, reklam yok, analitik yok
• Uygulama sorgu adlarını kaydetmez ve kendi adına hiçbir yere göndermez
• DNS sorguların, seçtiğin DNS sağlayıcısına şifrelenmeden (düz DNS) iletilir; sağlayıcının kendi gizlilik politikası geçerlidir

VPN ARAYÜZÜNÜN KULLANIMI (Android VpnService)
DNS Hızlı, DNS sorgularını seçtiğin sunucuya yönlendirmek için Android'in VPN arayüzünü (VpnService) yerel olarak kullanır. Bu, uzak bir VPN hizmeti değildir: trafiğin bir VPN sunucusuna gönderilmez; yalnızca DNS sorguları seçtiğin sunucuya iletilir, diğer tüm trafik normal yolundan devam eder. Uygulama, ilk bağlanışta bunu açıkça bildirir ve Android'in VPN izni penceresi onayını ister.

BİLMEN GEREKENLER
• Android aynı anda yalnızca bir VPN'e izin verir; başka bir VPN uygulaması açıkken bu uygulama bağlanamaz.
• Bazı tarayıcıların "güvenli DNS" ayarı ve Android'in belirli bir sunucu adına sabitlenmiş "Özel DNS" ayarı kendi sunucusunu kullandığı için bu yönlendirmeyi atlayabilir; "Otomatik" ya da "Kapalı" bırakman yeterli.
• Bazı ağlar (operatör, okul, şirket) DNS trafiğini kendi sunucusuna yönlendirebilir; bu durumda seçilen sunucunun etkisi görünmeyebilir.

## Yenilikler (sürüm notu)
İlk sürüm.

## Kategori ve etiketler
Kategori: Araçlar. Etiketler: ağ, DNS, hız, gizlilik.

## İletişim
E-posta: [e-posta adresin] · Gizlilik politikası URL: [yayınladığın adres]

## Görseller
- Simge: `ikon-512.png` (512×512)
- Öne çıkan görsel: `one-cikan-gorsel-1024x500.png` (1024×500)
- Ekran görüntüleri: **kendi telefonundan** al (en az 2, tercihen 4–8): bağlı ana ekran, sunucu listesi, ayarlar/temalar,
  sunucu ayrıntısı. `previews/` klasöründeki dosyalar çizim önizlemesidir; mağazada gerçek ekran görüntüsü kullan.

## Veri güvenliği formu için not
Uygulama kendi adına veri toplamaz/saklamaz. Yine de DNS sorgularının (alan adları) kullanıcının seçtiği DNS sağlayıcısına iletildiğini
formu doldururken değerlendir ve politikada açıkça yaz (bkz. `OKUBENI.md` §4).
