# DNS Hızlı — 40 özellik

Arayüz bilerek tek bir ana ekran + bir ayarlar sayfasıdır; aşağıdaki 40 özelliğin çoğu görünmez çalışır ya da
tek bir kontrole bağlıdır. Hiçbiri ek ekran, hesap veya karmaşık ayar gerektirmez.

**Doğrulama düzeyleri** (hangi özelliğe ne kadar güvenebileceğin açık yazılsın diye):

- ✅ **JVM testi**: bilgisayarda (Android olmadan) otomatik testle doğrulandı. Test grubunun adı yazılı.
- 🔧 **Android kodu**: Android'e özgü kısım (servis, tünel, bildirim, karo, erişilebilirlik sağlayıcısı…) yazıldı ve
  Android 34/35/36 API taslaklarına karşı **derlendi**, ama bir telefonda ya da emülatörde **çalıştırılmadı**.
  İlk gerçek cihaz denemesinde bunlara özellikle bak (bkz. `OKUBENI.md` → "İlk cihaz denemesi kontrol listesi").

Yollar `app/src/main/java/app/dnshizli/` altındadır. Test grupları `selftest/` içindedir; `./run-tests.sh` hepsini koşturur.

## Bağlantı ve çekirdek

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 1 | **Küreye dokun: bağlan / kes.** Tek dokunuş, tek kontrol. | `ui/Model.kt` (`tapOrb`), `ui/Widgets.kt` (`OrbBlock`) | ✅ "Model: bağlan / kes", "Ana ekran: küre ve satırlar" |
| 2 | **Yalnızca-DNS yerel VPN.** Sadece DNS adresine giden paketler tünele girer; diğer tüm trafik normal yolundan, dokunulmadan gider. | `platform/DnsVpnService.kt` (`establishTunnel`), `core/Packets.kt` | ✅ paket/yönlendirici testleri; 🔧 tünel kurulumu |
| 3 | **21 sunuculu katalog**: Cloudflare, Google, Quad9, AdGuard, Control D, OpenDNS, Mullvad, DNS.SB, Verisign, UncensoredDNS, CleanBrowsing… (hızlı, gizlilik, reklam, aile, güvenlik). Kullanıcı sunucu **ekleyemez** (bilinçli). | `core/Catalog.kt`, `tools/catalog_check.py` | ✅ "Katalog"; adresleri canlı doğrulamak için aracı **kendi ağında** çalıştır |
| 4 | **Satıra dokun: bağlan.** Bağlıyken başka satıra dokunmak sunucuyu değiştirir. | `ui/Model.kt` (`tapServer`) | ✅ "Model: bağlan / kes", "Ana ekran: küre ve satırlar" |
| 5 | **Kesintisiz sunucu değiştirme.** Tünel kopmaz; yeni sunucu cevap vermezse eskisi korunur ve neden bildirilir. | `platform/DnsVpnService.kt` (`switchServer`), `core/Format.kt` (`ConnectionCheck`) | ✅ "Bağlantı testi", çift dokunma koruması; 🔧 servis akışı |
| 6 | **Otomatik yedek sunucu.** Birincil art arda cevapsız kalıp ikincil cevap verirse kalıcı olarak ikinciye geçer; ağ değişince birinciye döner. | `core/DnsForwarder.kt` | ✅ "Yönlendirici: yedek sunucu…", "…kalıcı yedek geçişi" |
| 7 | **DNS önbelleği, 4 seviye** (kapalı / küçük / normal / büyük). Cevap süresine (TTL) uyar; aynı sorgu ağa gitmeden cevaplanır. | `core/DnsCache.kt`, `core/LongCache.kt`, `core/DnsForwarder.kt` | ✅ "Önbellek", "DNS TTL ayrıştırma", "Yönlendirici: önbellek", "LongCache" |
| 8 | **Ağ değişince yenile.** Wi-Fi ↔ mobil geçişinde bekleyen sorgular ve soket yenilenir; sistem olayıyla çalışır, yoklama yok. | `platform/NetworkWatcher.kt`, `core/DnsForwarder.kt` (`resetNetwork`) | ✅ "Ağ değişimi: soket yenileme"; 🔧 `NetworkWatcher` |
| 9 | **Bağlantı doğrulama.** Bağlanınca sistemin kendi çözümleyicisiyle rastgele bir ad çözdürüp sorgunun gerçekten seçilen sunucudan döndüğü doğrulanır; cevapsız sunucuyla internet kesilmez. | `core/Format.kt` (`ConnectionCheck`), `platform/DnsVpnService.kt` (`verify`) | ✅ "Bağlantı testi"; 🔧 servis |
| 10 | **Ağa göre sunucu.** Wi-Fi'de bir sunucu, mobil veride başka bir sunucu (ya da "otomatik"). | `core/Format.kt` (`Rules`), `ui/Pages.kt` (`SettingsPage`), `ui/Sheets.kt` (`ChoiceContent`) | ✅ "Ağa göre DNS", "Ayarlar: ağ kuralları…"; 🔧 uygulaması |
| 11 | **Son sunucuyu hatırla.** Kürenin altında hep "X seçili" yazar. | `core/Settings.kt` (`lastServer`) | ✅ "Ayarlar", "Model: bağlan / kes" |
| 12 | **Kendiliğinden yeniden bağlanma.** Sistem işlemi bellek için öldürürse servis yeniden başlar ve bağlı kalır. | `platform/DnsVpnService.kt` (`START_STICKY`, `wasActive`) | 🔧 |

## Sunucu listesi

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 13 | **Hız ölçümü**, hepsi ya da tek sunucu (gerçek DNS sorgusu, ms). Sonuçlar saklanır. | `core/DnsProbe.kt`, `ui/Model.kt` (`measure`) | ✅ "Gecikme ölçümü", "Model: hız ölçümü" |
| 14 | **En hıza bağlan.** Ölçüm bitince "En hızlı: X · 12 ms" mesajındaki "Bağlan" ile tek dokunuş. | `ui/Model.kt` (`connectFastest`), `core/ServerList.kt` | ✅ "Model: hız ölçümü", "Sunucu listesi" |
| 15 | **Hıza göre sırala.** | `core/ServerList.kt` | ✅ "Sunucu listesi", "Model: liste, favori, sıralama" |
| 16 | **Favoriler** (yıldız) ve "Favoriler" süzgeci. | `ui/Model.kt` (`toggleFavorite`), `ui/Widgets.kt` (`StarButton`) | ✅ "Model: liste, favori, sıralama" |
| 17 | **Kategori süzgeçleri**: Hızlı, Gizlilik, Reklam, Aile, Güvenlik. | `ui/Model.kt` (`Filter`), `ui/Pages.kt` (`ChipsRow`) | ✅ "Model: liste, favori, sıralama", "Ana ekran: süzgeç, sıralama, ölçüm" |
| 18 | **Sunucu ayrıntıları** (satıra uzun bas): adresleri kopyala, bu sunucuya bağlan/geç, favori yap, tek ölç. | `ui/Sheets.kt` (`DetailsContent`) | ✅ "Paneller: ayrıntı" |

## Sistemle bütünleşme

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 19 | **Uygulama açılınca bağlan** (isteğe bağlı). | `platform/MainActivity.kt` (`handleIntent`) | ✅ ayar anahtarı; 🔧 açılışta bağlanma |
| 20 | **Telefon açılınca bağlan** (isteğe bağlı) ve uygulama güncellenince açıksa devam. | `platform/BootReceiver.kt` | ✅ ayar anahtarı; 🔧 alıcı |
| 21 | **Hızlı ayarlar kutucuğu**: panelden bağlan/kes; izin ya da ilk bilgilendirme yoksa uygulamayı açar. Yalnızca panel görünürken dinler. | `platform/DnsTileService.kt` | 🔧 |
| 22 | **Bildirimde "Kes"** düğmesi; bildirim yalnızca bağlıyken vardır (Android önplan servisi için zorunlu tutar). | `platform/Notifier.kt` | 🔧 |
| 23 | **Uygulama kısayolları**: simgeye uzun bas → Bağlan / Kes. | `res/xml/shortcuts.xml`, `platform/MainActivity.kt` | 🔧 (XML biçimi doğrulandı) |

## Bilgi ve şeffaflık

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 24 | **Canlı istatistik**: süre · sorgu sayısı · önbellek yüzdesi, ortalama yanıt süresi (ms). | `ui/Model.kt` (`statusHint`), `core/DnsForwarder.kt` (`Stats`) | ✅ "Model: durum metinleri…", "İstatistik: ortalama yanıt süresi" |
| 25 | **Kalıcı toplamlar**: toplam sorgu, önbellekten yanıt, bağlı kalma süresi. | `platform/PrefsStore.kt` (`addTotals`), `ui/Pages.kt` | ✅ "Ayarlar" (kodlama); 🔧 servisten aktarım |
| 26 | **Açık durum ve hata metinleri.** "Bağlı değil / Bağlanıyor / Bağlı / Bağlanamadı" + nedeni ("Cloudflare yanıt vermedi", "Başka bir VPN açık olabilir"). | `ui/Strings.kt`, `ui/Model.kt` | ✅ "Model: durum metinleri ve geri bildirim" |
| 27 | **Tanılama günlüğü**: yalnızca bağlantı olayları; kopyala, paylaş, temizle. Sorgu adı **tutulmaz**. | `core/Format.kt` (`DiagLog`, `Journal`), `ui/Pages.kt` (`LogPage`) | ✅ "Tanılama günlüğü", "Ayarlar: ağ kuralları, günlük, yardım" |
| 28 | **"Nasıl çalışır?" sayfası**: DNS nedir, ne yapar, gizlilik, pil, bilmen gerekenler. | `ui/Pages.kt` (`HelpPage`), `ui/Strings.kt` | ✅ "Ayarlar: ağ kuralları, günlük, yardım" |
| 29 | **İlk açılış bilgilendirmesi** (Play'in VPN politikasının istediği açık bilgilendirme; kabul edilmeden bağlanılmaz). | `ui/Sheets.kt` (`ConsentContent`), `ui/Model.kt` (`acceptConsent`) | ✅ "Model: ilk açılış bilgilendirmesi", "Paneller: ilk açılış bilgilendirmesi" |
| 30 | **Gizlilik tasarımı**: hesap yok, reklam yok, analitik yok, sorgu kaydı yok, ağ erişimi yalnızca seçtiğin DNS sunucusuna. Gerçekçi not: DNS sorguları şifresiz (düz DNS) gider; bu yazılıdır. | tüm kod; `GIZLILIK.md` | ✅ günlük testleri; kod incelemesi (INTERNET izni dışında izin yok) |

## Tasarım ve kişiselleştirme

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 31 | **6 tema**: Aqua, Çimen, Okyanus, Gün batımı, Lavanta, Gece (hepsi cam yüzeyli, hepsi okunaklı). | `core/Themes.kt` | ✅ "Temalar", "Okunabilirlik (WCAG kontrast)", "AeroArt: tüm temalar…" |
| 32 | **Otomatik tema**: sistemin açık/koyu ayarını izler (Aqua ↔ Gece). | `core/Themes.kt` (`resolve`), `platform/MainActivity.kt` | ✅ "Tema geçişi" |
| 33 | **Cam şeffaflığı** kaydırıcısı; koyu temada otomatik dengelenir. | `core/Themes.kt` (`GlassMath`), `ui/SettingsWidgets.kt` (`SliderRow`) | ✅ "Ayarlar: cam kaydırıcısı" |
| 34 | **Kabarcık yoğunluğu**: kapalı / az / çok. | `core/Motion.kt` (`BubbleField`), `core/Settings.kt` | ✅ "Kabarcık alanı", "Ayarlar: açma, kontroller…" |
| 35 | **Animasyon düzeyi**: tam / az / kapalı; ayrıca sistemin "animasyonları kaldır" ayarına uyar. | `core/Settings.kt` (`Motion`), `platform/MainActivity.kt` (`applyConfig`) | ✅ "Hareket matematiği", "Kare planlaması (pil)"; 🔧 sistem ayarı |
| 36 | **Düşük güç modu**: tüm hareketi ve kabarcıkları kapatır. | `core/Settings.kt` (`effectiveMotion`) | ✅ "Kare planlaması (pil)" |
| 37 | **Dokunsal geri bildirim** (titreşim) aç/kapa; bağlanınca ve hatada güçlü, dokunuşlarda hafif. | `ui/Model.kt`, `platform/MainActivity.kt` (`haptic`) | ✅ "Model: durum metinleri ve geri bildirim"; 🔧 titreşim |
| 38 | **Sıvı küre ve akışkan tema geçişi**: küre suyla dolar/boşalır, hataya kırmızıya döner; tema değişince renkler akarak karışır. | `core/AeroArt.kt`, `core/Motion.kt` (`OrbMath`), `core/Themes.kt` (`AeroTheme.lerp`) | ✅ "AeroArt…", "Tema geçişi", "Hareket matematiği" |
| 39 | **Sayfa ve panel geçişleri**: sayfalar kayarak, paneller alttan yükselerek; geri hareketi uyumlu. | `ui/Scene.kt`, `ui/Sheets.kt`, `ui/Anim.kt` | ✅ "Gezinti ve geçişler" |
| 40 | **Erişilebilirlik**: TalkBack etiketleri, kaydırma ve kaydırıcı eylemleri, WCAG kontrast (≥ 4,5:1, her cam yoğunluğunda), 48 dp'ye yakın dokunma hedefleri, sistem yazı boyutu ölçeği, büyük yazıda kısalmayan başlıklar. | `ui/Scene.kt`, `platform/SceneView.kt`, `core/Themes.kt` | ✅ "Erişilebilirlik", "Okunabilirlik…", "Arayüz: dokunma hedefleri…"; 🔧 TalkBack sağlayıcısı |

## Sayılmayan ama olanlar

Bunlar özellikten çok kalite güvencesidir; 40'a dahil değildir.

- **Sıfır boşta tüketim.** Tünel okuyucu `poll()` ile bloklanır (paket yokken uyanmaz); ağ izleme sistem olayıyla çalışır;
  arayüz durağansa kare planlanmaz; zamanlayıcı ya da yoklama döngüsü yoktur. (✅ "Kare planlaması (pil)", "Performans ve bellek", "Kaynak temizliği"; 🔧 gerçek pil ölçümü)
- **Kare başına bellek ayırma ≤ 96 bayt** (durağan ekranda, kaydırırken ve süs animasyonlarında çizim yolu neredeyse ayırmasızdır).
  Tek seferlik kullanıcı eylemleri istisnadır ve ayrı bütçeyle sınanır: sayfa açma toplam ≈ 18 KB, tema değiştirme (0,6 sn'lik
  renk geçişi) toplam ≈ 0,6 MB. (✅ "Kare maliyeti: bellek ve çizim sayısı")
- **Dış bağımlılık yok.** Yalnızca Android çatısı + Kotlin standart kütüphanesi; sistem yazı tipi (APK'ya yazı tipi gömülmez).
- **Kenardan kenara, geniş ekran, tahmini geri.** İçerik geniş ekranda ortalanır; Android 13+ geri hareketi, yalnızca alt panel/sayfa açıkken uygulamaya aittir. (✅ düzen testleri; 🔧 Android bağlantısı)
- **Rastgele kullanım taraması** ("maymun"): yüzlerce rastgele dokunuş/ayar/boyut dizisiyle çökme ve tutarsızlık araması. (✅ "maymun: rastgele kullanım")
- **Sistem VPN ayarlarına kısayol** (Ayarlar → Bilgi).

## Bilinçli olarak yapılmayanlar (basit kalsın diye)

Özel DNS ekleme, DNS-over-HTTPS/TLS, uygulama bazlı ayırma, kendi engelleme listeleri, hesap/bulut, widget, çoklu dil.
Bunların hangisinin eklemeye değer olduğu `OKUBENI.md` → "Geliştirme önerileri" bölümünde sıralanmıştır.
