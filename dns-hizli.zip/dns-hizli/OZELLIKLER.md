# DNS Hızlı — 110 özellik, 12 dil, 12 tema

Arayüz bilerek tek bir ana ekran + bir ayarlar sayfasıdır; aşağıdaki 110 özelliğin çoğu görünmez çalışır ya da
tek bir kontrole bağlıdır. Hiçbiri ek ekran, hesap veya karmaşık ayar gerektirmez. 1–40 ilk sürümdür, 41–70 ikinci turda, 71–110 üçüncü turda
eklendi (en altta).

**Diller (12):** Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська. Varsayılan "Otomatik": telefonun
dilini izler, desteklenmiyorsa İngilizce. Ayarlar → Görünüm → Dil ile elle seçilir; Android 13+ sistemin "Uygulama dilleri"
ekranıyla da eşlenir. Tüm metinler `core/Tx*.kt` dosyalarındadır (dil başına bir dosya; eksik metin derlemeyi bozar, yani bir dil
yarım kalamaz). ✅ "Diller: eksiksiz ve tutarlı", "Diller: seçim ve biçimler", "Arayüz: her dilde ekranlar" (her dil × 360 ve
320 dp ekranda taşma/çakışma denetimi). Çeviriler makine değil elle yazıldı ama **anadili konuşan biri tarafından gözden
geçirilmedi**; yayından önce bir okutmak iyi olur.

**Doğrulama düzeyleri** (hangi özelliğe ne kadar güvenebileceğin açık yazılsın diye):

- ✅ **JVM testi**: bilgisayarda (Android olmadan) otomatik testle doğrulandı. Test grubunun adı yazılı.
- 🔧 **Android kodu**: Android'e özgü kısım (servis, tünel, bildirim, karo, erişilebilirlik sağlayıcısı…) yazıldı ve
  Android 34/35/36 API taslaklarına karşı **derlendi**, ama bir telefonda ya da emülatörde **çalıştırılmadı**.
  İlk gerçek cihaz denemesinde bunlara özellikle bak (bkz. `OKUBENI.md` → "İlk cihaz denemesi kontrol listesi").

Yollar `app/src/main/java/app/dnshizli/` altındadır. Test grupları `selftest/` içindedir; `./run-tests.sh` hepsini koşturur.

## Bağlantı ve çekirdek

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 1 | **Küreye dokun: bağlan / kes.** Tek dokunuş, tek kontrol. | `ui/Model.kt` (`tapOrb`), `ui/Widgets.kt` (`OrbBlock`) | ✅ "Model: bağlan / kes", "Ana ekran: küre ve satırlar" |
| 2 | **Yalnızca-DNS yerel VPN.** Sadece DNS adresine giden paketler tünele girer; diğer tüm trafik normal yolundan, dokunulmadan gider. | `platform/DnsVpnService.kt` (`establishTunnel`), `core/Packets.kt` | ✅ paket/yönlendirici testleri; 🔧 tünel kurulumu |
| 3 | **Hazır katalog** (şimdi 26 sunucu, bkz. #50): Cloudflare, Google, Quad9, AdGuard, Control D, OpenDNS, Mullvad, DNS.SB, DNS4EU, UncensoredDNS, CleanBrowsing… (hızlı, gizlilik, reklam, aile, güvenlik). Kullanıcı sunucu **ekleyemez** (bilinçli). | `core/Catalog.kt`, `tools/catalog_check.py` | ✅ "Katalog"; adresleri canlı doğrulamak için aracı **kendi ağında** çalıştır |
| 4 | **Satıra dokun: bağlan.** Bağlıyken başka satıra dokunmak sunucuyu değiştirir. | `ui/Model.kt` (`tapServer`) | ✅ "Model: bağlan / kes", "Ana ekran: küre ve satırlar" |
| 5 | **Kesintisiz sunucu değiştirme.** Tünel kopmaz; yeni sunucu cevap vermezse eskisi korunur ve neden bildirilir. | `platform/DnsVpnService.kt` (`switchServer`), `core/Format.kt` (`ConnectionCheck`) | ✅ "Bağlantı testi", çift dokunma koruması; 🔧 servis akışı |
| 6 | **Otomatik yedek sunucu.** Birincil art arda cevapsız kalıp ikincil cevap verirse kalıcı olarak ikinciye geçer; ağ değişince birinciye döner. | `core/DnsForwarder.kt` | ✅ "Yönlendirici: yedek sunucu…", "…kalıcı yedek geçişi" |
| 7 | **DNS önbelleği, 4 seviye** (kapalı / küçük / normal / büyük). Cevap süresine (TTL) uyar; aynı sorgu ağa gitmeden cevaplanır. | `core/DnsCache.kt`, `core/LongCache.kt`, `core/DnsForwarder.kt` | ✅ "Önbellek", "DNS TTL ayrıştırma", "Yönlendirici: önbellek", "LongCache" |
| 8 | **Ağ değişince yenile.** Wi-Fi ↔ mobil geçişinde bekleyen sorgular ve soket yenilenir; sistem olayıyla çalışır, yoklama yok. | `platform/NetworkWatcher.kt`, `core/DnsForwarder.kt` (`resetNetwork`) | ✅ "Ağ değişimi: soket yenileme"; 🔧 `NetworkWatcher` |
| 9 | **Bağlantı doğrulama.** Bağlanınca sistemin kendi çözümleyicisiyle rastgele bir ad çözdürüp sorgunun gerçekten seçilen sunucudan döndüğü doğrulanır; cevapsız sunucuyla internet kesilmez. | `core/Format.kt` (`ConnectionCheck`), `platform/DnsVpnService.kt` (`verify`) | ✅ "Bağlantı testi"; 🔧 servis |
| 10 | **Ağa göre sunucu.** Wi-Fi'de bir sunucu, mobil veride başka bir sunucu (ya da "otomatik"). | `core/Format.kt` (`Rules`), `ui/Pages.kt` (`SettingsPage`), `ui/Sheets.kt` (`ChoiceContent`) | ✅ "Ağa göre DNS", "Ayarlar: ağ kuralları…"; 🔧 uygulaması |
| 11 | **Son sunucuyu hatırla.** Kürenin altında hep "X seçili" yazar. | `core/Settings.kt` (`lastServer`) | ✅ "Ayarlar", "Model: bağlan / kes" |
| 12 | **Kendiliğinden yeniden bağlanma.** Sistem işlemi bellek için öldürürse servis yeniden başlar ve bağlı kalır. | `platform/DnsVpnService.kt` (`START_STICKY`, `wasActive`) | 🔧 |

## Sunucu listesi

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 13 | **Hız ölçümü**, hepsi ya da tek sunucu (gerçek DNS sorgusu, ms). Sonuçlar saklanır. | `core/DnsProbe.kt`, `ui/Model.kt` (`measure`) | ✅ "Gecikme ölçümü", "Model: hız ölçümü" |
| 14 | **En hıza bağlan.** Ölçüm bitince "En hızlı: X · 12 ms" mesajındaki "Bağlan" ile tek dokunuş. | `ui/Model.kt` (`connectFastest`), `core/ServerList.kt` | ✅ "Model: hız ölçümü", "Sunucu listesi" |
| 15 | **Hıza göre sırala.** | `core/ServerList.kt` | ✅ "Sunucu listesi", "Model: liste, favori, sıralama" |
| 16 | **Favoriler** (yıldız) ve "Favoriler" süzgeci. | `ui/Model.kt` (`toggleFavorite`), `ui/Widgets.kt` (`StarButton`) | ✅ "Model: liste, favori, sıralama" |
| 17 | **Kategori süzgeçleri**: Hızlı, Gizlilik, Reklam, Aile, Güvenlik. | `ui/Model.kt` (`Filter`), `ui/Pages.kt` (`ChipsRow`) | ✅ "Model: liste, favori, sıralama", "Ana ekran: süzgeç, sıralama, ölçüm" |
| 18 | **Sunucu ayrıntıları** (satıra uzun bas): adresleri kopyala, bu sunucuya bağlan/geç, favori yap, tek ölç. | `ui/Sheets.kt` (`DetailsContent`) | ✅ "Paneller: ayrıntı" |

## Sistemle bütünleşme

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 19 | **Uygulama açılınca bağlan** (isteğe bağlı). | `platform/MainActivity.kt` (`handleIntent`) | ✅ ayar anahtarı; 🔧 açılışta bağlanma |
| 20 | **Telefon açılınca bağlan** (isteğe bağlı) ve uygulama güncellenince açıksa devam. | `platform/BootReceiver.kt` | ✅ ayar anahtarı; 🔧 alıcı |
| 21 | **Hızlı ayarlar kutucuğu**: panelden bağlan/kes; izin ya da ilk bilgilendirme yoksa uygulamayı açar. Yalnızca panel görünürken dinler. | `platform/DnsTileService.kt` | 🔧 |
| 22 | **Bildirimde "Kes"** düğmesi; bildirim yalnızca bağlıyken vardır (Android önplan servisi için zorunlu tutar). | `platform/Notifier.kt` | 🔧 |
| 23 | **Uygulama kısayolları**: simgeye uzun bas → Bağlan / Kes. | `res/xml/shortcuts.xml`, `platform/MainActivity.kt` | 🔧 (XML biçimi doğrulandı) |

## Bilgi ve şeffaflık

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 24 | **Canlı istatistik**: süre · sorgu sayısı · önbellek yüzdesi, ortalama yanıt süresi (ms). | `ui/Model.kt` (`statusHint`), `core/DnsForwarder.kt` (`Stats`) | ✅ "Model: durum metinleri…", "İstatistik: ortalama yanıt süresi" |
| 25 | **Kalıcı toplamlar**: toplam sorgu, önbellekten yanıt, bağlı kalma süresi. | `platform/PrefsStore.kt` (`addTotals`), `ui/Pages.kt` | ✅ "Ayarlar" (kodlama); 🔧 servisten aktarım |
| 26 | **Açık durum ve hata metinleri.** "Bağlı değil / Bağlanıyor / Bağlı / Bağlanamadı" + nedeni ("Cloudflare yanıt vermedi", "Başka bir VPN açık olabilir"). | `ui/Strings.kt`, `ui/Model.kt` | ✅ "Model: durum metinleri ve geri bildirim" |
| 27 | **Tanılama günlüğü**: yalnızca bağlantı olayları; kopyala, paylaş, temizle. Sorgu adı **tutulmaz**. | `core/Format.kt` (`DiagLog`, `Journal`), `ui/Pages.kt` (`LogPage`) | ✅ "Tanılama günlüğü", "Ayarlar: ağ kuralları, günlük, yardım" |
| 28 | **"Nasıl çalışır?" sayfası**: DNS nedir, ne yapar, gizlilik, pil, bilmen gerekenler. | `ui/Pages.kt` (`HelpPage`), `ui/Strings.kt` | ✅ "Ayarlar: ağ kuralları, günlük, yardım" |
| 29 | **İlk açılış bilgilendirmesi** (Play'in VPN politikasının istediği açık bilgilendirme; kabul edilmeden bağlanılmaz). | `ui/Sheets.kt` (`ConsentContent`), `ui/Model.kt` (`acceptConsent`) | ✅ "Model: ilk açılış bilgilendirmesi", "Paneller: ilk açılış bilgilendirmesi" |
| 30 | **Gizlilik tasarımı**: hesap yok, reklam yok, analitik yok, sorgu kaydı yok, ağ erişimi yalnızca seçtiğin DNS sağlayıcısına. Sorgular artık varsayılan olarak şifreli gider (#41–43); şifre kapatılırsa düz DNS, bu açıkça yazılır. | tüm kod; `GIZLILIK.md` | ✅ günlük testleri; kod incelemesi (INTERNET izni dışında izin yok) |

## Tasarım ve kişiselleştirme

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 31 | **Temalar**: Aqua, Çimen, Okyanus, Gün batımı, Lavanta, Gece (+ #57–58 ile Mercan, Nane, AMOLED = 9; hepsi cam yüzeyli, hepsi okunaklı). | `core/Themes.kt` | ✅ "Temalar", "Okunabilirlik (WCAG kontrast)", "AeroArt: tüm temalar…" |
| 32 | **Otomatik tema**: sistemin açık/koyu ayarını izler (Aqua ↔ Gece). | `core/Themes.kt` (`resolve`), `platform/MainActivity.kt` | ✅ "Tema geçişi" |
| 33 | **Cam şeffaflığı** kaydırıcısı; koyu temada otomatik dengelenir. | `core/Themes.kt` (`GlassMath`), `ui/SettingsWidgets.kt` (`SliderRow`) | ✅ "Ayarlar: cam kaydırıcısı" |
| 34 | **Kabarcık yoğunluğu**: kapalı / az / çok. | `core/Motion.kt` (`BubbleField`), `core/Settings.kt` | ✅ "Kabarcık alanı", "Ayarlar: açma, kontroller…" |
| 35 | **Animasyon düzeyi**: tam / az / kapalı; ayrıca sistemin "animasyonları kaldır" ayarına uyar. | `core/Settings.kt` (`Motion`), `platform/MainActivity.kt` (`applyConfig`) | ✅ "Hareket matematiği", "Kare planlaması (pil)"; 🔧 sistem ayarı |
| 36 | **Düşük güç modu**: tüm hareketi ve kabarcıkları kapatır. | `core/Settings.kt` (`effectiveMotion`) | ✅ "Kare planlaması (pil)" |
| 37 | **Dokunsal geri bildirim** (titreşim) aç/kapa; bağlanınca ve hatada güçlü, dokunuşlarda hafif. | `ui/Model.kt`, `platform/MainActivity.kt` (`haptic`) | ✅ "Model: durum metinleri ve geri bildirim"; 🔧 titreşim |
| 38 | **Sıvı küre ve akışkan tema geçişi**: küre suyla dolar/boşalır, hataya kırmızıya döner; tema değişince renkler akarak karışır. | `core/AeroArt.kt`, `core/Motion.kt` (`OrbMath`), `core/Themes.kt` (`AeroTheme.lerp`) | ✅ "AeroArt…", "Tema geçişi", "Hareket matematiği" |
| 39 | **Sayfa ve panel geçişleri**: sayfalar kayarak, paneller alttan yükselerek; geri hareketi uyumlu. | `ui/Scene.kt`, `ui/Sheets.kt`, `ui/Anim.kt` | ✅ "Gezinti ve geçişler" |
| 40 | **Erişilebilirlik**: TalkBack etiketleri, kaydırma ve kaydırıcı eylemleri, WCAG kontrast (≥ 4,5:1, her cam yoğunluğunda), 48 dp'ye yakın dokunma hedefleri, sistem yazı boyutu ölçeği, büyük yazıda kısalmayan başlıklar. | `ui/Scene.kt`, `platform/SceneView.kt`, `core/Themes.kt` | ✅ "Erişilebilirlik", "Okunabilirlik…", "Arayüz: dokunma hedefleri…"; 🔧 TalkBack sağlayıcısı |

## Sayılmayan ama olanlar

Bunlar özellikten çok kalite güvencesidir; 70'e dahil değildir.

- **Büyük cevaplar artık parçalanıyor** (IP parçalama): 1500 baytı aşan DNS cevapları (DNSSEC, uzun TXT) önceden sorun
  çıkarabiliyordu. (✅ "Büyük cevaplar: IP parçalama")
- **IPv6 trafiği engellenmiyor**: tünel yalnızca IPv4 DNS adresini yakalar ama IPv6 trafiğini de serbest bırakır.
- **Android "Özel DNS" tespiti**: telefonda belirli bir sunucuya sabitlenmiş Özel DNS varsa bağlanırken açıkça uyarılır (bu durumda
  uygulamanın seçtiği sunucu kullanılmaz).
- **Sıfır boşta tüketim.** Tünel okuyucu `poll()` ile bloklanır (paket yokken uyanmaz); ağ izleme sistem olayıyla çalışır;
  arayüz durağansa kare planlanmaz; zamanlayıcı ya da yoklama döngüsü yoktur. (✅ "Kare planlaması (pil)", "Performans ve bellek", "Kaynak temizliği"; 🔧 gerçek pil ölçümü)
- **Kare başına bellek ayırma ≤ 96 bayt** (durağan ekranda, kaydırırken ve süs animasyonlarında çizim yolu neredeyse ayırmasızdır).
  Tek seferlik kullanıcı eylemleri istisnadır ve ayrı bütçeyle sınanır: sayfa açma toplam ≈ 18 KB, tema değiştirme (0,6 sn'lik
  renk geçişi) toplam ≈ 0,6 MB. (✅ "Kare maliyeti: bellek ve çizim sayısı")
- **Dış bağımlılık yok.** Yalnızca Android çatısı + Kotlin standart kütüphanesi; sistem yazı tipi (APK'ya yazı tipi gömülmez).
- **Kenardan kenara, geniş ekran, tahmini geri.** İçerik geniş ekranda ortalanır; Android 13+ geri hareketi, yalnızca alt panel/sayfa açıkken uygulamaya aittir. (✅ düzen testleri; 🔧 Android bağlantısı)
- **Rastgele kullanım taraması** ("maymun"): yüzlerce rastgele dokunuş/ayar/boyut dizisiyle çökme ve tutarsızlık araması. (✅ "maymun: rastgele kullanım")
- **Sistem VPN ayarlarına kısayol** (Ayarlar → Bilgi).

## Yeni 30 özellik (41–70)

### Şifreli DNS ve bağlantı

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 41 | **DNS-over-TLS (DoT)**: sorgular 853. porttan TLS ile, sertifika adı doğrulanarak gider; ağ yakalamasını aşar. | `core/SecureForwarder.kt` | ✅ "Şifreli DNS: DoT (yerel TLS sunucusu)", "…sertifika doğrulama" |
| 42 | **DNS-over-HTTPS (DoH)**: 443 üzerinden HTTPS POST (RFC 8484); DoT'un engellendiği ağlarda da çalışır. | `core/SecureForwarder.kt` | ✅ "Şifreli DNS: DoH (HTTP/1.1)" |
| 43 | **Şifreleme seçimi**: Otomatik (DoT → DoH → düz) / yalnız DoT / yalnız DoH / kapalı. Otomatik modda biri çalışmazsa sıradaki denenir. | `core/Catalog.kt` (`Encryption.plan`), `platform/DnsVpnService.kt` | ✅ "Şifreleme planı ve katalog", "Model: şifreleme tercihi"; 🔧 servis döngüsü |
| 44 | **Protokol her yerde görünür**: durum satırı, bildirim, widget ve ayrıntı paneli "DoT/DoH/Düz" yazar. | `core/Lang.kt` (`onLine`), `platform/Notifier.kt` | ✅ "Arayüz: ayrıntı paneli yenilikleri" |
| 45 | **Engellenen sorgu sayacı** (tahmini): reklam/aile sunucularının engellediği adlar sayılır (0.0.0.0 / :: ya da EDE 15–18 cevapları). | `core/Packets.kt` (`Dns.isBlocked`), `core/DnsForwarder.kt` | ✅ "Engelleme tahmini ve A kayıtları" |
| 46 | **Önbelleği temizle** düğmesi (Ayarlar → Gizlilik). | `ui/Model.kt` (`clearCache`), `platform/DnsVpnService.kt` | ✅ "Model: duraklatma, önbellek, dil"; 🔧 servis |
| 47 | **Ayrıntılı ölçüm**: en iyi, ortanca ve kayıp yüzdesi (tek sayı yerine). Şifreli sunucularda DoT ile ölçülür. | `core/DnsProbe.kt` (`ProbeResult`, `probeTls`) | ✅ "İlk çözümleme ve gecikme ölçümü" |
| 48 | **Ölçüm geçmişi grafiği** (son 12 ölçüm) ayrıntı panelinde. | `core/ServerList.kt` (`LatencyHistory`), `ui/Sheets.kt` (`HistoryChart`) | ✅ "Arayüz: ayrıntı paneli yenilikleri" |
| 49 | **En hızlıya bağlan** seçeneği: küreye dokununca son ölçüme göre en hızlı sunucu seçilir. | `ui/Model.kt`, `core/ServerList.kt` (`fastest`) | ✅ "Model: gizleme, son kullanılanlar, en hızlı" |
| 50 | **Genişletilmiş katalog: 26 sunucu.** DNS4EU (açık, reklamsız, çocuk) ve Mullvad varyantları eklendi; Mullvad yalnızca şifreli çalıştığı için düz DNS'e zorlanmaz; artık çalışmayan Verisign ve Alternate çıkarıldı. | `core/Catalog.kt`, `tools/catalog_check.py` (DoT denetimi de eklendi) | ✅ "Şifreleme planı ve katalog"; canlı doğrulama kendi ağında |

### Liste ve kullanım

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 51 | **"Son kullanılanlar" süzgeci** (son 5 sunucu). | `core/Settings.kt` (`withRecent`), `ui/Model.kt` | ✅ "Model: gizleme, son kullanılanlar, en hızlı" |
| 52 | **Sunucu gizle** (ayrıntı panelinden) + "Geri al"; Ayarlar → Liste → Gizlenenler'den geri getirilir. | `ui/Model.kt` (`hide/unhide`), `ui/Sheets.kt` | ✅ aynı grup |
| 53 | **Çekerek ölç**: listeyi aşağı çekip bırakınca tüm sunucular ölçülür. | `ui/Anim.kt` (`Scroller`), `ui/Node.kt` | ✅ "Arayüz: çekerek ölçme, sıkı liste, sade görünüm" |
| 54 | **Hızlı seçim**: küreye uzun bas → favoriler/son kullanılanlar + duraklat. | `ui/Sheets.kt` (`QuickContent`), `ui/Scene.kt` | ✅ "Arayüz: hızlı seçim ve duraklatma" |
| 55 | **Duraklat 5 / 15 / 60 dk**; süre bitince kendiliğinden devam eder (telefon uykudayken de). | `platform/DnsVpnService.kt` (AlarmManager), `ui/Model.kt` (`pause`) | ✅ "Model: duraklatma, önbellek, dil"; 🔧 alarm |
| 56 | **Sıkı liste**: daha kısa satırlar, açıklamasız; küçük ekranlar için. | `ui/Widgets.kt` (`ServerRow`) | ✅ "Arayüz: çekerek ölçme, sıkı liste, sade görünüm" |

### Görünüm ve erişilebilirlik

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 57 | **AMOLED teması**: tam siyah zemin (OLED ekranda pil dostu). | `core/Themes.kt` | ✅ "Temalar", "Okunabilirlik (WCAG kontrast)" |
| 58 | **Mercan ve Nane temaları**. | `core/Themes.kt` | ✅ aynı gruplar |
| 59 | **Uygulama içi yazı boyutu** (%90 / %100 / %115 / %130), sistem ölçeğiyle birlikte sınırlanır. | `core/Settings.kt` (`TextScale`), `ui/Scene.kt` | ✅ "Arayüz: ayarlarda yeni bölümler" |
| 60 | **Zamanlanmış gece teması**: Otomatik temada 22:00–07:00 arası Gece teması. | `core/Themes.kt` (`isNightHour`), `ui/Scene.kt` | ✅ "Tema geçişi" |
| 61 | **Yüksek kontrast**: daha koyu yazı, opak cam. | `core/Themes.kt` (`highContrast`) | ✅ "Okunabilirlik…", "Arayüz: ayarlarda yeni bölümler" |
| 62 | **Sade görünüm**: süzgeç çipleri ve istatistik satırı gizlenir; yalnızca küre ve liste. | `ui/Pages.kt` (`HomePage`) | ✅ "Model: dışa/içe aktarma, sıfırlama, sade görünüm" |

### Sistem, bildirim, veri

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 63 | **Ana ekran widget'ı**: tek dokunuşla bağlan/kes, sunucu ve protokol yazar. | `platform/DnsWidget.kt`, `res/layout/widget_dns.xml` | 🔧 (kaynaklar aapt2 ile doğrulandı) |
| 64 | **Bildirimde canlı süre ve "Sonraki"** düğmesi (favoriler/son kullanılanlar arasında geçer). | `platform/Notifier.kt` | 🔧 |
| 65 | **Kopma uyarısı**: bağlantı beklenmedik koparsa "Yeniden bağlan" düğmeli bildirim (isteğe bağlı). | `platform/Notifier.kt` (`drop`) | 🔧 |
| 66 | **12 dil + Android 13 uygulama başına dil** (bkz. en üst). | `core/Lang.kt`, `core/Tx*.kt`, `platform/App.kt`, `res/xml/locales_config.xml` | ✅ dil grupları; 🔧 sistem eşlemesi |
| 67 | **Ayarları dışa/içe aktar** (panoya kısa bir metin; yeni telefona taşımak için). | `core/Settings.kt` (`SettingsCodec.export/import`) | ✅ "Yeni ayarlar, dışa/içe aktarma, günlük sayılar" |
| 68 | **Ayarları / istatistikleri sıfırla** (onaylı). | `ui/Model.kt` | ✅ "Model: dışa/içe aktarma, sıfırlama, sade görünüm" |
| 69 | **Haftalık grafik**: son 7 günün sorgu sayısı. | `core/Settings.kt` (`DailyStats`), `ui/SettingsWidgets.kt` (`WeekChart`) | ✅ "Yeni ayarlar…", "Arayüz: ayarlarda yeni bölümler" |
| 70 | **Paylaş / puan ver / geri bildirim** (Ayarlar → Bilgi). | `platform/MainActivity.kt` | 🔧 |

## 3. tur: 71–110 (güvenlik, sağlamlık, tema, dil)

Bu turda ayrıca bir sızma-testi bakışıyla bulunan 10 açık ve 15 hata kapatıldı (aşağıda "Kapatılan bulgular").
Doğrulama: ✅ = JVM testi (grup adı: `core`, `secure`, `harden`, `model`, `ui`, `gfx`, `monkey`), 🔧 = Android'e özgü, derlendi ama
cihazda çalıştırılmadı.

### Güvenlik ve bağlantı (71–82)

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 71 | **Sahte cevap koruması**: cevabın soru bölümü sorguyla bire bir karşılaştırılır (RFC 5452); uymayan cevap atılır. | `core/Packets.kt` (`Dns.sameQuestion`), `core/DnsForwarder.kt` | ✅ `harden` |
| 72 | **Kaynak portu döndürme**: 2 soket, her biri 64 kullanımda yeni rastgele porta geçer; aynı anda yalnızca biri boşalır. | `core/DnsForwarder.kt` | ✅ `harden` |
| 73 | **Özdeş soruların birleştirilmesi**: aynı anda aynı soru tek sunucu sorgusuna iner, cevap herkese dağıtılır (en çok 16 bekleyen). | `core/DnsForwarder.kt`, `core/SecureForwarder.kt` | ✅ `harden`, `secure` |
| 74 | **Yavaş ad şeridi kilitlemez**: şifreli bağlantıda yük şeritleri (normalde 4, yük altında 12); damlatan sunucu bir şeridi tutamaz. | `core/SecureForwarder.kt` | ✅ `secure` |
| 75 | **Şifresize düşünce uyarı + otomatik dönüş**: bildirim gelir, uygulama ağ değişiminde ve her 10 dakikada şifreliyi yeniden dener. | `platform/DnsVpnService.kt`, `platform/Notifier.kt` | ✅ planlama (`secure`); 🔧 servis |
| 76 | **Sıkı şifreleme**: açıksa asla düz DNS'e düşülmez; şifreli kurulamazsa bağlanmaz. | `core/Catalog.kt` (`Encryption.plan`) | ✅ `secure` |
| 77 | **Kendiliğinden yeniden bağlanma**: kopunca 5 sn / 30 sn / 2 dk sonra dener; açılış, güncelleme ve duraklatma sonu bağlanmaları da. | `platform/DnsVpnService.kt` | 🔧 |
| 78 | **Yedek sunucu**: Kapalı / Otomatik / En hızlı; seçilen sunucu yanıt vermezse geçer ve bildirir. | `platform/DnsVpnService.kt`, `core/Settings.kt` | ✅ `model`; 🔧 servis |
| 79 | **Bağlantı testi**: tünelin içinden gerçek sorular (rastgele ad, DNSSEC hatalı ad, bilinen reklam adı); DNS çalışıyor mu, kaç ms, DNSSEC doğrulanıyor mu, reklam engelleniyor mu. | `core/SelfTest.kt`, `ui/Sheets.kt` | ✅ `core`, `ui`; 🔧 tünele enjeksiyon |
| 80 | **Sağlamlaştırılmış DoH/DoT ayrıştırıcı**: parça boyutu doğrulama, en çok 64 başlık satırı, her bayta zaman sınırı, durum satırı denetimi. | `core/SecureForwarder.kt` | ✅ `harden`, `secure` (bozuk/damlatan sunucu) |
| 81 | **UDP sağlama toplamı, IP kimliği, TC bayrağı**: tünel cevaplarının hepsi sağlama toplamlı; büyük cevap kesilirse TC işaretlenir. | `core/Packets.kt` | ✅ `harden`, `secure` |
| 82 | **Önbellek bellek bütçesi ve TTL yaşlandırma**: kayıt başına 8 KB sınır, toplam bütçe; cevaptaki TTL'ler beklenen süreyle azalır. | `core/DnsCache.kt` | ✅ `harden`, `core` |

### Liste ve ölçüm (83–92)

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 83 | **"Şifreli" süzgeci**: yalnızca DoT/DoH destekleyen sunucular. | `ui/Model.kt`, `core/ServerList.kt` | ✅ `model`, `ui` |
| 84 | **"Süzgeçsiz" süzgeci**: engelleme yapmayan sunucular. | aynı | ✅ aynı |
| 85 | **Üç sıralama**: Varsayılan / Hız / Ad (sıralama düğmesine dokunarak döner). | `core/ServerList.kt`, `core/Settings.kt` (`SortMode`) | ✅ `model` |
| 86 | **Son süzgeci hatırla**. | `ui/Model.kt` | ✅ `model` |
| 87 | **Açılışta otomatik ölç** (son ölçüm bir günden eskiyse). | `ui/Model.kt` (`onStart`) | ✅ `model` |
| 88 | **Şifreli ölçüm**: hız DoT üzerinden ölçülür (gerçek kullanıma yakın). | `platform/MainActivity.kt` | ✅ `secure`; 🔧 |
| 89 | **"Bana uygun sunucu" önerisi**: ölçümler ve ayarlardan en uygununu önerir. | `core/ServerList.kt` (`recommend`), `ui/Sheets.kt` | ✅ `core`, `ui` |
| 90 | **Satırda kilit rozeti**: şifreli sunucular bir bakışta görünür (erişilebilirlik metninde de). | `ui/Widgets.kt` | ✅ `ui` |
| 91 | **Renkli sinyal çubukları**: yanıt süresine göre yeşilden kırmızıya. | `core/AeroArt.kt`, `ui/Widgets.kt` | ✅ `gfx`, `ui` |
| 92 | **Ölçüm geçmişini temizle**. | `ui/Model.kt` | ✅ `model` |

### Bildirim, widget, kısayol (93–100)

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 93 | **Kilit ekranında gizle**: sunucu adı kilit ekranı bildiriminde görünmez. | `platform/Notifier.kt` | 🔧 |
| 94 | **Sessiz bildirim**: durum çubuğu simgesi yok, sessiz kanal. | `platform/Notifier.kt` | 🔧 |
| 95 | **Bildirimde "15 dk duraklat"** düğmesi; duraklatınca geri sayım. | `platform/Notifier.kt`, `platform/ActionReceiver.kt` | 🔧 |
| 96 | **Kesmeden önce sor** (yanlışlıkla dokunmaya karşı). | `ui/Model.kt` | ✅ `model` |
| 97 | **Widget'ta bugünkü sorgu sayısı**. | `platform/DnsWidget.kt` | 🔧 |
| 98 | **Duraklat kısayolu** (simgeye uzun basınca). | `res/xml/shortcuts.xml` | 🔧 |
| 99 | **Düğmeler izin denetimli alıcıdan geçer**: VPN izni geri alınmışsa servis çökmez, kullanıcı uygulamayı açmaya çağrılır. | `platform/ActionReceiver.kt` | 🔧 |
| 100 | **Dışa kapalı dahili başlatıcı**: bildirim/kutucuk/widget yalnızca uygulamanın kendi `activity-alias`'ı üzerinden açar; dışarıdan gelen kes isteği onay sorar. | `AndroidManifest.xml`, `platform/MainActivity.kt` | 🔧 |

### Görünüm (101–105)

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 101–103 | **3 yeni tema: Sakura (pembe), Bal (amber), Kuzey ışığı (koyu).** Toplam 12 tema. | `core/Themes.kt` | ✅ "Temalar", "Okunabilirlik (WCAG kontrast)" |
| 104 | **Duvar kâğıdı teması** (Android 12+): sistem vurgu renginden tema üretilir; kontrast her tohum için denetlenir (4000 rastgele tohumla sınandı). | `core/Themes.kt` (`fromSeed`), `platform/MainActivity.kt` | ✅ `core`, `ui`; 🔧 sistem rengi |
| 105 | **Otomatik açık/koyu seçimi ve gece saati ön ayarları** (22–07, 21–06, 23–08, 20–06). | `core/Settings.kt`, `ui/Scene.kt` | ✅ `model`, `ui` |

### İstatistik ve veri (106–110)

| # | Özellik | Kodda | Doğrulama |
|---|---------|-------|-----------|
| 106 | **Bağlantı geçmişi**: son 30 oturum (sunucu, yöntem, süre, sorgu, bitiş nedeni); sorgu adı tutulmaz. | `core/Settings.kt` (`SessionLog`), `ui/Pages.kt` | ✅ `core`, `ui` |
| 107 | **Sunucu başına kullanım süresi** (en çok kullanılan 3). | `core/Settings.kt` (`UsageStats`) | ✅ `core` |
| 108 | **Veri trafiği** (gönderilen / alınan DNS baytı). | `core/DnsForwarder.kt`, `core/Format.kt` | ✅ `harden`, `core` |
| 109 | **Ortalama yanıt süresi ve "kazanılan süre"** tahmini. | `core/Settings.kt` | ✅ `core` |
| 110 | **"Neler yeni?" sayfası** ve tanılama raporuna son çökmenin kısa özeti. | `ui/Pages.kt`, `platform/App.kt` | ✅ `ui`; 🔧 |

### Kapatılan bulgular (sızma testi / hata avı)

Güvenlik: sahte cevap (soru denetimi yoktu), tahmin edilebilir port, IP kimliği tekrarı, sağlama toplamsız cevap, DoH ayrıştırıcıda
sınırsız parça/başlık/zaman, önbellekte sınırsız büyüme, önyükleme cevabının doğrulanmaması, `QUICKBOOT` yayınının taklidi,
dışarıdan tetiklenebilen bildirim eylemleri, yedeklemeyle ayar sızması (`dataExtractionRules`, `network_security_config`).
Hata: erişilebilirlik denetiminin sıklığı, Geri'nin boşta görünmemesi, intent tekrarı, duraklatmanın güvenilirliği, ilk protokolün
doğrulanmaması, istatistik yazımının kaybı, "Sonraki"nin eski arayüz durumu, forwarder sızıntısı, ayar değişiminin uygulanmaması,
önbellek TTL, ayar dosyası yarışı, dil taşıması, boş liste iletisi; ayrıca bağımsız incelemede bulunan: açılışta bağlanma
başarısızsa yeniden denenmemesi, duraklatılmışken iptal edilen izinde asılı kalan servis, oturum yöntemi kaydı.

## Bilinçli olarak yapılmayanlar (basit kalsın diye)

Özel DNS ekleme, uygulama bazlı ayırma, kendi engelleme listeleri, hesap/bulut.
