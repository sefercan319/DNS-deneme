package app.dnshizli.core

/** Ekranda gösterilen sayı ve süre biçimleri (Türkçe). Yerel ayardan bağımsız, elle biçimlenir. */
object Format {
    private fun pad2(n: Long): String = if (n < 10) "0$n" else "$n"

    /** 754 -> "12:34", 3725 -> "1:02:05". */
    fun clock(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "$h:${pad2(m)}:${pad2(sec)}" else "${pad2(m)}:${pad2(sec)}"
    }

    /** Uzun süreler: 45 -> "45 sn", 600 -> "10 dk", 7500 -> "2 sa 5 dk", 200000 -> "2 gün 7 sa". */
    fun span(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0)
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        return when {
            d > 0 -> if (h > 0) "$d gün $h sa" else "$d gün"
            h > 0 -> if (m > 0) "$h sa $m dk" else "$h sa"
            m > 0 -> "$m dk"
            else -> "$s sn"
        }
    }

    /** 950 -> "950", 1250 -> "1,2 bin", 48000 -> "48 bin", 3400000 -> "3,4 mn". */
    fun count(n: Long): String = when {
        n < 1000 -> "$n"
        n < 10_000 -> "${n / 1000},${(n % 1000) / 100} bin"
        n < 1_000_000 -> "${n / 1000} bin"
        n < 10_000_000 -> "${n / 1_000_000},${(n % 1_000_000) / 100_000} mn"
        else -> "${n / 1_000_000} mn"
    }

    fun ms(n: Int): String = "$n ms"

    /** Geçen süreyi "az önce", "5 dk önce", "3 sa önce", "2 gün önce" olarak yazar. */
    fun ago(deltaMs: Long): String {
        val s = deltaMs.coerceAtLeast(0) / 1000
        return when {
            s < 45 -> "az önce"
            s < 90 * 60 -> "${maxOf(1L, (s + 30) / 60)} dk önce"
            s < 36 * 3600 -> "${(s + 1800) / 3600} sa önce"
            else -> "${(s + 43200) / 86400} gün önce"
        }
    }
}

/** Küçük, iş parçacığı güvenli halka tampon: son olayları saklar. Kullanıcı yardım ekranından kopyalayabilir. */
class DiagLog(private val capacity: Int = 120, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val lines = ArrayDeque<Pair<Long, String>>()

    @Synchronized
    fun add(msg: String) {
        if (lines.size >= capacity) lines.removeFirst()
        lines.addLast(clock() to msg)
    }

    @Synchronized
    fun size(): Int = lines.size

    @Synchronized
    fun clear() = lines.clear()

    /** Her satır: "SS:DD:SN mesaj" (cihazın yerel saatiyle), en eski üstte. */
    @Synchronized
    fun dump(): String {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT)
        return lines.joinToString("\n") { (t, m) -> fmt.format(java.util.Date(t)) + " " + m }
    }
}

/** Uygulama genelinde tek günlük. Sorgu adı veya kişisel veri asla yazılmaz. */
object Journal {
    val log = DiagLog()
    fun add(msg: String) = log.add(msg)
}

enum class NetKind { WIFI, MOBILE, ETHERNET, OTHER, NONE }

data class NetInfo(val wifi: Boolean, val cellular: Boolean, val ethernet: Boolean, val validated: Boolean)

/** "Ağa göre DNS" kuralları. Saf fonksiyonlar: kolayca test edilir. */
object Rules {
    /** Bağlı fiziksel ağlardan hangisinin kullanıldığını seçer (doğrulanmış Wi-Fi > Ethernet > mobil). */
    fun pick(nets: List<NetInfo>): NetKind {
        val usable = nets.filter { it.validated }.ifEmpty { nets }
        return when {
            usable.any { it.wifi } -> NetKind.WIFI
            usable.any { it.ethernet } -> NetKind.ETHERNET
            usable.any { it.cellular } -> NetKind.MOBILE
            usable.isNotEmpty() -> NetKind.OTHER
            else -> NetKind.NONE
        }
    }

    /** Bu ağ türü için kullanıcı özel bir sunucu atamış mı? */
    fun ruleFor(s: AppSettings, kind: NetKind): String? = when (kind) {
        NetKind.WIFI -> s.wifiServer
        NetKind.MOBILE -> s.mobileServer
        else -> null
    }

    /** Bağlanılacak ilk sunucu: ağ kuralı, yoksa son kullanılan, yoksa varsayılan. */
    fun initialServer(s: AppSettings, kind: NetKind): String =
        ruleFor(s, kind) ?: s.lastServer ?: Catalog.DEFAULT_ID
}

sealed class CheckResult {
    data class Ok(val ms: Int) : CheckResult()
    object NoAnswer : CheckResult()
}

/**
 * Bağlantı testi: sistemin kendi çözümleyicisiyle bir ad çözdürür ([resolve]) ve bu sorgunun gerçekten
 * yönlendiriciden geçip cevaplandığını sayaçlardan doğrular. Böylece "Bağlı" yazısı yalnızca tünel
 * açıldı demek değil, DNS gerçekten çalışıyor demek olur.
 */
object ConnectionCheck {
    fun run(fw: DnsForwarder, resolve: () -> Unit, timeoutMs: Long = 4000): CheckResult {
        val before = fw.stats()
        val t0 = System.nanoTime()
        val worker = Thread({ try { resolve() } catch (_: Throwable) {} }, "dns-check")
        worker.isDaemon = true
        worker.start()
        while (true) {
            val now = fw.stats()
            val elapsed = (System.nanoTime() - t0) / 1_000_000
            if (now.answered > before.answered || now.cacheHits > before.cacheHits) {
                return CheckResult.Ok(elapsed.toInt())
            }
            if (elapsed >= timeoutMs) return CheckResult.NoAnswer
            try { Thread.sleep(15) } catch (_: InterruptedException) { return CheckResult.NoAnswer }
        }
    }
}
