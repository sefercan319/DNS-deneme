package app.dnshizli.platform

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.SystemClock

/**
 * Telefon açılınca ("Telefon açılınca bağlan" ayarı açıksa) ya da uygulama güncellenince (VPN açıktıysa)
 * servisi başlatır. Bu iki yayın, Android'in arka planda önplan servisi başlatma kısıtından muaftır.
 * VPN izni daha önce verilmemişse hiçbir şey yapmaz (izin penceresi arka planda gösterilemez).
 *
 * Duraklatma telefon kapanırken sürüyorsa sistem alarmları kaybolur: burada yeniden kurulur (süre dolduysa hemen devam).
 *
 * Güvenlik: "QUICKBOOT_POWERON" korumalı bir sistem yayını değildir, herhangi bir uygulama gönderebilir. Bu yüzden
 * yalnızca cihaz gerçekten yeni açılmışsa ([BOOT_WINDOW_MS] içinde) dikkate alınır.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val prefs = PrefsStore(context)
        val settings = prefs.loadSettings()
        val justBooted = SystemClock.elapsedRealtime() < BOOT_WINDOW_MS
        val boot = action == Intent.ACTION_BOOT_COMPLETED || (action == QUICKBOOT && justBooted)
        if (action == QUICKBOOT && !justBooted) return
        val ready = try { VpnService.prepare(context) == null } catch (_: Exception) { false }

        val paused = prefs.pausedUntil()
        if (paused > 0L && (boot || action == Intent.ACTION_MY_PACKAGE_REPLACED)) {
            if (!ready || !settings.onboarded) { prefs.setPausedUntil(0L); return }
            if (paused <= System.currentTimeMillis()) start(context, DnsVpnService.resumeIntent(context, auto = true))
            else PauseAlarm.schedule(context, paused)
            return
        }
        val wanted = when {
            boot -> settings.connectOnBoot
            action == Intent.ACTION_MY_PACKAGE_REPLACED -> settings.wasActive
            else -> false
        }
        if (!wanted || !settings.onboarded || !ready) return
        start(context, DnsVpnService.connectIntent(context, null, auto = true))
    }

    private fun start(context: Context, i: Intent) {
        try {
            context.startForegroundService(i)
        } catch (_: Exception) {
            // başlatılamadı (kısıt, izin): kullanıcı uygulamayı açınca elle bağlanır
        }
    }

    private companion object {
        const val QUICKBOOT = "android.intent.action.QUICKBOOT_POWERON"
        const val BOOT_WINDOW_MS = 10 * 60_000L
    }
}
