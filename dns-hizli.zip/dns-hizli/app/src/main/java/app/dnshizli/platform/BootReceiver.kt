package app.dnshizli.platform

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

/**
 * Telefon açılınca ("Telefon açılınca bağlan" ayarı açıksa) ya da uygulama güncellenince (VPN açıktıysa)
 * servisi başlatır. Bu iki yayın, Android'in arka planda önplan servisi başlatma kısıtından muaftır.
 * VPN izni daha önce verilmemişse hiçbir şey yapmaz (izin penceresi arka planda gösterilemez).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val settings = PrefsStore(context).loadSettings()
        val wanted = when (action) {
            Intent.ACTION_BOOT_COMPLETED, "android.intent.action.QUICKBOOT_POWERON" -> settings.connectOnBoot
            Intent.ACTION_MY_PACKAGE_REPLACED -> settings.wasActive
            else -> false
        }
        if (!wanted || !settings.onboarded) return
        try {
            if (VpnService.prepare(context) != null) return
            context.startForegroundService(DnsVpnService.connectIntent(context, null))
        } catch (_: Exception) {
            // başlatılamadı (kısıt, izin): kullanıcı uygulamayı açınca elle bağlanır
        }
    }
}
