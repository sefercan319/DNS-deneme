package app.dnshizli.core

import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class Stats(
    val queries: Long = 0,
    val cacheHits: Long = 0,
    val forwarded: Long = 0,
    val answered: Long = 0,
    val retries: Long = 0,
    val timeouts: Long = 0,
    val dropped: Long = 0,
    val resets: Long = 0,
    val latencySumMs: Long = 0,
    /** Birincil sunucu cevap vermeyince yedeğe kalıcı geçiş sayısı. */
    val failovers: Long = 0,
    /** Şu an yedek (ikinci) sunucu birincil olarak kullanılıyor mu? */
    val backup: Boolean = false,
) {
    /** Ağdan gelen cevapların ortalama süresi (ms). Hiç cevap yoksa 0. */
    val avgMs: Int get() = if (answered == 0L) 0 else (latencySumMs / answered).toInt()

    /** Önbellekten karşılanan sorguların yüzdesi. */
    val hitPercent: Int get() = if (queries == 0L) 0 else (cacheHits * 100 / queries).toInt()
}

/**
 * Tünelden gelen DNS sorgularını seçilen sunucuya iletir. Android'e bağlı değildir.
 *
 * Kaynak tüketimini düşük tutan tasarım:
 *  - Tüm sorgular için TEK bir UDP soketi (sorgu başına soket/thread yok).
 *  - Sorgu id'leri yeniden yazılır; cevap id ile eşleştirilir (rastgele id, kaynak adresi doğrulanır).
 *  - İki thread (cevap alıcı, zaman aşımı kontrolü) artı tünel okuyucu. Zaman aşımı kontrolü sadece
 *    bekleyen sorgu varken uyanır, boştayken hiç CPU harcanmaz.
 *  - Küçük LRU önbellek, tekrar eden sorgular ağa çıkmaz.
 *  - Sıcak yolda tampon yeniden kullanılır; sorgu başına sadece küçük bir kayıt nesnesi ve anahtar metni oluşur.
 *
 * Sağlamlık:
 *  - [resetNetwork]: ağ değişince (Wi-Fi <-> mobil) soketi yeniler, önbelleği boşaltır, bekleyen
 *    sorguları yeni soketten yeniden gönderir.
 *  - Alım hatası üst üste tekrarlarsa soket kendiliğinden yenilenir.
 *  - Yedek geçişi: birincil sunucu üst üste [FAILOVER_AFTER] sorguda zamanında cevap vermez ve ikincisi verirse,
 *    sonraki sorgular doğrudan ikinciye gider (her sorguda 1,2 sn beklemek yerine). Ağ değişince birincile dönülür.
 *  - Bozuk, kesik, sahte kaynaklı paketler sessizce atılır.
 *
 * [onPacket] tek bir thread'den (tünel okuyucu) çağrılmalıdır.
 */
class DnsForwarder(
    private val upstreams: List<InetSocketAddress>,
    private val writeToTun: (ByteArray, Int, Int) -> Unit,
    private val protect: (DatagramSocket) -> Boolean = { true },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val retryAfterMs: Long = 1200,
    private val giveUpAfterMs: Long = 4000,
    private val sweepMs: Long = 400,
    cacheEntries: Int = 256,
    private val threadFactory: (Runnable, String) -> Thread =
        { r, name -> Thread(r, name).apply { isDaemon = true } },
    private val log: (String) -> Unit = {},
) : AutoCloseable {

    private class Pending(
        val clientIp: Int,
        val serverIp: Int,
        val clientPort: Int,
        val serverPort: Int,
        val clientId: Int,
        val cacheKey: String,
        val query: ByteArray,      // upstream id'si yazılmış DNS verisi (yeniden deneme için)
        val firstSentAt: Long,
        @Volatile var firstIdx: Int,   // ilk gönderildiği sunucu (yeniden deneme diğerine gider)
    ) {
        @Volatile var sentAt: Long = firstSentAt
        @Volatile var attempt = 0
    }

    init {
        require(upstreams.isNotEmpty()) { "en az bir DNS sunucusu gerekli" }
    }

    @Volatile private var socket: DatagramSocket? = null
    @Volatile private var generation = 0
    @Volatile private var primaryIdx = 0
    private val streak = AtomicInteger()
    private val pending = ConcurrentHashMap<Int, Pending>()
    private val cache = DnsCache(cacheEntries, nowMs)
    private val random = SecureRandom()
    private val sweepScheduled = AtomicBoolean(false)
    private val scheduler: ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor { r -> threadFactory(r, "dns-sweep") }
    private var receiver: Thread? = null
    @Volatile private var closed = false
    @Volatile private var lastTimeoutLog = 0L

    // yalnızca onPacket thread'i kullanır
    private val tunBuf = ByteArray(Packets.HDR + MAX_DNS)

    private val queries = AtomicLong()
    private val cacheHits = AtomicLong()
    private val forwarded = AtomicLong()
    private val answered = AtomicLong()
    private val retries = AtomicLong()
    private val timeouts = AtomicLong()
    private val dropped = AtomicLong()
    private val resets = AtomicLong()
    private val latencySum = AtomicLong()
    private val failovers = AtomicLong()

    fun start() {
        check(socket == null) { "zaten başlatıldı" }
        socket = newSocket()
        receiver = threadFactory(Runnable { receiveLoop() }, "dns-recv").also { it.start() }
    }

    fun stats() = Stats(
        queries.get(), cacheHits.get(), forwarded.get(), answered.get(), retries.get(),
        timeouts.get(), dropped.get(), resets.get(), latencySum.get(), failovers.get(), primaryIdx != 0,
    )

    internal fun pendingCount() = pending.size
    internal fun localPort() = socket?.localPort ?: -1

    fun clearCache() = cache.clear()

    /**
     * Ağ değişti (ör. Wi-Fi'den mobil veriye geçildi): eski soket artık yanlış ağa bağlı olabilir.
     * Soketi yeniler, önbelleği boşaltır (cevaplar ağa göre değişebilir) ve bekleyen sorguları
     * yeni soketten bir kez daha gönderir. Herhangi bir thread'den çağrılabilir.
     */
    fun resetNetwork(reason: String = "ağ değişti") {
        if (closed) return
        try {
            rebindSocket(reason)
        } catch (e: IOException) {
            log("soket yenilenemedi: ${e.message}")
            return
        }
        cache.clear()
        primaryIdx = 0                       // yeni ağda önce yine birincil denenir
        streak.set(0)
        val now = nowMs()
        for (e in pending.values) {
            e.sentAt = now
            e.attempt = 0
            e.firstIdx = 0
            send(e.query, upstreams[0])
        }
        resets.incrementAndGet()
        if (pending.isNotEmpty()) scheduleSweep()
    }

    private fun newSocket(): DatagramSocket {
        val s = DatagramSocket()
        if (!protect(s)) {
            s.close()
            throw IOException("protect() başarısız: soket tünel dışında tutulamadı")
        }
        try { s.receiveBufferSize = 64 * 1024 } catch (_: Exception) {}
        return s
    }

    @Synchronized
    private fun rebindSocket(reason: String) {
        if (closed) return
        val fresh = newSocket()
        val old = socket
        socket = fresh
        generation++
        try { old?.close() } catch (_: Exception) {}
        log("soket yenilendi ($reason)")
    }

    /** Tünelden okunan ham IP paketi. [p] çağrıdan sonra yeniden kullanılabilir; burada saklanmaz. */
    fun onPacket(p: ByteArray, len: Int) {
        if (closed) return
        val ihl = Packets.queryHeaderLen(p, len)
        if (ihl < 0) return
        val dnsOff = ihl + Packets.UDP_HDR
        val dnsLen = Packets.dnsLength(p, ihl)
        if (dnsLen < Packets.DNS_HDR || dnsLen > MAX_DNS) return
        if ((p[dnsOff + 2].toInt() and 0x80) != 0) return        // sorgu değil (QR=1)

        queries.incrementAndGet()
        val clientIp = Packets.i32(p, 12)
        val serverIp = Packets.i32(p, 16)
        val clientPort = Packets.u16(p, ihl)
        val serverPort = Packets.u16(p, ihl + 2)
        val clientId = Packets.u16(p, dnsOff)
        val key = String(p, dnsOff + 2, dnsLen - 2, Charsets.ISO_8859_1)

        // 1) önbellek
        val n = cache.get(key, clientId, tunBuf, Packets.HDR)
        if (n > 0) {
            cacheHits.incrementAndGet()
            Packets.writeHeaders(tunBuf, serverIp, clientIp, serverPort, clientPort, n)
            writeToTun(tunBuf, 0, Packets.HDR + n)
            return
        }

        // 2) önbellekte yok: upstream'e gönder
        if (pending.size >= MAX_PENDING) {
            dropped.incrementAndGet()
            return
        }
        val query = p.copyOfRange(dnsOff, dnsOff + dnsLen)
        val first = primaryIdx
        val entry = Pending(clientIp, serverIp, clientPort, serverPort, clientId, key, query, nowMs(), first)
        var upId: Int
        do {
            upId = random.nextInt(65536)
        } while (pending.putIfAbsent(upId, entry) != null)
        Packets.put16(query, 0, upId)

        forwarded.incrementAndGet()
        send(query, upstreams[first])
        scheduleSweep()
    }

    private fun send(data: ByteArray, to: InetSocketAddress) {
        val s = socket ?: return
        try {
            s.send(DatagramPacket(data, data.size, to))
        } catch (_: IOException) {
            // ağ yok olabilir; zaman aşımı kontrolü ikinci denemeyi yapar
        }
    }

    private fun receiveLoop() {
        val buf = ByteArray(MAX_DNS)
        val out = ByteArray(Packets.HDR + MAX_DNS)
        val pkt = DatagramPacket(buf, buf.size)
        var failures = 0
        while (!closed) {
            val s = socket ?: return
            val gen = generation
            try {
                pkt.length = buf.size
                s.receive(pkt)
                failures = 0
            } catch (e: IOException) {
                if (closed) return
                if (gen != generation) continue                  // yeni soket takıldı, hemen dön
                failures++
                if (failures >= 5) {
                    failures = 0
                    try { rebindSocket("alım hatası: ${e.message}") } catch (_: IOException) {}
                }
                try { Thread.sleep(minOf(100L * (failures + 1), 1000L)) } catch (_: InterruptedException) { return }
                continue
            }
            val len = pkt.length
            if (len < Packets.DNS_HDR) continue
            val from = upstreamIndex(pkt)
            if (from < 0) continue                               // sahte kaynak
            val entry = pending.remove(Packets.u16(buf, 0)) ?: continue

            answered.incrementAndGet()
            if (upstreams.size > 1) noteAnswer(entry, from)
            latencySum.addAndGet(maxOf(0L, nowMs() - entry.firstSentAt))

            val ttl = Dns.cacheTtl(buf, len)
            if (ttl > 0 && len <= MAX_REPLY) cache.put(entry.cacheKey, buf, len, ttl)

            if (len > MAX_REPLY) {                               // tünel MTU'suna sığmaz
                dropped.incrementAndGet()
                continue
            }
            System.arraycopy(buf, 0, out, Packets.HDR, len)
            Packets.put16(out, Packets.HDR, entry.clientId)      // istemcinin id'sini geri koy
            Packets.writeHeaders(out, entry.serverIp, entry.clientIp, entry.serverPort, entry.clientPort, len)
            writeToTun(out, 0, Packets.HDR + len)
        }
    }

    /** Paketin geldiği sunucunun [upstreams] içindeki sırası; hiçbiri değilse -1 (sahte kaynak). */
    private fun upstreamIndex(pkt: DatagramPacket): Int {
        for (i in upstreams.indices) {
            val u = upstreams[i]
            if (u.port == pkt.port && u.address == pkt.address) return i
        }
        return -1
    }

    /**
     * Cevabın hangi sunucudan geldiğine bakar. Birincil sunucuya gönderilen sorgu ona değil diğerine
     * (yeniden denemeye) cevaplandıysa sayaç artar; üst üste [FAILOVER_AFTER] kez olursa yedek birincil olur.
     * Birincilden gelen her cevap sayacı sıfırlar, bu yüzden tek seferlik yavaşlık geçişe yol açmaz.
     */
    private fun noteAnswer(entry: Pending, from: Int) {
        val primary = primaryIdx
        if (from == entry.firstIdx) {
            if (from == primary) streak.set(0)
        } else if (entry.firstIdx == primary) {
            if (streak.incrementAndGet() >= FAILOVER_AFTER) {
                streak.set(0)
                primaryIdx = from
                failovers.incrementAndGet()
                log("yedek sunucuya geçildi")
            }
        }
    }

    /** Sadece bekleyen sorgu varken çalışır; boştayken hiç uyanmaz. */
    private fun scheduleSweep() {
        if (closed) return
        if (sweepScheduled.compareAndSet(false, true)) {
            try {
                scheduler.schedule({ sweep() }, sweepMs, TimeUnit.MILLISECONDS)
            } catch (_: RejectedExecutionException) {
                sweepScheduled.set(false)
            }
        }
    }

    private fun sweep() {
        sweepScheduled.set(false)
        val now = nowMs()
        val it = pending.entries.iterator()
        while (it.hasNext()) {
            val e = it.next().value
            val age = now - e.sentAt
            if (age >= giveUpAfterMs) {
                it.remove()
                timeouts.incrementAndGet()
                if (now - lastTimeoutLog > 5000) {
                    lastTimeoutLog = now
                    log("zaman aşımı (toplam ${timeouts.get()})")
                }
            } else if (e.attempt == 0 && age >= retryAfterMs) {
                e.attempt = 1
                retries.incrementAndGet()
                // İlk gönderilenin dışındaki sunucuya, tek sunucu varsa aynısına bir kez daha dene.
                send(e.query, upstreams[(e.firstIdx + 1) % upstreams.size])
            }
        }
        if (pending.isNotEmpty()) scheduleSweep()
    }

    override fun close() {
        if (closed) return
        closed = true
        try { socket?.close() } catch (_: Exception) {}
        scheduler.shutdownNow()
        receiver?.interrupt()
        pending.clear()
        cache.clear()
    }

    companion object {
        /** DNS mesajı için üst sınır (UDP). */
        const val MAX_DNS = 4096

        /** Tünel MTU'su 1500; IPv4 + UDP başlığından sonra kalan. */
        const val MAX_REPLY = 1500 - Packets.HDR

        /** Sel koruması: aynı anda bekleyebilecek en fazla sorgu. */
        const val MAX_PENDING = 1024

        /** Yedek sunucuya geçmek için birincilin üst üste kaç sorguda cevapsız kalması gerektiği. */
        const val FAILOVER_AFTER = 2
    }
}
