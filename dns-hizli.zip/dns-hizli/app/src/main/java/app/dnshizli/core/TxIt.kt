package app.dnshizli.core

/** Italiano. */
object TxIt : Tx() {
    override val lang = Lang.IT

    override val decimalSep = ','
    override val thousand = " mila"
    override val million = " mln"
    override fun percent(n: Int) = "$n%"
    override val dayU = "g"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "proprio ora"
    override fun ago(span: String) = "$span fa"

    override val OFF = "Non connesso"
    override val CONNECTING = "Connessione…"
    override val ON = "Connesso"
    override val ERROR = "Connessione non riuscita"
    override val PAUSED = "In pausa"
    override val HINT_OFF = "Tocca la sfera per connetterti"
    override val HINT_CONNECTING = "Potrebbe richiedere qualche secondo"
    override val HINT_ERROR = "Tocca per riprovare"
    override val HINT_PAUSED = "Tocca per riprendere subito"
    override val ERR_DEFAULT = "Impossibile connettersi"
    override fun selected(name: String) = "$name selezionato"
    override fun pausedUntil(time: String) = "Riprende alle $time"
    override fun blockedShort(n: String) = "$n bloccate"
    override fun queriesShort(n: String) = "$n richieste"
    override fun cacheShort(pct: String) = "$pct in cache"

    override val SERVERS = "Server"
    override val FILTER_ALL = "Tutti"
    override val FILTER_FAV = "Preferiti"
    override val FILTER_RECENT = "Recenti"
    override val EMPTY_FAV = "Ancora nessun preferito. Tocca la stella di un server."
    override val EMPTY_RECENT = "Non ti sei ancora connesso a nessun server."
    override val EMPTY_FILTER = "Nessun server in questa categoria."
    override val MEASURE = "Misura velocità"
    override val MEASURING = "Misurazione…"
    override val SORT = "Ordina per velocità"
    override val PULL_TO_MEASURE = "Trascina per misurare"
    override val RELEASE_TO_MEASURE = "Rilascia per misurare"
    override fun serversCount(n: Int) = "$n server"
    override val TAG_FAST = "Veloci"
    override val TAG_PRIVACY = "Privacy"
    override val TAG_ADS = "Pubblicità"
    override val TAG_FAMILY = "Famiglia"
    override val TAG_SECURITY = "Sicurezza"
    override val VAR_OPEN = "Senza filtri"
    override val VAR_ADS = "Anti-pubblicità"
    override val VAR_SECURITY = "Sicurezza"
    override val VAR_FAMILY = "Famiglia"
    override val A11Y_CONNECTED = "connesso"
    override val A11Y_ENCRYPTED = "cifrato"
    override fun favA11y(name: String) = "$name preferito"

    override val COPIED = "Copiato negli appunti"
    override val DISCONNECTED = "Disconnesso"
    override val BACKUP = "Passato al server di riserva"
    override val NO_REPLY = "Nessun server ha risposto"
    override val MEASURE_FIRST = "Prima misura le velocità"
    override val CONNECT = "Connetti"
    override val UNDO = "Annulla"
    override fun fastest(name: String, ms: Int) = "Il più veloce: $name · $ms ms"
    override fun switched(name: String) = "Passaggio a $name"
    override fun hiddenToast(name: String) = "$name nascosto"

    override val PRIMARY = "Primario"
    override val SECONDARY = "Secondario"
    override val COPY = "Copia"
    override fun addressA11y(label: String, ip: String) = "Indirizzo $label: $ip"
    override val CONNECT_TO_THIS = "Connetti a questo server"
    override val SWITCH_TO_THIS = "Passa a questo server"
    override val CONNECTED_NOW = "Connesso ora"
    override val ADD_FAV = "Aggiungi ai preferiti"
    override val REMOVE_FAV = "Rimuovi dai preferiti"
    override val MEASURE_THIS = "Misura velocità"
    override val HIDE = "Nascondi dall'elenco"
    override val UNHIDE = "Mostra nell'elenco"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Ultima misura: nessuna risposta · $ago" else "Ultima misura: $ms ms · $ago"
    override val NEVER_MEASURED = "Non ancora misurato"
    override val ENC_SUPPORT = "DNS cifrato"
    override val ENC_NONE = "Non supportato"
    override val ENC_ONLY = "Accetta solo connessioni cifrate"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Migliore $best ms · mediana $median ms · perdita $lossPct%"
    override val HISTORY = "Storico misure"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n misure, nessuna risposta" else "$HISTORY: $n misure, mediana $median ms"

    override val QUICK_TITLE = "Scelta rapida"
    override val QUICK_FAVORITES = "Preferiti"
    override val QUICK_RECENT = "Usati di recente"
    override val PAUSE_FOR = "Metti in pausa"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Riprendi"

    override val SETTINGS = "Impostazioni"
    override val SEC_LOOK = "Aspetto"
    override val SEC_CONNECTION = "Connessione"
    override val SEC_PRIVACY = "Privacy e sicurezza"
    override val SEC_LIST = "Elenco server"
    override val SEC_INFO = "Statistiche"
    override val SEC_DATA = "Dati"
    override val SEC_ABOUT = "Informazioni"
    override val LANGUAGE = "Lingua"
    override val LANG_AUTO = "Automatica (lingua di sistema)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Automatico"
    override val THEME_AUTO_NOTE = "Automatico · segue chiaro/scuro di sistema"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prato"
        "ocean" -> "Oceano"
        "sunset" -> "Tramonto"
        "lavender" -> "Lavanda"
        "coral" -> "Corallo"
        "mint" -> "Menta"
        "night" -> "Notte"
        "amoled" -> "Nero (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema notte a orario"
    override val THEME_SCHEDULE_NOTE = "In Automatico, Notte dalle 22:00 alle 07:00"
    override val GLASS = "Opacità del vetro"
    override val BUBBLES = "Bolle"
    override val MOTION = "Animazioni"
    override val TEXT_SIZE = "Dimensione testo"
    override val HIGH_CONTRAST = "Contrasto elevato"
    override val HIGH_CONTRAST_NOTE = "Vetro più opaco e testo più scuro"
    override val MINIMAL = "Vista essenziale"
    override val MINIMAL_NOTE = "Nasconde i filtri e la riga delle statistiche"
    override val LOW_POWER = "Risparmio energetico"
    override val LOW_POWER_NOTE = "Disattiva ogni movimento, preserva la batteria"
    override val HAPTICS = "Vibrazione"
    override val HAPTICS_NOTE = "Leggero riscontro al tocco"
    override val ENCRYPTION = "DNS cifrato"
    override val ENCRYPTION_NOTE = "Auto: prima DoT, poi DoH, infine DNS non cifrato"
    override val AUTO_CONNECT = "Connetti all'apertura"
    override val AUTO_CONNECT_NOTE = "All'apertura dell'app si connette all'ultimo server"
    override val CONNECT_ON_BOOT = "Connetti all'avvio"
    override val CONNECT_ON_BOOT_NOTE = "Si connette da solo dopo il riavvio del telefono"
    override val AUTO_FASTEST = "Connetti al più veloce"
    override val AUTO_FASTEST_NOTE = "La sfera sceglie il server più veloce dell'ultima misura"
    override val REFRESH_ON_NET = "Aggiorna al cambio di rete"
    override val REFRESH_ON_NET_NOTE = "Il DNS si aggiorna passando tra Wi-Fi e dati mobili"
    override val NOTIFY_DROP = "Avvisa se cade la connessione"
    override val NOTIFY_DROP_NOTE = "Notifica con pulsante per riconnettere in caso di caduta"
    override val CACHE = "Cache DNS"
    override val CLEAR_CACHE = "Svuota cache"
    override val CACHE_CLEARED = "Cache svuotata"
    override val ONLY_CONNECTED = "Disponibile quando connesso"
    override val RULE_WIFI = "Server per Wi-Fi"
    override val RULE_MOBILE = "Server per dati mobili"
    override val RULE_AUTO = "Automatico"
    override val RULE_AUTO_NOTE = "L'ultimo server usato"
    override val COMPACT = "Elenco compatto"
    override val COMPACT_NOTE = "Righe più corte, senza descrizione"
    override val HIDDEN = "Server nascosti"
    override val HIDDEN_NONE = "Nessuno"
    override val STAT_QUERIES = "Richieste totali"
    override val STAT_HITS = "Risposte dalla cache"
    override val STAT_BLOCKED = "Bloccate (stima)"
    override val STAT_TIME = "Tempo totale connesso"
    override val WEEK = "Ultimi 7 giorni"
    override fun weekA11y(total: String) = "$total richieste negli ultimi 7 giorni"
    override val WEEKDAYS = listOf("Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do")
    override val EXPORT = "Esporta impostazioni"
    override val IMPORT = "Importa impostazioni"
    override val EXPORTED = "Codice impostazioni copiato"
    override val IMPORTED = "Impostazioni caricate"
    override val IMPORT_BAD = "Negli appunti non c'è un codice impostazioni valido"
    override val RESET_SETTINGS = "Ripristina impostazioni"
    override val RESET_STATS = "Azzera statistiche"
    override val CONFIRM = "Sei sicuro?"
    override val RESET = "Ripristina"
    override val RESET_DONE = "Ripristinato"
    override val LOG = "Registro diagnostico"
    override val HELP = "Come funziona?"
    override val VPN_SETTINGS = "Impostazioni VPN di sistema"
    override val SHARE_APP = "Condividi l'app"
    override val RATE_APP = "Valuta l'app"
    override val FEEDBACK = "Invia feedback"
    override fun shareAppText(url: String) = "$APP ti collega ai DNS più noti con un tocco: $url"
    override val VERSION = "Versione"
    override val OPT_BUBBLES = listOf("No", "Poche", "Molte")
    override val OPT_MOTION = listOf("Tutte", "Ridotte", "No")
    override val OPT_CACHE = listOf("No", "Piccola", "Normale", "Grande")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "No")
    override val PLAIN_DNS = "DNS non cifrato"

    override val LOG_NOTE = "Si conservano solo gli eventi di connessione. Mai nomi delle richieste né dati personali."
    override val LOG_EMPTY = "Ancora nessuna voce."
    override val SHARE = "Condividi"
    override val CLEAR = "Cancella"
    override val CLEARED = "Cancellato"
    override val HELP_SECTIONS = listOf(
        "Cos'è il DNS?" to
            "Il DNS è il servizio che trasforma gli indirizzi internet (come example.com) in numeri comprensibili ai dispositivi. " +
            "Il DNS che usi può influire su velocità, privacy e contenuti bloccati.",
        "Cosa fa l'app?" to
            "Usa il server DNS scelto in tutte le app. Per farlo apre un'interfaccia VPN locale sul telefono, " +
            "ma il tuo traffico non passa da alcun server VPN. Solo le richieste DNS vanno al server scelto; " +
            "tutto il resto segue il percorso normale.",
        "DNS cifrato (DoT / DoH)" to
            "Con i server compatibili le richieste viaggiano cifrate: nessuno in rete (proprietario del Wi-Fi, operatore) vede " +
            "quali siti visiti né può alterare le risposte. In Automatico si prova prima DoT, poi DoH; se nessuno funziona, " +
            "si usa il DNS non cifrato. Vieni avvisato quando succede e l'app prova a tornare alla cifratura a ogni cambio di rete e ogni 10 minuti. " +
            "Con \"Cifratura rigorosa\" attiva, il DNS non cifrato non viene mai usato. La schermata principale mostra il metodo in uso.",
        "Test di connessione" to
            "Impostazioni > Privacy e sicurezza > Test di connessione invia vere richieste DNS attraverso il tunnel. Mostra che " +
            "il DNS risponde davvero dal server scelto, con che velocità, se il server convalida le firme DNSSEC " +
            "e se blocca un noto dominio pubblicitario.",
        "Privacy" to
            "Nessun account, nessuna raccolta di dati, nessuna pubblicità. L'app non salva i nomi delle richieste e non invia nulla di sua iniziativa. " +
            "Le tue richieste vanno solo al provider DNS scelto, secondo la sua informativa sulla privacy. " +
            "Il registro diagnostico contiene solo eventi di connessione.",
        "Batteria e risorse" to
            "In background consuma pochissimo. A schermo spento non gira nessun ciclo; " +
            "lavora solo quando arriva una richiesta DNS. Le connessioni cifrate si chiudono da sole quando inattive.",
        "Da sapere" to
            "Android consente una sola VPN alla volta; con un'altra app VPN attiva questa non può connettersi. " +
            "Il \"DNS sicuro\" di alcuni browser e il \"DNS privato\" di Android impostato su un nome usano il proprio server " +
            "e possono aggirare questo reindirizzamento; basta lasciarli su \"Automatico\" o \"Disattivato\". " +
            "Tieni premuta la sfera per cambiare server al volo o mettere in pausa la connessione.",
    )

    override val NOTIF_CHANNEL = "Stato della connessione"
    override val NOTIF_CHANNEL_NOTE = "Mostrata mentre la connessione DNS è attiva"
    override val NOTIF_ALERT_CHANNEL = "Avvisi di connessione"
    override val NOTIF_CONNECTING = "Connessione…"
    override val NOTIF_STOP = "Disconnetti"
    override val NOTIF_NEXT = "Successivo"
    override val NOTIF_DROP_TITLE = "Connessione DNS persa"
    override val NOTIF_RECONNECT = "Riconnetti"
    override fun notifOn(name: String, proto: String) = "Connesso a $name · $proto"
    override fun notifPaused(time: String) = "In pausa · riprende alle $time"
    override val TILE_ON = "Connesso"
    override val TILE_OFF = "Disattivato"
    override val WIDGET_TAP = "Tocca: connetti / disconnetti"
    override val ERR_PERMISSION = "Autorizzazione VPN non concessa"
    override val ERR_ESTABLISH = "Impossibile aprire l'interfaccia VPN. Potrebbe esserci un'altra VPN attiva."
    override fun errNoReply(name: String) = "$name non ha risposto"
    override fun errNoProto(name: String, proto: String) = "$name non supporta $proto"
    override val ERR_SOCKET = "Rete non raggiungibile"
    override fun errPrivateDns(host: String) = "Il DNS privato di Android è impostato su $host e aggira l'app. Imposta Impostazioni > Rete > DNS privato su Automatico o Disattivato."
    override val ERR_REVOKED = "Il sistema ha chiuso la connessione"
    override val ERR_TUNNEL = "Il tunnel si è chiuso inaspettatamente"
    override val ERR_UNKNOWN = "Si è verificato un errore imprevisto"

    override val CONSENT_TITLE = "Prima di connetterti"
    override val CONSENT_BODY = listOf(
        "$APP usa l'interfaccia VPN di Android per indirizzare le tue richieste DNS (i nomi dei siti che visiti) al server DNS scelto.",
        "Il tuo traffico non viene inviato a nessun server VPN; solo le richieste DNS vanno al provider scelto. Con i server compatibili " +
            "sono cifrate (DoT/DoH), altrimenti viaggiano in chiaro. Si applica l'informativa privacy del provider.",
        "L'app non raccoglie dati personali, non salva i nomi delle richieste e non condivide nulla.",
        "Se continui, Android mostrerà una richiesta di connessione VPN; tocca \"OK\".",
    )
    override val CONSENT_OK = "Ho capito, continua"
    override val CLOSE = "Chiudi"
    override val BACK = "Indietro"

    // ---- 3. sürüm ----
    override val RESUMING = "Ripresa in corso…"
    override val DOWNGRADED = "Cifratura non riuscita, DNS non cifrato"
    override val UPGRADED = "Di nuovo su DNS cifrato"
    override val NOTIF_DOWNGRADE_TITLE = "Il DNS non è cifrato"
    override fun notifDowngrade(name: String) = "Impossibile stabilire una connessione cifrata con $name. È in uso il DNS non cifrato; l'app proverà a tornare alla cifratura."
    override fun backupUsed(failed: String, used: String) = "$failed non ha risposto, connesso a $used"
    override val NOTIF_RETRYING = "Connessione persa, nuovo tentativo…"
    override fun errNoEncrypted(name: String) = "Impossibile stabilire una connessione cifrata con $name"
    override val APPLYING = "Applicazione della nuova impostazione"
    override val CONFIRM_DISCONNECT = "Disconnettere?"
    override val DISCONNECT = "Disconnetti"

    override val SEC_NOTIF = "Notifiche"
    override val STRICT_ENC = "Cifratura rigorosa"
    override val STRICT_ENC_NOTE = "Non ripiegare mai sul DNS non cifrato"
    override val AUTO_RECONNECT = "Riconnetti automaticamente"
    override val AUTO_RECONNECT_NOTE = "Se la connessione cade, riprova dopo 5 s, 30 s e 2 min"
    override val BACKUP_SERVER = "Server di riserva"
    override val BACKUP_OFF = "Disattivato"
    override val BACKUP_OFF_NOTE = "Non si connette se il server scelto non risponde"
    override val BACKUP_FASTEST = "Il più veloce"
    override val BACKUP_FASTEST_NOTE = "L'altro server più veloce dell'ultima misura"
    override val CONFIRM_OFF = "Conferma la disconnessione"
    override val CONFIRM_OFF_NOTE = "Un tocco accidentale sulla sfera non disconnette"
    override val LOCK_HIDE = "Nascondi a schermo bloccato"
    override val LOCK_HIDE_NOTE = "Il nome del server non appare nella notifica a schermo bloccato"
    override val QUIET_NOTIF = "Notifica discreta"
    override val QUIET_NOTIF_NOTE = "Nessuna icona nella barra di stato, silenziosa"
    override val REMEMBER_FILTER = "Ricorda l'ultimo filtro"
    override val REMEMBER_FILTER_NOTE = "All'apertura dell'app torna l'ultimo filtro scelto"
    override val AUTO_MEASURE = "Misura all'avvio"
    override val AUTO_MEASURE_NOTE = "Misura da solo se l'ultima misura ha più di un giorno"
    override val MEASURE_ENC = "Misura cifrata"
    override val MEASURE_ENC_NOTE = "Misura la velocità via DoT, più vicina all'uso cifrato reale"
    override val OPT_SORT = listOf("Standard", "Velocità", "Nome")
    override fun sortA11y(mode: String) = "Ordine: $mode"
    override val AUTO_LIGHT = "Automatico: tema chiaro"
    override val AUTO_DARK = "Automatico: tema scuro"
    override val NIGHT_HOURS = "Ore notturne"
    override val FILTER_ENCRYPTED = "Cifrati"
    override val FILTER_UNFILTERED = "Senza filtri"

    override val TEST = "Testa la connessione"
    override val TEST_NOTE = "DNS, DNSSEC e blocco pubblicità"
    override val TESTING = "Test in corso…"
    override val TEST_TITLE = "Test di connessione"
    override val TEST_OK = "Il DNS funziona"
    override val TEST_FAIL = "Nessuna risposta"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Metodo"
    override val TEST_LATENCY = "Tempo di risposta"
    override val TEST_DNSSEC = "Convalida DNSSEC"
    override val TEST_ADS = "Blocco pubblicità"
    override val DNSSEC_YES = "Convalida attiva"
    override val DNSSEC_NO = "Nessuna convalida"
    override val ADS_YES = "Attivo"
    override val ADS_NO = "Non attivo"
    override val UNKNOWN = "Sconosciuto"
    override val TEST_EXPLAIN = "Le domande sono state inviate attraverso il tunnel, come farebbe un'app; le risposte sono arrivate dal server scelto."
    override val TEST_AGAIN = "Ripeti il test"

    override val RECOMMEND = "Trovami un server"
    override val RECOMMEND_NOTE = "Scegli l'obiettivo e ti colleghiamo al più veloce adatto"
    override val GOAL_SPEED = "Velocità"
    override val GOAL_SPEED_NOTE = "Il server più veloce secondo le tue misure"
    override val GOAL_PRIVACY_NOTE = "Nessun log, attento alla privacy"
    override val GOAL_ADS_NOTE = "Blocca pubblicità e tracker"
    override val GOAL_FAMILY_NOTE = "Blocca i contenuti per adulti"
    override val GOAL_SECURITY_NOTE = "Blocca siti dannosi e di phishing"
    override fun recommended(name: String) = "Consigliato: $name"

    override val PRIVATE_DNS = "Nome DNS privato"
    override val PRIVATE_DNS_NOTE = "Puoi incollarlo nell'impostazione DNS privato di Android. Il sistema userà questo server direttamente, aggirando quest'app."
    override val CLEAR_HISTORY = "Cancella storico misure"
    override val HISTORY_CLEARED = "Misure cancellate"

    override val GUARD = "Protezione continua"
    override val GUARD_NOTE = "VPN sempre attiva"
    override val GUARD_BODY = listOf(
        "Quando l'app non è connessa (spenta, in pausa o dopo una caduta), le tue richieste DNS vanno al server del tuo provider internet.",
        "Per evitarlo, attiva \"VPN sempre attiva\" per quest'app nelle impostazioni VPN di Android. Se è attivo anche \"Blocca connessioni senza VPN\", internet non funzionerà affatto finché l'app non è connessa: nulla trapela, ma mettere in pausa significa anche restare senza internet.",
        "Con la VPN sempre attiva, il sistema avvia l'app da solo all'accensione del telefono e dopo che si è fermata.",
    )
    override val GUARD_BUTTON = "Apri impostazioni VPN"
    override val BATTERY = "Impostazioni batteria"
    override val BATTERY_OK = "Senza limitazioni"
    override val BATTERY_LIMITED = "Potrebbe essere limitata"
    override val BATTERY_BODY = listOf(
        "Android di solito protegge le app VPN. Alcuni produttori (Xiaomi, Huawei, Oppo, Vivo, alcune versioni Samsung) però possono chiudere le app in background per risparmiare batteria.",
        "Se la connessione cade da sola, imposta l'uso della batteria di quest'app su \"Senza limitazioni\" o \"Non ottimizzata\"; su alcuni telefoni consenti anche l'\"Avvio automatico\".",
    )
    override val BATTERY_BUTTON = "Apri impostazioni batteria"

    override val STAT_AVG = "Tempo medio di risposta"
    override val STAT_SAVED = "Tempo risparmiato con la cache"
    override val STAT_TRAFFIC = "Traffico DNS"
    override val SESSIONS = "Storico connessioni"
    override val SESSIONS_NOTE = "Ultime 30 connessioni; i nomi delle richieste non sono mai salvati"
    override val SESSIONS_EMPTY = "Ancora nessuna connessione registrata."
    override val MOST_USED = "Più usati"
    override val TODAY = "Oggi"
    override val YESTERDAY = "Ieri"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Disconnesso da te"
        EndReason.PAUSE -> "In pausa"
        EndReason.SWITCH -> "Server cambiato"
        EndReason.DROP -> "Caduta"
        EndReason.REVOKED -> "Chiusa dal sistema"
        EndReason.FAILED -> "Nessuna risposta"
        EndReason.NETWORK -> "Rete cambiata"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries richieste"

    override val WHATS_NEW = "Novità"
    override val WHATS_NEW_TOAST = "L'app è stata aggiornata"
    override val SHOW = "Mostra"
    override val WHATS_NEW_ITEMS = listOf(
        "Connessione più sicura: controlli extra contro risposte DNS false, avviso quando si ripiega sul DNS non cifrato, opzione di cifratura rigorosa e ritorno automatico alla cifratura.",
        "Test di connessione: verifica con un tocco che il DNS risponda dal server scelto, oltre a convalida DNSSEC e blocco pubblicità.",
        "Server di riserva e riconnessione automatica: l'app si ripristina da sola se il server scelto non risponde o la connessione cade.",
        "Storico connessioni, server più usati, tempo medio di risposta e traffico DNS.",
        "Nuovi filtri (Cifrati, Senza filtri), ordinamento per nome, \"Trovami un server\" e misura all'avvio.",
        "Contatori in tempo reale nella notifica, pulsante di pausa di 15 minuti, opzione per nascondere a schermo bloccato e notifica discreta.",
        "Tre nuovi temi (Sakura, Miele, Aurora), un tema dallo sfondo e scelta chiaro/scuro per il tema automatico.",
        "Quattro nuove lingue: indonesiano, vietnamita, polacco e ucraino.",
    )
    override fun importedWith(changes: String) = "Impostazioni caricate · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "cifratura indebolita"
        SensitiveChange.AUTO_START -> "connessione automatica attivata"
        SensitiveChange.RULES -> "regole dei server modificate"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries richieste · $blocked bloccate"
    override val NOTIF_LOCKED = "Protezione DNS attiva"
    override val NOTIF_QUIET_CHANNEL = "Stato della connessione (discreta)"
    override fun widgetToday(queries: String) = "Oggi $queries richieste"
    override fun pauseAction(minutes: Int) = "Pausa ${minutes(minutes)}"


    override val NOTES = mapOf(
        "cloudflare" to "Veloce, attento alla privacy",
        "google" to "Stabile, molto diffuso",
        "quad9" to "Blocca i domini dannosi",
        "adguard" to "Blocca pubblicità e tracker",
        "controld" to "Senza filtri, veloce",
        "opendns" to "Cisco, protezione anti-phishing",
        "mullvad" to "Nessun log, solo cifrato",
        "dnssb" to "Attento alla privacy, veloce",
        "dns4eu" to "DNS dell'UE, contro i malware",
        "uncensored" to "Nessun filtro né reindirizzamento",
        "quad9-open" to "Non blocca nulla",
        "adguard-open" to "Nessun blocco, attento alla privacy",
        "dns4eu-open" to "DNS dell'UE, senza filtri",
        "controld-ads" to "Pubblicità, tracker, malware",
        "mullvad-ads" to "Pubblicità e tracker, solo cifrato",
        "dns4eu-ads" to "DNS dell'UE, pubblicità e malware",
        "cloudflare-security" to "Blocca i siti dannosi",
        "controld-malware" to "Blocca i siti dannosi",
        "cleanbrowsing-security" to "Phishing e siti dannosi",
        "cloudflare-family" to "Filtro malware e contenuti adulti",
        "opendns-family" to "Filtro contenuti per adulti",
        "adguard-family" to "Filtro pubblicità e contenuti adulti",
        "cleanbrowsing-family" to "Contenuti adulti, ricerca sicura",
        "dns4eu-child" to "DNS dell'UE, tutela dei minori",
        "mullvad-family" to "Filtro famiglia, solo cifrato",
        "controld-family" to "Filtro contenuti per adulti",
    )
}
