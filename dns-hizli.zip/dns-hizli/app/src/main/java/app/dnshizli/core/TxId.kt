package app.dnshizli.core

/** Bahasa Indonesia. */
object TxId : Tx() {
    override val lang = Lang.ID

    override val decimalSep = ','
    override val thousand = " rb"
    override val million = " jt"
    override fun percent(n: Int) = "$n%"
    override val dayU = "hr"
    override val hourU = "jam"
    override val minU = "mnt"
    override val secU = "dtk"
    override val justNow = "baru saja"
    override fun ago(span: String) = "$span lalu"

    override val OFF = "Tidak terhubung"
    override val CONNECTING = "Menghubungkan…"
    override val ON = "Terhubung"
    override val ERROR = "Gagal terhubung"
    override val PAUSED = "Dijeda"
    override val HINT_OFF = "Ketuk bola untuk terhubung"
    override val HINT_CONNECTING = "Mungkin perlu beberapa detik"
    override val HINT_ERROR = "Ketuk untuk mencoba lagi"
    override val HINT_PAUSED = "Ketuk untuk lanjut sekarang"
    override val ERR_DEFAULT = "Koneksi gagal"
    override fun selected(name: String) = "$name dipilih"
    override fun pausedUntil(time: String) = "Lanjut pukul $time"
    override fun blockedShort(n: String) = "$n diblokir"
    override fun queriesShort(n: String) = "$n kueri"
    override fun cacheShort(pct: String) = "$pct cache"

    override val SERVERS = "Server"
    override val FILTER_ALL = "Semua"
    override val FILTER_FAV = "Favorit"
    override val FILTER_RECENT = "Terakhir"
    override val EMPTY_FAV = "Belum ada favorit. Ketuk bintang pada server."
    override val EMPTY_RECENT = "Kamu belum pernah terhubung ke server."
    override val EMPTY_FILTER = "Tidak ada server di kategori ini."
    override val MEASURE = "Ukur kecepatan"
    override val MEASURING = "Mengukur…"
    override val SORT = "Urutan"
    override val PULL_TO_MEASURE = "Tarik untuk mengukur kecepatan"
    override val RELEASE_TO_MEASURE = "Lepas untuk mengukur"
    override fun serversCount(n: Int) = "$n server"
    override val TAG_FAST = "Cepat"
    override val TAG_PRIVACY = "Privasi"
    override val TAG_ADS = "Blokir iklan"
    override val TAG_FAMILY = "Keluarga"
    override val TAG_SECURITY = "Keamanan"
    override val VAR_OPEN = "Tanpa Filter"
    override val VAR_ADS = "Blokir Iklan"
    override val VAR_SECURITY = "Keamanan"
    override val VAR_FAMILY = "Keluarga"
    override val A11Y_CONNECTED = "terhubung"
    override val A11Y_ENCRYPTED = "terenkripsi"
    override fun favA11y(name: String) = "$name favorit"

    override val COPIED = "Disalin ke papan klip"
    override val DISCONNECTED = "Koneksi terputus"
    override val BACKUP = "Beralih ke server cadangan"
    override val NO_REPLY = "Tidak ada server yang merespons"
    override val MEASURE_FIRST = "Ukur kecepatan dulu"
    override val CONNECT = "Hubungkan"
    override val UNDO = "Urungkan"
    override fun fastest(name: String, ms: Int) = "Tercepat: $name · $ms ms"
    override fun switched(name: String) = "Beralih ke $name"
    override fun hiddenToast(name: String) = "$name disembunyikan"

    override val PRIMARY = "Utama"
    override val SECONDARY = "Sekunder"
    override val COPY = "Salin"
    override fun addressA11y(label: String, ip: String) = "Alamat $label: $ip"
    override val CONNECT_TO_THIS = "Hubungkan ke server ini"
    override val SWITCH_TO_THIS = "Beralih ke server ini"
    override val CONNECTED_NOW = "Sedang terhubung"
    override val ADD_FAV = "Tambah ke favorit"
    override val REMOVE_FAV = "Hapus dari favorit"
    override val MEASURE_THIS = "Ukur kecepatan"
    override val HIDE = "Sembunyikan dari daftar"
    override val UNHIDE = "Tampilkan di daftar"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Cek terakhir: tak ada respons · $ago" else "Cek terakhir: $ms ms · $ago"
    override val NEVER_MEASURED = "Belum diukur"
    override val ENC_SUPPORT = "DNS terenkripsi"
    override val ENC_NONE = "Tidak didukung"
    override val ENC_ONLY = "Hanya menerima koneksi terenkripsi"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Terbaik $best ms · median $median ms · hilang $lossPct%"
    override val HISTORY = "Riwayat kecepatan"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n pengukuran, tak ada respons" else "$HISTORY: $n pengukuran, median $median ms"

    override val QUICK_TITLE = "Ganti cepat"
    override val QUICK_FAVORITES = "Favorit"
    override val QUICK_RECENT = "Terakhir dipakai"
    override val PAUSE_FOR = "Jeda"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} jam" else "$n mnt"
    override val RESUME = "Lanjutkan"

    override val SETTINGS = "Pengaturan"
    override val SEC_LOOK = "Tampilan"
    override val SEC_CONNECTION = "Koneksi"
    override val SEC_PRIVACY = "Privasi & keamanan"
    override val SEC_LIST = "Daftar server"
    override val SEC_INFO = "Statistik"
    override val SEC_DATA = "Data"
    override val SEC_ABOUT = "Tentang"
    override val LANGUAGE = "Bahasa"
    override val LANG_AUTO = "Otomatis (bahasa sistem)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Otomatis"
    override val THEME_AUTO_NOTE = "Otomatis · ikuti mode terang/gelap sistem"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Rumput"
        "ocean" -> "Samudra"
        "sunset" -> "Senja"
        "lavender" -> "Lavender"
        "coral" -> "Koral"
        "mint" -> "Mint"
        "sakura" -> "Sakura"
        "honey" -> "Madu"
        "night" -> "Malam"
        "amoled" -> "Hitam (AMOLED)"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema malam terjadwal"
    override val THEME_SCHEDULE_NOTE = "Di mode Otomatis, tema gelap pada jam pilihanmu"
    override val GLASS = "Transparansi kaca"
    override val BUBBLES = "Gelembung"
    override val MOTION = "Animasi"
    override val TEXT_SIZE = "Ukuran teks"
    override val HIGH_CONTRAST = "Kontras tinggi"
    override val HIGH_CONTRAST_NOTE = "Kaca lebih pekat dan teks lebih gelap"
    override val MINIMAL = "Tampilan minimal"
    override val MINIMAL_NOTE = "Sembunyikan filter dan baris statistik"
    override val LOW_POWER = "Mode hemat daya"
    override val LOW_POWER_NOTE = "Matikan semua gerakan, hemat baterai"
    override val HAPTICS = "Getaran"
    override val HAPTICS_NOTE = "Getar ringan saat disentuh"
    override val ENCRYPTION = "DNS terenkripsi"
    override val ENCRYPTION_NOTE = "Otomatis: DoT dulu, lalu DoH, terakhir DNS biasa"
    override val AUTO_CONNECT = "Hubungkan saat app dibuka"
    override val AUTO_CONNECT_NOTE = "Terhubung ke server terakhir saat kamu membuka aplikasi"
    override val CONNECT_ON_BOOT = "Hubungkan saat ponsel aktif"
    override val CONNECT_ON_BOOT_NOTE = "Terhubung otomatis setelah ponsel dimulai ulang"
    override val AUTO_FASTEST = "Hubungkan ke yang tercepat"
    override val AUTO_FASTEST_NOTE = "Ketuk bola untuk memilih server tercepat dari cek terakhir"
    override val REFRESH_ON_NET = "Perbarui saat ganti jaringan"
    override val REFRESH_ON_NET_NOTE = "DNS diperbarui saat beralih antara Wi-Fi dan data seluler"
    override val NOTIFY_DROP = "Beri tahu jika koneksi putus"
    override val NOTIFY_DROP_NOTE = "Notifikasi dengan tombol sambung ulang saat putus tiba-tiba"
    override val CACHE = "Cache DNS"
    override val CLEAR_CACHE = "Hapus cache"
    override val CACHE_CLEARED = "Cache dihapus"
    override val ONLY_CONNECTED = "Tersedia saat terhubung"
    override val RULE_WIFI = "Server Wi-Fi"
    override val RULE_MOBILE = "Server data seluler"
    override val RULE_AUTO = "Otomatis"
    override val RULE_AUTO_NOTE = "Server yang terakhir kamu pakai"
    override val COMPACT = "Daftar ringkas"
    override val COMPACT_NOTE = "Baris lebih pendek tanpa deskripsi"
    override val HIDDEN = "Server tersembunyi"
    override val HIDDEN_NONE = "Tidak ada"
    override val STAT_QUERIES = "Total kueri"
    override val STAT_HITS = "Dijawab dari cache"
    override val STAT_BLOCKED = "Diblokir (perkiraan)"
    override val STAT_TIME = "Total waktu terhubung"
    override val WEEK = "7 hari terakhir"
    override fun weekA11y(total: String) = "$total kueri dalam 7 hari terakhir"
    override val WEEKDAYS = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
    override val EXPORT = "Ekspor pengaturan"
    override val IMPORT = "Impor pengaturan"
    override val EXPORTED = "Kode pengaturan disalin ke papan klip"
    override val IMPORTED = "Pengaturan dimuat"
    override val IMPORT_BAD = "Tidak ada kode pengaturan yang valid di papan klip"
    override val RESET_SETTINGS = "Reset pengaturan"
    override val RESET_STATS = "Reset statistik"
    override val CONFIRM = "Kamu yakin?"
    override val RESET = "Reset"
    override val RESET_DONE = "Berhasil direset"
    override val LOG = "Log diagnostik"
    override val HELP = "Bagaimana cara kerjanya?"
    override val VPN_SETTINGS = "Setelan VPN sistem"
    override val SHARE_APP = "Bagikan aplikasi"
    override val RATE_APP = "Beri nilai aplikasi"
    override val FEEDBACK = "Kirim masukan"
    override fun shareAppText(url: String) = "$APP menghubungkanmu ke server DNS populer dengan sekali ketuk: $url"
    override val VERSION = "Versi"
    override val OPT_BUBBLES = listOf("Mati", "Sedikit", "Banyak")
    override val OPT_MOTION = listOf("Penuh", "Sedikit", "Mati")
    override val OPT_CACHE = listOf("Mati", "Kecil", "Normal", "Besar")
    override val OPT_ENCRYPTION = listOf("Otomatis", "DoT", "DoH", "Mati")
    override val PLAIN_DNS = "DNS biasa"

    override val LOG_NOTE = "Hanya peristiwa koneksi yang disimpan. Nama kueri dan data pribadi tidak pernah disimpan."
    override val LOG_EMPTY = "Belum ada catatan."
    override val SHARE = "Bagikan"
    override val CLEAR = "Hapus"
    override val CLEARED = "Dihapus"
    override val HELP_SECTIONS = listOf(
        "Apa itu DNS?" to
            "DNS adalah layanan yang mengubah alamat internet (seperti example.com) menjadi angka yang dipahami perangkat. " +
            "DNS yang kamu pakai bisa memengaruhi kecepatan, privasi, dan konten apa saja yang diblokir.",
        "Apa fungsi aplikasi ini?" to
            "Aplikasi ini memakai server DNS pilihanmu di semua aplikasi. Untuk itu, aplikasi membuka antarmuka VPN lokal di ponselmu, " +
            "tetapi lalu lintasmu tidak dikirim ke server VPN. Hanya kueri DNS yang dikirim ke server pilihanmu; " +
            "selebihnya tetap lewat jalur biasa.",
        "DNS terenkripsi (DoT / DoH)" to
            "Di server yang mendukung, kueri dikirim terenkripsi: tak seorang pun di jaringan (pemilik Wi-Fi, operator) bisa melihat " +
            "situs yang kamu kunjungi atau mengubah jawabannya. Di mode Otomatis, DoT dicoba lebih dulu, lalu DoH; jika keduanya gagal, " +
            "DNS biasa dipakai. Kamu akan diberi tahu saat itu terjadi, dan aplikasi mencoba kembali ke enkripsi setiap kali " +
            "jaringan berganti dan setiap 10 menit. Jika \"Enkripsi ketat\" aktif, DNS biasa tidak pernah dipakai. " +
            "Layar utama menunjukkan metode yang sedang dipakai.",
        "Tes koneksi" to
            "Pengaturan > Privasi & keamanan > Tes koneksi mengirim pertanyaan DNS sungguhan melalui terowongan. Hasilnya menunjukkan " +
            "bahwa DNS benar-benar dijawab oleh server pilihanmu, seberapa cepat, apakah server memvalidasi tanda tangan DNSSEC, " +
            "dan apakah server memblokir domain iklan yang terkenal.",
        "Privasi" to
            "Tanpa akun, tanpa pengumpulan data, tanpa iklan. Aplikasi tidak menyimpan nama kueri dan tidak mengirim apa pun atas kemauannya sendiri. " +
            "Kueri kamu hanya dikirim ke penyedia DNS pilihanmu, sesuai kebijakan privasi penyedia tersebut. " +
            "Log diagnostik hanya berisi peristiwa koneksi.",
        "Baterai dan sumber daya" to
            "Pemakaian sumber daya di latar belakang sangat kecil. Tidak ada proses yang terus berputar saat layar mati; " +
            "aplikasi hanya bekerja saat ada kueri DNS masuk. Koneksi terenkripsi tertutup sendiri saat tidak dipakai.",
        "Perlu diketahui" to
            "Android hanya mengizinkan satu VPN dalam satu waktu; aplikasi ini tidak bisa terhubung saat aplikasi VPN lain aktif. " +
            "Setelan \"DNS aman\" di browser dan \"DNS Pribadi\" Android yang diatur ke nama host tertentu memakai server sendiri " +
            "dan bisa melewati pengalihan ini; cukup biarkan di \"Otomatis\" atau \"Nonaktif\". " +
            "Tekan lama bola untuk cepat beralih ke server yang biasa kamu pakai atau menjeda koneksi sebentar.",
    )

    override val NOTIF_CHANNEL = "Status koneksi"
    override val NOTIF_CHANNEL_NOTE = "Ditampilkan saat koneksi DNS aktif"
    override val NOTIF_ALERT_CHANNEL = "Peringatan koneksi"
    override val NOTIF_CONNECTING = "Menghubungkan…"
    override val NOTIF_STOP = "Putuskan"
    override val NOTIF_NEXT = "Berikutnya"
    override val NOTIF_DROP_TITLE = "Koneksi DNS terputus"
    override val NOTIF_RECONNECT = "Sambung ulang"
    override fun notifOn(name: String, proto: String) = "Terhubung ke $name · $proto"
    override fun notifPaused(time: String) = "Dijeda · lanjut pukul $time"
    override val TILE_ON = "Terhubung"
    override val TILE_OFF = "Mati"
    override val WIDGET_TAP = "Ketuk: hubungkan / putuskan"
    override val ERR_PERMISSION = "Izin VPN tidak diberikan"
    override val ERR_ESTABLISH = "Antarmuka VPN tidak bisa dibuka. Mungkin ada VPN lain yang aktif."
    override fun errNoReply(name: String) = "$name tidak merespons"
    override fun errNoProto(name: String, proto: String) = "$name tidak mendukung $proto"
    override val ERR_SOCKET = "Tidak dapat menjangkau jaringan"
    override fun errPrivateDns(host: String) = "DNS Pribadi Android diatur ke $host dan melewati aplikasi ini. Ubah Setelan > Jaringan > DNS Pribadi ke Otomatis atau Nonaktif."
    override val ERR_REVOKED = "Koneksi ditutup oleh sistem"
    override val ERR_TUNNEL = "Terowongan tertutup secara tak terduga"
    override val ERR_UNKNOWN = "Terjadi kesalahan tak terduga"

    override val CONSENT_TITLE = "Sebelum terhubung"
    override val CONSENT_BODY = listOf(
        "$APP memakai antarmuka VPN Android untuk mengarahkan kueri DNS kamu (nama situs yang kamu kunjungi) ke server DNS pilihanmu.",
        "Lalu lintasmu tidak dikirim ke server VPN; hanya kueri DNS yang dikirim ke penyedia pilihanmu. Di server yang mendukung, " +
            "kueri dienkripsi (DoT/DoH); jika tidak, kueri dikirim tanpa enkripsi. Kebijakan privasi penyedia tersebut berlaku.",
        "Aplikasi ini tidak mengumpulkan data pribadi, tidak menyimpan nama kueri, dan tidak membagikan apa pun kepada siapa pun.",
        "Jika lanjut, Android akan menampilkan permintaan koneksi VPN; kamu perlu mengetuk \"OK\".",
    )
    override val CONSENT_OK = "Mengerti, lanjutkan"
    override val CLOSE = "Tutup"
    override val BACK = "Kembali"

    override val RESUMING = "Melanjutkan…"
    override val DOWNGRADED = "Gagal mengenkripsi, pakai DNS biasa"
    override val UPGRADED = "Kembali ke DNS terenkripsi"
    override val NOTIF_DOWNGRADE_TITLE = "DNS tidak terenkripsi"
    override fun notifDowngrade(name: String) = "Tidak bisa membuat koneksi terenkripsi ke $name. DNS biasa sedang dipakai; aplikasi akan mencoba kembali ke enkripsi."
    override fun backupUsed(failed: String, used: String) = "$failed tidak merespons, terhubung ke $used"
    override val NOTIF_RETRYING = "Koneksi putus, mencoba lagi…"
    override fun errNoEncrypted(name: String) = "Tidak bisa membuat koneksi terenkripsi ke $name"
    override val APPLYING = "Menerapkan pengaturan baru ke koneksi"
    override val CONFIRM_DISCONNECT = "Putuskan koneksi?"
    override val DISCONNECT = "Putuskan"

    override val SEC_NOTIF = "Notifikasi"
    override val STRICT_ENC = "Enkripsi ketat"
    override val STRICT_ENC_NOTE = "Jangan pernah beralih ke DNS biasa"
    override val AUTO_RECONNECT = "Sambung ulang otomatis"
    override val AUTO_RECONNECT_NOTE = "Jika koneksi putus, coba lagi setelah 5 dtk, 30 dtk, dan 2 mnt"
    override val BACKUP_SERVER = "Server cadangan"
    override val BACKUP_OFF = "Mati"
    override val BACKUP_OFF_NOTE = "Jangan terhubung jika server pilihan tidak merespons"
    override val BACKUP_FASTEST = "Tercepat"
    override val BACKUP_FASTEST_NOTE = "Server lain yang tercepat dari cek terakhir"
    override val CONFIRM_OFF = "Tanya sebelum memutuskan"
    override val CONFIRM_OFF_NOTE = "Ketukan tak sengaja pada bola tidak memutus koneksi"
    override val LOCK_HIDE = "Sembunyikan di layar kunci"
    override val LOCK_HIDE_NOTE = "Nama server tidak tampil di notifikasi layar kunci"
    override val QUIET_NOTIF = "Notifikasi senyap"
    override val QUIET_NOTIF_NOTE = "Tanpa ikon di bilah status, tanpa suara"
    override val REMEMBER_FILTER = "Ingat filter terakhir"
    override val REMEMBER_FILTER_NOTE = "Filter yang terakhir kamu pilih muncul lagi saat aplikasi dibuka"
    override val AUTO_MEASURE = "Ukur saat dibuka"
    override val AUTO_MEASURE_NOTE = "Ukur otomatis jika cek terakhir sudah lebih dari sehari"
    override val MEASURE_ENC = "Pengukuran terenkripsi"
    override val MEASURE_ENC_NOTE = "Ukur kecepatan lewat DoT, lebih mirip pemakaian terenkripsi"
    override val OPT_SORT = listOf("Bawaan", "Kecepatan", "Nama")
    override fun sortA11y(mode: String) = "Urutkan: $mode"
    override val AUTO_LIGHT = "Otomatis: tema terang"
    override val AUTO_DARK = "Otomatis: tema gelap"
    override val NIGHT_HOURS = "Jam malam"
    override val FILTER_ENCRYPTED = "Terenkripsi"
    override val FILTER_UNFILTERED = "Tanpa filter"

    override val TEST = "Tes koneksi"
    override val TEST_NOTE = "DNS, DNSSEC, dan blokir iklan"
    override val TESTING = "Menguji…"
    override val TEST_TITLE = "Tes koneksi"
    override val TEST_OK = "DNS berfungsi"
    override val TEST_FAIL = "Tidak ada respons"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Metode"
    override val TEST_LATENCY = "Waktu respons"
    override val TEST_DNSSEC = "Validasi DNSSEC"
    override val TEST_ADS = "Blokir iklan"
    override val DNSSEC_YES = "Memvalidasi"
    override val DNSSEC_NO = "Tidak memvalidasi"
    override val ADS_YES = "Aktif"
    override val ADS_NO = "Nonaktif"
    override val UNKNOWN = "Tidak diketahui"
    override val TEST_EXPLAIN = "Pertanyaan dikirim melalui terowongan, sama seperti saat sebuah aplikasi bertanya; jawabannya datang dari server pilihanmu."
    override val TEST_AGAIN = "Tes lagi"

    override val RECOMMEND = "Carikan server untukku"
    override val RECOMMEND_NOTE = "Pilih tujuanmu, kami hubungkan ke yang cocok dan tercepat"
    override val GOAL_SPEED = "Kecepatan"
    override val GOAL_SPEED_NOTE = "Server tercepat menurut pengukuranmu"
    override val GOAL_PRIVACY_NOTE = "Tanpa log, fokus privasi"
    override val GOAL_ADS_NOTE = "Memblokir iklan dan pelacak"
    override val GOAL_FAMILY_NOTE = "Memblokir konten dewasa"
    override val GOAL_SECURITY_NOTE = "Memblokir situs berbahaya dan phishing"
    override fun recommended(name: String) = "Rekomendasi: $name"

    override val PRIVATE_DNS = "Nama DNS Pribadi"
    override val PRIVATE_DNS_NOTE = "Kamu bisa menempelkannya di setelan DNS Pribadi Android. Sistem lalu memakai server ini secara langsung dan aplikasi ini dilewati."
    override val CLEAR_HISTORY = "Hapus riwayat kecepatan"
    override val HISTORY_CLEARED = "Pengukuran dihapus"

    override val GUARD = "Perlindungan selalu aktif"
    override val GUARD_NOTE = "VPN selalu aktif"
    override val GUARD_BODY = listOf(
        "Saat aplikasi tidak terhubung (dimatikan, dijeda, atau setelah putus), kueri DNS kamu dikirim ke server penyedia internetmu.",
        "Untuk mencegahnya, aktifkan \"VPN selalu aktif\" untuk aplikasi ini di setelan VPN Android. Jika \"Blokir koneksi tanpa VPN\" juga aktif, internet sama sekali tidak berfungsi saat aplikasi tidak terhubung: tidak ada kebocoran, tapi menjeda juga berarti tanpa internet.",
        "Dengan VPN selalu aktif, sistem menjalankan aplikasi secara otomatis saat ponsel menyala dan setelah aplikasi berhenti.",
    )
    override val GUARD_BUTTON = "Buka setelan VPN sistem"
    override val BATTERY = "Setelan baterai"
    override val BATTERY_OK = "Tidak dibatasi"
    override val BATTERY_LIMITED = "Mungkin dibatasi"
    override val BATTERY_BODY = listOf(
        "Android biasanya melindungi aplikasi VPN. Namun, beberapa produsen (Xiaomi, Huawei, Oppo, Vivo, beberapa versi Samsung) bisa menutup aplikasi di latar belakang untuk menghemat baterai.",
        "Jika koneksi sering putus sendiri, atur penggunaan baterai aplikasi ini ke \"Tidak dibatasi\" atau \"Tidak dioptimalkan\"; di beberapa ponsel, izinkan juga \"Mulai otomatis\".",
    )
    override val BATTERY_BUTTON = "Buka setelan baterai"

    override val STAT_AVG = "Rata-rata waktu respons"
    override val STAT_SAVED = "Waktu yang dihemat cache"
    override val STAT_TRAFFIC = "Lalu lintas DNS"
    override val SESSIONS = "Riwayat koneksi"
    override val SESSIONS_NOTE = "30 koneksi terakhir; nama kueri tidak pernah disimpan"
    override val SESSIONS_EMPTY = "Belum ada koneksi yang tercatat."
    override val MOST_USED = "Paling sering dipakai"
    override val TODAY = "Hari ini"
    override val YESTERDAY = "Kemarin"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Kamu putuskan"
        EndReason.PAUSE -> "Dijeda"
        EndReason.SWITCH -> "Server diganti"
        EndReason.DROP -> "Terputus"
        EndReason.REVOKED -> "Ditutup sistem"
        EndReason.FAILED -> "Tak merespons"
        EndReason.NETWORK -> "Jaringan berganti"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries kueri"

    override val WHATS_NEW = "Apa yang baru?"
    override val WHATS_NEW_TOAST = "Aplikasi telah diperbarui"
    override val SHOW = "Lihat"
    override val WHATS_NEW_ITEMS = listOf(
        "Koneksi lebih aman: pemeriksaan tambahan terhadap jawaban DNS palsu, peringatan saat beralih ke DNS biasa, opsi enkripsi ketat, dan kembali ke enkripsi secara otomatis.",
        "Tes koneksi: cek dengan sekali ketuk bahwa DNS dijawab oleh server pilihanmu, plus validasi DNSSEC dan blokir iklan.",
        "Server cadangan dan sambung ulang otomatis: aplikasi pulih sendiri jika server pilihan tidak merespons atau koneksi putus.",
        "Riwayat koneksi, server yang paling sering dipakai, rata-rata waktu respons, dan lalu lintas DNS.",
        "Filter baru (Terenkripsi, Tanpa filter), urutkan menurut nama, \"Carikan server untukku\", dan pengukuran saat dibuka.",
        "Penghitung langsung di notifikasi, tombol jeda 15 menit, sembunyikan di layar kunci, dan opsi notifikasi senyap.",
        "Tiga tema baru (Sakura, Madu, Aurora), tema dari wallpaper, dan pilihan terang/gelap untuk tema otomatis.",
        "Empat bahasa baru: Indonesia, Vietnam, Polandia, dan Ukraina.",
    )
    override fun importedWith(changes: String) = "Pengaturan dimuat · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "enkripsi melemah"
        SensitiveChange.AUTO_START -> "sambung otomatis diaktifkan"
        SensitiveChange.RULES -> "aturan server diubah"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries kueri · $blocked diblokir"
    override val NOTIF_LOCKED = "Perlindungan DNS aktif"
    override val NOTIF_QUIET_CHANNEL = "Status koneksi (senyap)"
    override fun widgetToday(queries: String) = "Hari ini $queries kueri"
    override fun pauseAction(minutes: Int) = "Jeda ${minutes(minutes)}"

    override val NOTES = mapOf(
        "cloudflare" to "Cepat, fokus privasi",
        "google" to "Stabil, banyak dipakai",
        "quad9" to "Memblokir domain berbahaya",
        "adguard" to "Memblokir iklan dan pelacak",
        "controld" to "Tanpa filter, cepat",
        "opendns" to "Cisco, perlindungan phishing",
        "mullvad" to "Tanpa log, hanya terenkripsi",
        "dnssb" to "Fokus privasi, cepat",
        "dns4eu" to "DNS Uni Eropa, anti-malware",
        "uncensored" to "Tanpa filter atau pengalihan",
        "quad9-open" to "Tanpa pemblokiran",
        "adguard-open" to "Tanpa blokir, fokus privasi",
        "dns4eu-open" to "DNS Uni Eropa, tanpa filter",
        "controld-ads" to "Iklan, pelacak, malware",
        "mullvad-ads" to "Iklan dan pelacak, hanya terenkripsi",
        "dns4eu-ads" to "DNS Uni Eropa, iklan dan malware",
        "cloudflare-security" to "Memblokir situs berbahaya",
        "controld-malware" to "Memblokir situs berbahaya",
        "cleanbrowsing-security" to "Phishing dan situs berbahaya",
        "cloudflare-family" to "Filter malware dan konten dewasa",
        "opendns-family" to "Filter konten dewasa",
        "adguard-family" to "Filter iklan dan konten dewasa",
        "cleanbrowsing-family" to "Konten dewasa, pencarian aman",
        "dns4eu-child" to "DNS Uni Eropa, perlindungan anak",
        "mullvad-family" to "Filter keluarga, hanya terenkripsi",
        "controld-family" to "Filter konten dewasa",
    )
}
