package app.dnshizli.platform

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import app.dnshizli.R
import app.dnshizli.core.Catalog
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi

/**
 * Hızlı ayarlar kutucuğu: uygulamayı açmadan tek dokunuşla bağlan/kes. Yalnızca panel görünürken dinler.
 * VPN izni yoksa ya da ilk açılış bilgilendirmesi gösterilmediyse uygulamayı açar.
 */
class DnsTileService : TileService() {
    private val listener: (VpnUi) -> Unit = { update(it) }

    override fun onStartListening() {
        VpnStatus.addListener(listener)
        update(VpnStatus.snapshot())
    }

    override fun onStopListening() {
        VpnStatus.removeListener(listener)
    }

    override fun onClick() {
        val ui = VpnStatus.snapshot()
        if (ui.active) {
            try {
                startForegroundService(DnsVpnService.disconnectIntent(this))
            } catch (_: Exception) {
                openApp(DnsVpnService.ACTION_DISCONNECT)
            }
            return
        }
        val settings = PrefsStore(this).loadSettings()
        val ready = settings.onboarded && try { VpnService.prepare(this) == null } catch (_: Exception) { false }
        if (!ready) { openApp(DnsVpnService.ACTION_CONNECT); return }
        try {
            startForegroundService(DnsVpnService.connectIntent(this, null))
        } catch (_: Exception) {
            openApp(DnsVpnService.ACTION_CONNECT)
        }
    }

    private fun openApp(action: String) {
        val intent = Intent(this, MainActivity::class.java).setAction(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(this, 2, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        } catch (_: Exception) {
            // panel kapalıysa ya da sistem reddettiyse yapacak bir şey yok
        }
    }

    private fun update(ui: VpnUi) {
        val tile = qsTile ?: return
        tile.state = if (ui.active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = Strings.APP
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = if (ui.active) Catalog.byId(ui.serverId)?.name ?: Strings.TILE_ON else Strings.TILE_OFF
        }
        tile.updateTile()
    }
}
