package app.dnshizli.core

/** ARGB renk yardımcıları (Android'e bağlı değil, JVM'de test edilebilir). */
object Rgb {
    const val WHITE: Int = -1                       // 0xFFFFFFFF
    const val TRANSPARENT: Int = 0

    fun a(c: Int) = (c ushr 24) and 0xFF
    fun r(c: Int) = (c ushr 16) and 0xFF
    fun g(c: Int) = (c ushr 8) and 0xFF
    fun b(c: Int) = c and 0xFF

    fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        (a.coerceIn(0, 255) shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /** Rengin RGB'sini koruyup saydamlığını [alpha] (0..1) yapar. */
    fun alpha(c: Int, alpha: Float): Int =
        (c and 0x00FFFFFF) or ((alpha.coerceIn(0f, 1f) * 255f + 0.5f).toInt() shl 24)

    /** Rengin mevcut saydamlığını [k] ile çarpar. */
    fun scaleAlpha(c: Int, k: Float): Int = alpha(c, (a(c) / 255f) * k)

    fun lerp(x: Int, y: Int, t: Float): Int {
        val u = t.coerceIn(0f, 1f)
        fun m(p: Int, q: Int) = (p + (q - p) * u + 0.5f).toInt()
        return argb(m(a(x), a(y)), m(r(x), r(y)), m(g(x), g(y)), m(b(x), b(y)))
    }

    /** [top] rengini [bottom] üzerine koyar (standart alfa birleştirme). */
    fun over(top: Int, bottom: Int): Int {
        val ta = a(top) / 255.0
        val ba = a(bottom) / 255.0
        val ra = ta + ba * (1 - ta)
        if (ra <= 0.0) return 0
        fun ch(t: Int, b: Int) = ((t * ta + b * ba * (1 - ta)) / ra + 0.5).toInt()
        return argb((ra * 255 + 0.5).toInt(), ch(r(top), r(bottom)), ch(g(top), g(bottom)), ch(b(top), b(bottom)))
    }

    /** WCAG göreli parlaklık (opak renk varsayılır). */
    fun luminance(c: Int): Double {
        fun lin(v: Int): Double {
            val s = v / 255.0
            return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * lin(r(c)) + 0.7152 * lin(g(c)) + 0.0722 * lin(b(c))
    }

    /** WCAG kontrast oranı (1..21). */
    fun contrast(x: Int, y: Int): Double {
        val l1 = luminance(x)
        val l2 = luminance(y)
        return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05)
    }
}

/**
 * Cam yüzeylerin dolgu şeffaflığı: kaydırıcı değeri [g] 0..1. Koyu temada cam rengi açık olduğu için
 * dolgu çok daha az opak tutulur (açık yazı okunaklı kalsın diye).
 */
object GlassMath {
    private const val DARK_SCALE = 0.20f
    fun top(g: Float, dark: Boolean = false): Float =
        (0.34f + (0.80f - 0.34f) * g.coerceIn(0f, 1f)) * (if (dark) DARK_SCALE else 1f)

    fun bottom(g: Float, dark: Boolean = false): Float =
        (0.22f + (0.52f - 0.22f) * g.coerceIn(0f, 1f)) * (if (dark) DARK_SCALE else 1f)
}

/**
 * Frutiger Aero renk teması: gökyüzü gradyanı, cam rengi, canlı vurgu rengi ve okunaklı metin renkleri.
 *  - accentLight/accent/accentDeep: sıvı, parıltı ve vurgular için canlı tonlar.
 *  - control/controlDeep: seçili düğme dolgusu; beyaz yazı bunların üzerinde okunur (>= 4.5:1).
 *  - text/textSoft/link: cam kartların üzerinde her cam yoğunluğunda >= 4.5:1 kontrast verir.
 */
class AeroTheme(
    val id: String,
    val name: String,
    val dark: Boolean,
    val skyTop: Int,
    val skyMid: Int,
    val skyBottom: Int,
    val accentLight: Int,
    val accent: Int,
    val accentDeep: Int,
    val control: Int,
    val controlDeep: Int,
    val glow: Int,
    val text: Int,
    val textSoft: Int,
    val link: Int,
    val tint: Int,
    val shadow: Int,
) {
    val onControl: Int get() = Rgb.WHITE

    /** Gökyüzü gradyanındaki rengi [y] (0 üst, 1 alt) konumunda döner. */
    fun skyAt(y: Float): Int =
        if (y <= SKY_MID_POS) Rgb.lerp(skyTop, skyMid, y / SKY_MID_POS)
        else Rgb.lerp(skyMid, skyBottom, (y - SKY_MID_POS) / (1f - SKY_MID_POS))

    companion object {
        const val SKY_MID_POS = 0.55f

        /** İki tema arasında renk renk geçiş. [t]=0 -> a, [t]=1 -> b. */
        fun lerp(a: AeroTheme, b: AeroTheme, t: Float): AeroTheme {
            if (t <= 0f) return a
            if (t >= 1f) return b
            fun m(x: Int, y: Int) = Rgb.lerp(x, y, t)
            return AeroTheme(
                id = if (t < 0.5f) a.id else b.id,
                name = if (t < 0.5f) a.name else b.name,
                dark = if (t < 0.5f) a.dark else b.dark,
                skyTop = m(a.skyTop, b.skyTop), skyMid = m(a.skyMid, b.skyMid), skyBottom = m(a.skyBottom, b.skyBottom),
                accentLight = m(a.accentLight, b.accentLight), accent = m(a.accent, b.accent),
                accentDeep = m(a.accentDeep, b.accentDeep),
                control = m(a.control, b.control), controlDeep = m(a.controlDeep, b.controlDeep),
                glow = m(a.glow, b.glow), text = m(a.text, b.text), textSoft = m(a.textSoft, b.textSoft),
                link = m(a.link, b.link), tint = m(a.tint, b.tint), shadow = m(a.shadow, b.shadow),
            )
        }
    }
}

object Themes {
    const val AUTO_ID = "auto"

    private fun c(rgb: Int): Int = rgb or (0xFF shl 24)

    val aqua = AeroTheme(
        id = "aqua", name = "Aqua", dark = false,
        skyTop = c(0xDDF8FF), skyMid = c(0x9BE4F8), skyBottom = c(0x58BDEB),
        accentLight = c(0x7CF0E2), accent = c(0x19C6C0), accentDeep = c(0x0F8FB5),
        control = c(0x0B7E9B), controlDeep = c(0x08627E),
        glow = c(0x5FE3E8), text = c(0x06304A), textSoft = c(0x1F4A63), link = c(0x05526E),
        tint = Rgb.WHITE, shadow = c(0x0A4F7A),
    )

    val meadow = AeroTheme(
        id = "meadow", name = "Çimen", dark = false,
        skyTop = c(0xDFF7FF), skyMid = c(0xA9EBC4), skyBottom = c(0x62CF73),
        accentLight = c(0xB4F76A), accent = c(0x3DCC5A), accentDeep = c(0x1E9A4A),
        control = c(0x18813F), controlDeep = c(0x0F6A32),
        glow = c(0x8CF07A), text = c(0x0A3520), textSoft = c(0x244F36), link = c(0x0F5C2E),
        tint = Rgb.WHITE, shadow = c(0x0F6B3A),
    )

    val ocean = AeroTheme(
        id = "ocean", name = "Okyanus", dark = false,
        skyTop = c(0xD6EEFF), skyMid = c(0x8EC3F8), skyBottom = c(0x5C97E8),
        accentLight = c(0x6FE0FF), accent = c(0x2B9DF5), accentDeep = c(0x1B62C9),
        control = c(0x1B62C9), controlDeep = c(0x154CA3),
        glow = c(0x6BC7FF), text = c(0x0A2547), textSoft = c(0x1F3E66), link = c(0x0C3A84),
        tint = Rgb.WHITE, shadow = c(0x1B4FA0),
    )

    val sunset = AeroTheme(
        id = "sunset", name = "Gün batımı", dark = false,
        skyTop = c(0xFFE9CC), skyMid = c(0xFFB59E), skyBottom = c(0xE88AB8),
        accentLight = c(0xFFD27A), accent = c(0xFF8A5B), accentDeep = c(0xD9487B),
        control = c(0xC23A68), controlDeep = c(0xA12C57),
        glow = c(0xFFB07A), text = c(0x3B1740), textSoft = c(0x5C2F58), link = c(0x82204A),
        tint = Rgb.WHITE, shadow = c(0x9A3A6A),
    )

    val lavender = AeroTheme(
        id = "lavender", name = "Lavanta", dark = false,
        skyTop = c(0xF0E6FF), skyMid = c(0xC8B0F8), skyBottom = c(0x9A82E6),
        accentLight = c(0xD2B8FF), accent = c(0x9B6BF2), accentDeep = c(0x6D45D6),
        control = c(0x6B43D1), controlDeep = c(0x5532B0),
        glow = c(0xC4A6FF), text = c(0x2A1A55), textSoft = c(0x3C2D70), link = c(0x432596),
        tint = Rgb.WHITE, shadow = c(0x4B3A9A),
    )

    val night = AeroTheme(
        id = "night", name = "Gece", dark = true,
        skyTop = c(0x07122B), skyMid = c(0x0B2A55), skyBottom = c(0x0A4562),
        accentLight = c(0x8CF5E6), accent = c(0x2FD9C6), accentDeep = c(0x1197B5),
        control = c(0x0B7E9B), controlDeep = c(0x08627E),
        glow = c(0x37E0D0), text = c(0xEAF7FF), textSoft = c(0xC2DAEE), link = c(0x8CF5E6),
        tint = c(0xE4F2FF), shadow = c(0x000000),
    )

    val all: List<AeroTheme> = listOf(aqua, meadow, ocean, sunset, lavender, night)

    fun isValidId(id: String): Boolean = id == AUTO_ID || all.any { it.id == id }

    fun byId(id: String): AeroTheme? {
        val l = all
        for (i in 0 until l.size) { val t = l[i]; if (t.id == id) return t }
        return null
    }

    /** Kullanıcının seçimini ("auto" dahil) gerçek temaya çevirir. */
    fun resolve(id: String, systemDark: Boolean): AeroTheme =
        if (id == AUTO_ID) (if (systemDark) night else aqua) else (byId(id) ?: aqua)
}
