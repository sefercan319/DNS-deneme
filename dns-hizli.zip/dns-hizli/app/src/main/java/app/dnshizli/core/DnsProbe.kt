package app.dnshizli.core

import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.security.SecureRandom

/**
 * Bir DNS sunucusunun gecikmesini ölçer. VPN açıkken de çalışır: tünele sadece sahte DNS adresi
 * yönlendirildiği için bu sorgular doğrudan ağdan çıkar.
 */
object DnsProbe {
    private val random = SecureRandom()

    /**
     * [host]:[port] adresine "example.com A" sorgusu yollar; [attempts] denemenin en hızlısını
     * milisaniye olarak döner. Hiçbirine cevap gelmezse null.
     */
    fun measure(host: String, port: Int = 53, timeoutMs: Int = 1500, attempts: Int = 2): Int? {
        val target = try { InetAddress.getByName(host) } catch (_: IOException) { return null }
        var best: Int? = null
        try {
            DatagramSocket().use { s ->
                repeat(attempts) {
                    val id = random.nextInt(65536)
                    val query = Dns.buildQuery(id, "example.com")
                    val buf = ByteArray(512)
                    val reply = DatagramPacket(buf, buf.size)
                    val t0 = System.nanoTime()
                    val deadline = t0 + timeoutMs * 1_000_000L
                    try {
                        s.send(DatagramPacket(query, query.size, target, port))
                        while (true) {
                            val left = ((deadline - System.nanoTime()) / 1_000_000).toInt()
                            if (left <= 0) break
                            s.soTimeout = left
                            reply.length = buf.size
                            s.receive(reply)
                            val isAnswer = reply.length >= Packets.DNS_HDR &&
                                reply.address == target &&
                                Packets.u16(buf, 0) == id &&
                                (buf[2].toInt() and 0x80) != 0
                            if (isAnswer) {
                                val ms = ((System.nanoTime() - t0) / 1_000_000).toInt()
                                best = minOf(best ?: Int.MAX_VALUE, ms)
                                break
                            }
                        }
                    } catch (_: SocketTimeoutException) {
                        // bu deneme cevapsız
                    } catch (_: IOException) {
                        // ağ yok; sonraki deneme
                    }
                }
            }
        } catch (_: IOException) {
            // soket açılamadı
        }
        return best
    }
}
