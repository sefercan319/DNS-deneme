package app.dnshizli.core

import java.io.EOFException
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.SecureRandom
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Bir ölçümün sonucu: cevaplanan denemelerin süreleri (ms) ve toplam deneme sayısı. */
class ProbeResult(val times: List<Int>, val attempts: Int) {
    val best: Int? get() = times.minOrNull()

    /** Ortanca (çift sayıda ölçümde alttaki). */
    val median: Int? get() = if (times.isEmpty()) null else times.sorted()[(times.size - 1) / 2]

    /** Cevapsız kalan denemelerin yüzdesi. */
    val lossPct: Int get() = if (attempts <= 0) 0 else ((attempts - times.size) * 100 + attempts / 2) / attempts
}

/**
 * Bir DNS sunucusunun gecikmesini ölçer. VPN açıkken de çalışır: tünele sadece sahte DNS adresi
 * yönlendirildiği için bu sorgular doğrudan ağdan çıkar.
 */
object DnsProbe {
    private val random = SecureRandom()

    /** [probe] sonucunun en iyisi; hiç cevap yoksa null. (Eski arayüz.) */
    fun measure(host: String, port: Int = 53, timeoutMs: Int = 1500, attempts: Int = 2): Int? =
        probe(host, port, timeoutMs, attempts).best

    /** [host]:[port] adresine [attempts] kez "example.com A" sorgusu (düz DNS/UDP) yollar. */
    fun probe(host: String, port: Int = 53, timeoutMs: Int = 1500, attempts: Int = 3): ProbeResult {
        val target = try { InetAddress.getByName(host) } catch (_: IOException) { return ProbeResult(emptyList(), attempts) }
        val times = ArrayList<Int>(attempts)
        try {
            DatagramSocket().use { s ->
                repeat(attempts) {
                    val id = random.nextInt(65536)
                    val query = Dns.buildQuery(id, "example.com")
                    val buf = ByteArray(512)
                    val reply = DatagramPacket(buf, buf.size)
                    val t0 = System.nanoTime()
                    val deadline = t0 + timeoutMs * 1_000_000L
                    try {
                        s.send(DatagramPacket(query, query.size, target, port))
                        while (true) {
                            val left = ((deadline - System.nanoTime()) / 1_000_000).toInt()
                            if (left <= 0) break
                            s.soTimeout = left
                            reply.length = buf.size
                            s.receive(reply)
                            val isAnswer = reply.length >= Packets.DNS_HDR &&
                                reply.address == target && reply.port == port &&
                                Packets.u16(buf, 0) == id &&
                                Dns.sameQuestion(query, 0, Dns.questionEnd(query, 0, query.size), buf, 0, reply.length)
                            if (isAnswer) {
                                times.add(((System.nanoTime() - t0) / 1_000_000).toInt())
                                break
                            }
                        }
                    } catch (_: SocketTimeoutException) {
                        // bu deneme cevapsız
                    } catch (_: IOException) {
                        // ağ yok; sonraki deneme
                    }
                }
            }
        } catch (_: IOException) {
            // soket açılamadı
        }
        return ProbeResult(times, attempts)
    }

    /**
     * Yalnızca şifreli çalışan sunucular için: DoT bağlantısı kurulur (el sıkışma süresi sayılmaz), sonra
     * aynı bağlantıda [attempts] soru-cevabın süresi ölçülür. Böylece sonuç düz DNS ölçümüyle karşılaştırılabilir.
     */
    fun probeTls(
        ip: String, tlsHost: String, port: Int = 853, timeoutMs: Int = 2500, attempts: Int = 3,
        tls: SSLSocketFactory = SSLSocketFactory.getDefault() as SSLSocketFactory,
        verifier: HostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier(),
    ): ProbeResult {
        val times = ArrayList<Int>(attempts)
        var sock: SSLSocket? = null
        var raw: Socket? = null
        try {
            raw = Socket()
            raw.connect(InetSocketAddress(InetAddress.getByName(ip), port), timeoutMs)
            raw.soTimeout = timeoutMs
            val s = tls.createSocket(raw, tlsHost, port, true) as SSLSocket
            sock = s
            s.soTimeout = timeoutMs
            s.startHandshake()
            if (!verifier.verify(tlsHost, s.session)) return ProbeResult(emptyList(), attempts)
            val out = s.outputStream
            val inp = s.inputStream
            val buf = ByteArray(4096)
            repeat(attempts) {
                val id = random.nextInt(65536)
                val q = Dns.buildQuery(id, "example.com")
                val t0 = System.nanoTime()
                val frame = ByteArray(q.size + 2)
                frame[0] = (q.size ushr 8).toByte(); frame[1] = q.size.toByte()
                System.arraycopy(q, 0, frame, 2, q.size)
                out.write(frame); out.flush()
                val hi = inp.read(); val lo = inp.read()
                if (hi < 0 || lo < 0) throw EOFException()
                val len = (hi shl 8) or lo
                if (len > buf.size || len < Packets.DNS_HDR) throw IOException("geçersiz uzunluk")
                var got = 0
                while (got < len) { val r = inp.read(buf, got, len - got); if (r < 0) throw EOFException(); got += r }
                if (Packets.u16(buf, 0) == id) times.add(((System.nanoTime() - t0) / 1_000_000).toInt())
            }
        } catch (_: IOException) {
            // bağlantı kurulamadı ya da koptu: kalan denemeler cevapsız sayılır
        } finally {
            try { sock?.close() ?: raw?.close() } catch (_: Exception) {}
        }
        return ProbeResult(times, attempts)
    }
}

/**
 * Şifreli DNS sunucusunun adresini bulmak için ilk çözümleme ("bootstrap"): tünel açıkken sistemin çözümleyicisi
 * zaten bize yönlendiği için kullanılamaz; bunun yerine sağlayıcının kendi düz DNS adresine doğrudan (tünel dışı,
 * korumalı soketle) tek bir A sorgusu gönderilir. Cevap gelmezse boş liste döner (çağıran, sağlayıcının bilinen IP'sini kullanır).
 *
 * Bu tek sorgu şifresizdir; sahte bir cevap en fazla bağlantıyı başka bir adrese yöneltebilir (TLS sertifika adı
 * denetimi yine de geçmez). Yine de: cevabın kaynağı (adres ve 53. port), kimliği ve soru bölümü denetlenir, yalnızca
 * herkese açık (global) IPv4 adresleri kabul edilir.
 */
object Bootstrap {
    private val random = SecureRandom()

    fun resolveA(
        name: String, dnsIp: String, port: Int = 53, timeoutMs: Int = 1500,
        newSocket: () -> DatagramSocket = { DatagramSocket() },
    ): List<String> {
        val target = try { InetAddress.getByName(dnsIp) } catch (_: IOException) { return emptyList() }
        try {
            newSocket().use { s ->
                repeat(2) {
                    val id = random.nextInt(65536)
                    val q = Dns.buildQuery(id, name)
                    val buf = ByteArray(1500)
                    val reply = DatagramPacket(buf, buf.size)
                    try {
                        s.soTimeout = timeoutMs
                        s.send(DatagramPacket(q, q.size, target, port))
                        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
                        while (System.nanoTime() < deadline) {
                            reply.length = buf.size
                            s.receive(reply)
                            if (reply.address != target || reply.port != port) continue
                            if (reply.length < Packets.DNS_HDR || Packets.u16(buf, 0) != id) continue
                            if (!Dns.sameQuestion(q, 0, Dns.questionEnd(q, 0, q.size), buf, 0, reply.length)) continue
                            return Dns.aRecords(buf, reply.length).filter { isGlobal(it) }
                        }
                    } catch (_: SocketTimeoutException) {
                    } catch (_: IOException) {
                    }
                }
            }
        } catch (_: IOException) {
        }
        return emptyList()
    }

    private fun isGlobal(ip: String): Boolean {
        val p = ip.split('.')
        if (p.size != 4) return false
        val n = p.map { it.toIntOrNull() ?: return false }
        return Dns.isGlobalIpv4(n[0], n[1], n[2], n[3])
    }
}
