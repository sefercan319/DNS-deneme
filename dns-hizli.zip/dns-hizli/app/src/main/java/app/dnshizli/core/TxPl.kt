package app.dnshizli.core

/** Polski. */
object TxPl : Tx() {
    override val lang = Lang.PL

    override val decimalSep = ','
    override val thousand = " tys."
    override val million = " mln"
    override fun percent(n: Int) = "$n%"
    override val dayU = "d"
    override val hourU = "godz."
    override val minU = "min"
    override val secU = "s"
    override val justNow = "przed chwilą"
    override fun ago(span: String) = "$span temu"

    override val OFF = "Brak połączenia"
    override val CONNECTING = "Łączenie…"
    override val ON = "Połączono"
    override val ERROR = "Błąd połączenia"
    override val PAUSED = "Wstrzymano"
    override val HINT_OFF = "Dotknij kuli, aby połączyć"
    override val HINT_CONNECTING = "To może potrwać kilka sekund"
    override val HINT_ERROR = "Dotknij, aby spróbować ponownie"
    override val HINT_PAUSED = "Dotknij, aby wznowić teraz"
    override val ERR_DEFAULT = "Nie udało się połączyć"
    override fun selected(name: String) = "Wybrano: $name"
    override fun pausedUntil(time: String) = "Wznowienie o $time"
    override fun blockedShort(n: String) = "zablokowane: $n"
    override fun queriesShort(n: String) = "zapytania: $n"
    override fun cacheShort(pct: String) = "cache $pct"

    override val SERVERS = "Serwery"
    override val FILTER_ALL = "Wszystkie"
    override val FILTER_FAV = "Ulubione"
    override val FILTER_RECENT = "Ostatnie"
    override val EMPTY_FAV = "Brak ulubionych. Dotknij gwiazdki serwera."
    override val EMPTY_RECENT = "Nie było jeszcze połączeń z żadnym serwerem."
    override val EMPTY_FILTER = "Brak serwerów w tej kategorii."
    override val MEASURE = "Zmierz szybkość"
    override val MEASURING = "Pomiar…"
    override val SORT = "Sortowanie"
    override val PULL_TO_MEASURE = "Pociągnij, aby zmierzyć"
    override val RELEASE_TO_MEASURE = "Puść, aby zmierzyć"
    override fun serversCount(n: Int) = "serwery: $n"
    override val TAG_FAST = "Szybkie"
    override val TAG_PRIVACY = "Prywatność"
    override val TAG_ADS = "Bez reklam"
    override val TAG_FAMILY = "Rodzina"
    override val TAG_SECURITY = "Ochrona"
    override val VAR_OPEN = "Bez filtra"
    override val VAR_ADS = "Bez reklam"
    override val VAR_SECURITY = "Ochrona"
    override val VAR_FAMILY = "Rodzina"
    override val A11Y_CONNECTED = "połączono"
    override val A11Y_ENCRYPTED = "szyfrowany"
    override fun favA11y(name: String) = "$name w ulubionych"

    override val COPIED = "Skopiowano do schowka"
    override val DISCONNECTED = "Rozłączono"
    override val BACKUP = "Przełączono na serwer zapasowy"
    override val NO_REPLY = "Żaden serwer nie odpowiedział"
    override val MEASURE_FIRST = "Najpierw zmierz szybkość"
    override val CONNECT = "Połącz"
    override val UNDO = "Cofnij"
    override fun fastest(name: String, ms: Int) = "Najszybszy: $name · $ms ms"
    override fun switched(name: String) = "Przełączanie na $name"
    override fun hiddenToast(name: String) = "Ukryto: $name"

    override val PRIMARY = "Podstawowy"
    override val SECONDARY = "Alternatywny"
    override val COPY = "Kopiuj"
    override fun addressA11y(label: String, ip: String) = "Adres ($label): $ip"
    override val CONNECT_TO_THIS = "Połącz z tym serwerem"
    override val SWITCH_TO_THIS = "Przełącz na ten serwer"
    override val CONNECTED_NOW = "Obecnie połączony"
    override val ADD_FAV = "Dodaj do ulubionych"
    override val REMOVE_FAV = "Usuń z ulubionych"
    override val MEASURE_THIS = "Zmierz szybkość"
    override val HIDE = "Ukryj na liście"
    override val UNHIDE = "Pokaż na liście"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Ostatni pomiar: brak odpowiedzi · $ago" else "Ostatni pomiar: $ms ms · $ago"
    override val NEVER_MEASURED = "Jeszcze nie zmierzono"
    override val ENC_SUPPORT = "Szyfrowany DNS"
    override val ENC_NONE = "Nieobsługiwany"
    override val ENC_ONLY = "Tylko połączenia szyfrowane"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Najlepszy $best ms · mediana $median ms · straty $lossPct%"
    override val HISTORY = "Historia pomiarów"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: liczba pomiarów $n, brak odpowiedzi" else "$HISTORY: liczba pomiarów $n, mediana $median ms"

    override val QUICK_TITLE = "Szybki wybór"
    override val QUICK_FAVORITES = "Ulubione"
    override val QUICK_RECENT = "Ostatnio używane"
    override val PAUSE_FOR = "Wstrzymaj"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} godz." else "$n min"
    override val RESUME = "Wznów"

    override val SETTINGS = "Ustawienia"
    override val SEC_LOOK = "Wygląd"
    override val SEC_CONNECTION = "Połączenie"
    override val SEC_PRIVACY = "Prywatność i ochrona"
    override val SEC_LIST = "Lista serwerów"
    override val SEC_INFO = "Statystyki"
    override val SEC_DATA = "Dane"
    override val SEC_ABOUT = "Informacje"
    override val LANGUAGE = "Język"
    override val LANG_AUTO = "Automatycznie (język systemu)"
    override val THEME = "Motyw"
    override val THEME_AUTO = "Automatyczny"
    override val THEME_AUTO_NOTE = "Automatyczny · jasny/ciemny jak w systemie"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Łąka"
        "ocean" -> "Ocean"
        "sunset" -> "Zachód słońca"
        "lavender" -> "Lawenda"
        "coral" -> "Koral"
        "mint" -> "Mięta"
        "sakura" -> "Sakura"
        "honey" -> "Miód"
        "night" -> "Noc"
        "amoled" -> "Czarny (AMOLED)"
        "aurora" -> "Zorza"
        "dynamic" -> "Tapeta"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Motyw: $name"
    override val THEME_SCHEDULE = "Motyw nocny według godzin"
    override val THEME_SCHEDULE_NOTE = "W trybie automatycznym ciemny motyw w wybranych godzinach"
    override val GLASS = "Przezroczystość szkła"
    override val BUBBLES = "Bąbelki"
    override val MOTION = "Animacje"
    override val TEXT_SIZE = "Rozmiar tekstu"
    override val HIGH_CONTRAST = "Wysoki kontrast"
    override val HIGH_CONTRAST_NOTE = "Mniej przezroczyste szkło i ciemniejszy tekst"
    override val MINIMAL = "Widok minimalny"
    override val MINIMAL_NOTE = "Ukrywa filtry i wiersz statystyk"
    override val LOW_POWER = "Oszczędzanie energii"
    override val LOW_POWER_NOTE = "Wyłącza wszystkie animacje, oszczędza baterię"
    override val HAPTICS = "Wibracje"
    override val HAPTICS_NOTE = "Delikatna reakcja na dotyk"
    override val ENCRYPTION = "Szyfrowany DNS"
    override val ENCRYPTION_NOTE = "Auto: najpierw DoT, potem DoH, na końcu zwykły DNS"
    override val AUTO_CONNECT = "Łącz po otwarciu aplikacji"
    override val AUTO_CONNECT_NOTE = "Łączy z ostatnim serwerem po otwarciu aplikacji"
    override val CONNECT_ON_BOOT = "Łącz po uruchomieniu"
    override val CONNECT_ON_BOOT_NOTE = "Łączy automatycznie po restarcie telefonu"
    override val AUTO_FASTEST = "Łącz z najszybszym"
    override val AUTO_FASTEST_NOTE = "Kula wybiera najszybszy serwer z ostatniego pomiaru"
    override val REFRESH_ON_NET = "Odświeżaj po zmianie sieci"
    override val REFRESH_ON_NET_NOTE = "DNS odświeża się przy przejściu między Wi-Fi a danymi komórkowymi"
    override val NOTIFY_DROP = "Powiadamiaj o rozłączeniu"
    override val NOTIFY_DROP_NOTE = "Powiadomienie z przyciskiem ponownego połączenia przy zerwaniu"
    override val CACHE = "Pamięć podręczna DNS"
    override val CLEAR_CACHE = "Wyczyść pamięć podręczną"
    override val CACHE_CLEARED = "Wyczyszczono pamięć podręczną"
    override val ONLY_CONNECTED = "Dostępne po połączeniu"
    override val RULE_WIFI = "Serwer dla Wi-Fi"
    override val RULE_MOBILE = "Serwer dla sieci komórkowej"
    override val RULE_AUTO = "Automatycznie"
    override val RULE_AUTO_NOTE = "Ostatnio używany serwer"
    override val COMPACT = "Kompaktowa lista"
    override val COMPACT_NOTE = "Niższe wiersze bez opisów"
    override val HIDDEN = "Ukryte serwery"
    override val HIDDEN_NONE = "Brak"
    override val STAT_QUERIES = "Zapytania łącznie"
    override val STAT_HITS = "Z pamięci podręcznej"
    override val STAT_BLOCKED = "Zablokowane (szacunkowo)"
    override val STAT_TIME = "Łączny czas połączenia"
    override val WEEK = "Ostatnie 7 dni"
    override fun weekA11y(total: String) = "Zapytania z ostatnich 7 dni: $total"
    override val WEEKDAYS = listOf("Pn", "Wt", "Śr", "Cz", "Pt", "So", "Nd")
    override val EXPORT = "Eksportuj ustawienia"
    override val IMPORT = "Importuj ustawienia"
    override val EXPORTED = "Skopiowano kod ustawień do schowka"
    override val IMPORTED = "Wczytano ustawienia"
    override val IMPORT_BAD = "Brak prawidłowego kodu ustawień w schowku"
    override val RESET_SETTINGS = "Resetuj ustawienia"
    override val RESET_STATS = "Resetuj statystyki"
    override val CONFIRM = "Na pewno?"
    override val RESET = "Resetuj"
    override val RESET_DONE = "Zresetowano"
    override val LOG = "Dziennik diagnostyczny"
    override val HELP = "Jak to działa?"
    override val VPN_SETTINGS = "Systemowe ustawienia VPN"
    override val SHARE_APP = "Udostępnij aplikację"
    override val RATE_APP = "Oceń aplikację"
    override val FEEDBACK = "Wyślij opinię"
    override fun shareAppText(url: String) = "$APP łączy z popularnymi serwerami DNS jednym dotknięciem: $url"
    override val VERSION = "Wersja"
    override val OPT_BUBBLES = listOf("Wył.", "Mało", "Dużo")
    override val OPT_MOTION = listOf("Pełne", "Mniej", "Wył.")
    override val OPT_CACHE = listOf("Wył.", "Mała", "Normalna", "Duża")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Wył.")
    override val PLAIN_DNS = "Zwykły DNS"

    override val LOG_NOTE = "Zapisywane są tylko zdarzenia połączenia. Nazwy zapytań i dane osobowe nigdy nie są przechowywane."
    override val LOG_EMPTY = "Brak wpisów."
    override val SHARE = "Udostępnij"
    override val CLEAR = "Wyczyść"
    override val CLEARED = "Wyczyszczono"
    override val HELP_SECTIONS = listOf(
        "Czym jest DNS?" to
            "DNS to usługa, która zamienia adresy internetowe (np. example.com) na liczby zrozumiałe dla urządzeń. " +
            "Używany DNS wpływa na szybkość, prywatność i to, jakie treści są blokowane.",
        "Co robi aplikacja?" to
            "Sprawia, że wybrany serwer DNS jest używany we wszystkich aplikacjach. W tym celu otwiera na telefonie lokalny interfejs VPN, " +
            "ale Twój ruch nie trafia na żaden serwer VPN. Do wybranego serwera wysyłane są tylko zapytania DNS; " +
            "cała reszta płynie zwykłą drogą.",
        "Szyfrowany DNS (DoT / DoH)" to
            "Na serwerach, które to obsługują, zapytania są szyfrowane: nikt w sieci (właściciel Wi-Fi, operator) nie zobaczy, " +
            "jakie strony odwiedzasz, ani nie podmieni odpowiedzi. W trybie Auto najpierw próbowany jest DoT, potem DoH; jeśli żaden nie działa, " +
            "używany jest zwykły DNS. Dostaniesz wtedy ostrzeżenie, a aplikacja spróbuje wrócić do szyfrowania przy każdej " +
            "zmianie sieci i co 10 minut. Gdy włączone jest „Ścisłe szyfrowanie”, zwykły DNS nigdy nie jest używany. " +
            "Ekran główny pokazuje, która metoda jest w użyciu.",
        "Test połączenia" to
            "Ustawienia > Prywatność i ochrona > Przetestuj połączenie wysyła prawdziwe zapytania DNS przez tunel. Pokazuje, " +
            "czy DNS rzeczywiście odpowiada z wybranego serwera, jak szybko, czy serwer weryfikuje podpisy DNSSEC " +
            "i czy blokuje znaną domenę reklamową.",
        "Prywatność" to
            "Bez konta, bez zbierania danych, bez reklam. Aplikacja nie zapisuje nazw zapytań i sama niczego nigdzie nie wysyła. " +
            "Twoje zapytania trafiają tylko do wybranego dostawcy DNS, zgodnie z jego polityką prywatności. " +
            "Dziennik diagnostyczny zawiera wyłącznie zdarzenia połączenia.",
        "Bateria i zasoby" to
            "W tle zużywa bardzo mało zasobów. Przy wyłączonym ekranie nic nie działa w pętli; " +
            "aplikacja pracuje tylko wtedy, gdy przychodzi zapytanie DNS. Nieużywane połączenia szyfrowane zamykają się same.",
        "Warto wiedzieć" to
            "Android pozwala na tylko jeden VPN naraz; ta aplikacja nie połączy się, gdy aktywna jest inna aplikacja VPN. " +
            "Ustawienie „bezpieczny DNS” w przeglądarce i „Prywatny DNS” Androida z konkretną nazwą hosta używają własnego serwera " +
            "i mogą omijać to przekierowanie; wystarczy zostawić je na „Automatyczny” lub „Wyłączony”. " +
            "Przytrzymaj kulę, aby szybko przełączyć się na ulubione serwery lub na chwilę wstrzymać połączenie.",
    )

    override val NOTIF_CHANNEL = "Stan połączenia"
    override val NOTIF_CHANNEL_NOTE = "Widoczne, gdy połączenie DNS jest aktywne"
    override val NOTIF_ALERT_CHANNEL = "Alerty połączenia"
    override val NOTIF_CONNECTING = "Łączenie…"
    override val NOTIF_STOP = "Rozłącz"
    override val NOTIF_NEXT = "Następny"
    override val NOTIF_DROP_TITLE = "Utracono połączenie DNS"
    override val NOTIF_RECONNECT = "Połącz ponownie"
    override fun notifOn(name: String, proto: String) = "Połączono z $name · $proto"
    override fun notifPaused(time: String) = "Wstrzymano · wznowienie o $time"
    override val TILE_ON = "Połączono"
    override val TILE_OFF = "Wył."
    override val WIDGET_TAP = "Dotknij: połącz / rozłącz"
    override val ERR_PERMISSION = "Nie przyznano uprawnienia VPN"
    override val ERR_ESTABLISH = "Nie udało się otworzyć interfejsu VPN. Może działać inny VPN."
    override fun errNoReply(name: String) = "$name nie odpowiada"
    override fun errNoProto(name: String, proto: String) = "$name nie obsługuje $proto"
    override val ERR_SOCKET = "Brak dostępu do sieci"
    override fun errPrivateDns(host: String) = "Prywatny DNS Androida jest ustawiony na $host i omija tę aplikację. Ustaw Ustawienia > Sieć > Prywatny DNS na Automatyczny lub Wyłączony."
    override val ERR_REVOKED = "System zamknął połączenie"
    override val ERR_TUNNEL = "Tunel został nieoczekiwanie zamknięty"
    override val ERR_UNKNOWN = "Wystąpił nieoczekiwany błąd"

    override val CONSENT_TITLE = "Zanim się połączysz"
    override val CONSENT_BODY = listOf(
        "$APP używa interfejsu VPN Androida, aby kierować Twoje zapytania DNS (nazwy odwiedzanych stron) do wybranego serwera DNS.",
        "Twój ruch nie jest wysyłany na serwer VPN; do wybranego dostawcy trafiają tylko zapytania DNS. Na serwerach, które to obsługują, " +
            "zapytania są szyfrowane (DoT/DoH); na pozostałych są wysyłane bez szyfrowania. Obowiązuje polityka prywatności dostawcy.",
        "Aplikacja nie zbiera danych osobowych, nie zapisuje nazw zapytań i niczego nikomu nie udostępnia.",
        "Jeśli przejdziesz dalej, Android wyświetli prośbę o połączenie VPN; musisz dotknąć „OK”.",
    )
    override val CONSENT_OK = "Rozumiem, dalej"
    override val CLOSE = "Zamknij"
    override val BACK = "Wstecz"

    override val RESUMING = "Wznawianie…"
    override val DOWNGRADED = "Brak szyfrowania, używany zwykły DNS"
    override val UPGRADED = "Znów szyfrowany DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS nie jest szyfrowany"
    override fun notifDowngrade(name: String) = "Nie udało się nawiązać szyfrowanego połączenia z $name. Używany jest zwykły DNS; aplikacja spróbuje wrócić do szyfrowania."
    override fun backupUsed(failed: String, used: String) = "$failed nie odpowiada, połączono z $used"
    override val NOTIF_RETRYING = "Utracono połączenie, ponawianie…"
    override fun errNoEncrypted(name: String) = "Nie udało się nawiązać szyfrowanego połączenia z $name"
    override val APPLYING = "Stosowanie nowego ustawienia do połączenia"
    override val CONFIRM_DISCONNECT = "Rozłączyć?"
    override val DISCONNECT = "Rozłącz"

    override val SEC_NOTIF = "Powiadomienia"
    override val STRICT_ENC = "Ścisłe szyfrowanie"
    override val STRICT_ENC_NOTE = "Nigdy nie przechodź na zwykły DNS"
    override val AUTO_RECONNECT = "Łącz ponownie automatycznie"
    override val AUTO_RECONNECT_NOTE = "Po zerwaniu połączenia ponawia po 5 s, 30 s i 2 min"
    override val BACKUP_SERVER = "Serwer zapasowy"
    override val BACKUP_OFF = "Wyłączony"
    override val BACKUP_OFF_NOTE = "Nie łącz, jeśli wybrany serwer nie odpowiada"
    override val BACKUP_FASTEST = "Najszybszy"
    override val BACKUP_FASTEST_NOTE = "Najszybszy inny serwer z ostatniego pomiaru"
    override val CONFIRM_OFF = "Pytaj przed rozłączeniem"
    override val CONFIRM_OFF_NOTE = "Przypadkowe dotknięcie kuli nie rozłączy"
    override val LOCK_HIDE = "Ukryj na ekranie blokady"
    override val LOCK_HIDE_NOTE = "Nazwa serwera nie pojawia się w powiadomieniu na ekranie blokady"
    override val QUIET_NOTIF = "Ciche powiadomienie"
    override val QUIET_NOTIF_NOTE = "Bez ikony na pasku stanu, bez dźwięku"
    override val REMEMBER_FILTER = "Zapamiętaj ostatni filtr"
    override val REMEMBER_FILTER_NOTE = "Po otwarciu aplikacji wraca ostatnio wybrany filtr"
    override val AUTO_MEASURE = "Mierz po uruchomieniu"
    override val AUTO_MEASURE_NOTE = "Mierzy automatycznie, jeśli ostatni pomiar ma ponad dobę"
    override val MEASURE_ENC = "Pomiar szyfrowany"
    override val MEASURE_ENC_NOTE = "Mierzy szybkość przez DoT, bliżej realnego użycia"
    override val OPT_SORT = listOf("Domyślnie", "Szybkość", "Nazwa")
    override fun sortA11y(mode: String) = "Sortowanie: $mode"
    override val AUTO_LIGHT = "Automatyczny: jasny motyw"
    override val AUTO_DARK = "Automatyczny: ciemny motyw"
    override val NIGHT_HOURS = "Godziny nocne"
    override val FILTER_ENCRYPTED = "Szyfrowane"
    override val FILTER_UNFILTERED = "Bez filtra"

    override val TEST = "Przetestuj połączenie"
    override val TEST_NOTE = "DNS, DNSSEC i blokowanie reklam"
    override val TESTING = "Testowanie…"
    override val TEST_TITLE = "Test połączenia"
    override val TEST_OK = "DNS działa"
    override val TEST_FAIL = "Brak odpowiedzi"
    override val TEST_SERVER = "Serwer"
    override val TEST_METHOD = "Metoda"
    override val TEST_LATENCY = "Czas odpowiedzi"
    override val TEST_DNSSEC = "Weryfikacja DNSSEC"
    override val TEST_ADS = "Blokowanie reklam"
    override val DNSSEC_YES = "Weryfikuje"
    override val DNSSEC_NO = "Nie weryfikuje"
    override val ADS_YES = "Włączone"
    override val ADS_NO = "Wyłączone"
    override val UNKNOWN = "Nieznane"
    override val TEST_EXPLAIN = "Zapytania wysłano przez tunel, tak jak zrobiłaby to aplikacja; odpowiedzi przyszły z wybranego serwera."
    override val TEST_AGAIN = "Testuj ponownie"

    override val RECOMMEND = "Dobierz mi serwer"
    override val RECOMMEND_NOTE = "Wybierz cel, a połączymy z najszybszym pasującym"
    override val GOAL_SPEED = "Szybkość"
    override val GOAL_SPEED_NOTE = "Najszybszy serwer według Twoich pomiarów"
    override val GOAL_PRIVACY_NOTE = "Bez logów, nastawiony na prywatność"
    override val GOAL_ADS_NOTE = "Blokuje reklamy i trackery"
    override val GOAL_FAMILY_NOTE = "Blokuje treści dla dorosłych"
    override val GOAL_SECURITY_NOTE = "Blokuje szkodliwe strony i phishing"
    override fun recommended(name: String) = "Polecany: $name"

    override val PRIVATE_DNS = "Nazwa prywatnego DNS"
    override val PRIVATE_DNS_NOTE = "Możesz wkleić ją w ustawieniu Prywatny DNS Androida. System użyje wtedy tego serwera bezpośrednio, z pominięciem aplikacji."
    override val CLEAR_HISTORY = "Wyczyść historię pomiarów"
    override val HISTORY_CLEARED = "Wyczyszczono pomiary"

    override val GUARD = "Stała ochrona"
    override val GUARD_NOTE = "Zawsze włączony VPN"
    override val GUARD_BODY = listOf(
        "Gdy aplikacja nie jest połączona (wyłączona, wstrzymana lub po zerwaniu), Twoje zapytania DNS trafiają do serwera dostawcy internetu.",
        "Aby temu zapobiec, włącz dla tej aplikacji „Zawsze włączony VPN” w ustawieniach VPN Androida. Jeśli włączone jest też „Blokuj połączenia bez VPN”, internet nie działa wcale, gdy aplikacja nie jest połączona: nic nie wycieka, ale wstrzymanie oznacza też brak internetu.",
        "Przy zawsze włączonym VPN system sam uruchamia aplikację po włączeniu telefonu i po jej zatrzymaniu.",
    )
    override val GUARD_BUTTON = "Otwórz systemowe ustawienia VPN"
    override val BATTERY = "Ustawienia baterii"
    override val BATTERY_OK = "Bez ograniczeń"
    override val BATTERY_LIMITED = "Może być ograniczana"
    override val BATTERY_BODY = listOf(
        "Android zwykle chroni aplikacje VPN. Mimo to niektórzy producenci (Xiaomi, Huawei, Oppo, Vivo, niektóre wersje Samsunga) mogą zamykać aplikacje w tle, aby oszczędzać baterię.",
        "Jeśli połączenie samo się zrywa, ustaw zużycie baterii tej aplikacji na „Bez ograniczeń” lub „Nie optymalizuj”; na niektórych telefonach zezwól też na „Autostart”.",
    )
    override val BATTERY_BUTTON = "Otwórz ustawienia baterii"

    override val STAT_AVG = "Średni czas odpowiedzi"
    override val STAT_SAVED = "Czas zaoszczędzony (cache)"
    override val STAT_TRAFFIC = "Ruch DNS"
    override val SESSIONS = "Historia połączeń"
    override val SESSIONS_NOTE = "Ostatnie 30 połączeń; nazwy zapytań nie są zapisywane"
    override val SESSIONS_EMPTY = "Brak zapisanych połączeń."
    override val MOST_USED = "Najczęściej używane"
    override val TODAY = "Dziś"
    override val YESTERDAY = "Wczoraj"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Rozłączono ręcznie"
        EndReason.PAUSE -> "Wstrzymano"
        EndReason.SWITCH -> "Zmiana serwera"
        EndReason.DROP -> "Zerwane"
        EndReason.REVOKED -> "Zamknięte przez system"
        EndReason.FAILED -> "Brak odpowiedzi"
        EndReason.NETWORK -> "Zmiana sieci"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · zapytania: $queries"

    override val WHATS_NEW = "Co nowego?"
    override val WHATS_NEW_TOAST = "Aplikacja została zaktualizowana"
    override val SHOW = "Pokaż"
    override val WHATS_NEW_ITEMS = listOf(
        "Bezpieczniejsze połączenie: dodatkowa ochrona przed fałszywymi odpowiedziami DNS, ostrzeżenie przy przejściu na zwykły DNS, opcja ścisłego szyfrowania i automatyczny powrót do szyfrowania.",
        "Test połączenia: jednym dotknięciem sprawdzisz, czy DNS odpowiada z wybranego serwera, a także weryfikację DNSSEC i blokowanie reklam.",
        "Serwer zapasowy i automatyczne ponowne łączenie: aplikacja sama sobie radzi, gdy wybrany serwer nie odpowiada lub połączenie się zrywa.",
        "Historia połączeń, najczęściej używane serwery, średni czas odpowiedzi i ruch DNS.",
        "Nowe filtry (Szyfrowane, Bez filtra), sortowanie według nazwy, „Dobierz mi serwer” i pomiar po uruchomieniu.",
        "Liczniki na żywo w powiadomieniu, przycisk pauzy na 15 minut, ukrywanie na ekranie blokady i opcja cichego powiadomienia.",
        "Trzy nowe motywy (Sakura, Miód, Zorza), motyw z tapety oraz wybór jasnego/ciemnego wariantu motywu automatycznego.",
        "Cztery nowe języki: indonezyjski, wietnamski, polski i ukraiński.",
    )
    override fun importedWith(changes: String) = "Wczytano ustawienia · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "osłabiono szyfrowanie"
        SensitiveChange.AUTO_START -> "włączono automatyczne łączenie"
        SensitiveChange.RULES -> "zmieniono reguły serwerów"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · zapytania: $queries · zablokowane: $blocked"
    override val NOTIF_LOCKED = "Ochrona DNS włączona"
    override val NOTIF_QUIET_CHANNEL = "Stan połączenia (cichy)"
    override fun widgetToday(queries: String) = "Zapytania dziś: $queries"
    override fun pauseAction(minutes: Int) = "Wstrzymaj ${minutes(minutes)}"

    override val NOTES = mapOf(
        "cloudflare" to "Szybki, dba o prywatność",
        "google" to "Stabilny, popularny",
        "quad9" to "Blokuje szkodliwe domeny",
        "adguard" to "Blokuje reklamy i trackery",
        "controld" to "Bez filtrów, szybki",
        "opendns" to "Cisco, ochrona przed phishingiem",
        "mullvad" to "Bez logów, tylko szyfrowany",
        "dnssb" to "Dba o prywatność, szybki",
        "dns4eu" to "DNS UE, ochrona przed malware",
        "uncensored" to "Bez filtrów i przekierowań",
        "quad9-open" to "Nic nie blokuje",
        "adguard-open" to "Bez blokad, dba o prywatność",
        "dns4eu-open" to "DNS UE, bez filtrów",
        "controld-ads" to "Reklamy, trackery, malware",
        "mullvad-ads" to "Reklamy i trackery, tylko szyfrowany",
        "dns4eu-ads" to "DNS UE, reklamy i malware",
        "cloudflare-security" to "Blokuje szkodliwe strony",
        "controld-malware" to "Blokuje szkodliwe strony",
        "cleanbrowsing-security" to "Phishing i szkodliwe strony",
        "cloudflare-family" to "Filtr malware i treści 18+",
        "opendns-family" to "Filtr treści dla dorosłych",
        "adguard-family" to "Filtr reklam i treści 18+",
        "cleanbrowsing-family" to "Treści 18+, bezpieczne wyszukiwanie",
        "dns4eu-child" to "DNS UE, ochrona dzieci",
        "mullvad-family" to "Filtr rodzinny, tylko szyfrowany",
        "controld-family" to "Filtr treści dla dorosłych",
    )
}
