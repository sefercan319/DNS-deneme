package app.dnshizli.ui

import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Format
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Rgb
import app.dnshizli.core.TextFit

/**
 * Alttan açılan cam panel (modal). İçerik [body] bir sütundur; panel içeriğe göre büyür, ekrana sığmazsa kayar.
 * Boş yere (panelin dışına) dokunmak veya geri tuşu kapatır.
 */
class Sheet(private val body: Column, private val onDismiss: () -> Unit) : Node() {
    val open = Anim(0f)
    var closing = false
        private set
    private val scroll = ScrollView()
    private var px = 0f
    private var pw = 0f
    private var ptop = 0f
    private var pbottom = 0f

    override val tappable: Boolean get() = true

    init {
        scroll.setContent(body)
        add(scroll)
    }

    fun layoutSheet(env: Env) {
        x = 0f; y = 0f
        w = env.width; h = env.height
        val cw = minOf(w, M.MAX_W)
        pw = cw - 24f
        px = (w - pw) / 2f
        body.layout(env, pw)
        val maxH = env.height - env.insetTop - env.insetBottom - 64f
        val vh = minOf(body.h, maxH)
        scroll.setViewport(env, pw, vh)
        pbottom = env.height - env.insetBottom - 12f
        ptop = pbottom - vh - 22f
        scroll.x = px
        scroll.y = ptop + 22f
    }

    fun show(env: Env) { closing = false; open.set(0f); open.go(1f, env.dur(0.34f)) }

    fun close(env: Env) {
        if (closing) return
        closing = true
        open.go(0f, env.dur(0.24f), Ease.IN_OUT)
        if (env.motion <= 0f) open.set(0f)
    }

    val finished: Boolean get() = closing && !open.active && open.value <= 0.001f

    override fun contains(lx: Float, ly: Float): Boolean = !(lx >= px && lx <= px + pw && ly >= ptop && ly <= pbottom)

    override fun hit(lx: Float, ly: Float): Node? {
        if (open.active || closing) return this
        return super.hit(lx, ly)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { if (tap && !closing) onDismiss() }

    override fun tick(dt: Float, env: Env): Boolean {
        val a = open.step(dt)
        val b = tickKids(dt, env)
        return a || b
    }

    override fun draw(g: Gfx, env: Env) {
        val o = open.value
        if (o <= 0.001f) return
        g.paint(Rgb.alpha(env.theme.shadow, 0.42f * o)); g.rect(0f, 0f, w, h)
        g.save()
        g.translate(0f, (1f - o) * (h - ptop + 24f))
        env.art.card(g, px, ptop, px + pw, pbottom, 28f, strong = 1f, shadow = 1f)
        env.art.grabber(g, px + pw / 2f, ptop + 8f)
        drawKids(g, env)
        g.restore()
    }

    override fun a11y(): A11y? = null
}

/** Alt panel başlığı: solda başlık, sağda kapat düğmesi. */
class SheetTitle(private val text: String, onClose: () -> Unit) : Node() {
    private val label = Label(text, 22f, bold = true, maxLines = 2)
    private val close = IconButton(Icon.CLOSE, Strings.CLOSE, 40f, onClose)
    init { add(close) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        close.layout(env, maxW)
        label.layout(env, w - close.w - 12f)
        h = maxOf(44f, label.h)
        close.x = w - close.w; close.y = (h - close.h) / 2f
        label.x = 0f; label.y = (h - label.h) / 2f
    }
    override fun draw(g: Gfx, env: Env) {
        g.save(); g.translate(label.x, label.y); label.draw(g, env); g.restore()
        drawKids(g, env)
    }
    override fun a11y(): A11y = A11y(text, Role.HEADING)
}

/** Küçük, dokunulmayan etiket hapı (ör. "Gizlilik"). */
class TagPill(private val text: String) : Node() {
    override fun layout(env: Env, maxW: Float) { w = env.metrics.textWidth(text, env.sz(12f), true) + 22f; h = 26f }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, h / 2f, shadow = 0f)
        val fs = env.sz(12f)
        g.paint(env.theme.text)
        g.text(text, w / 2f, centerBaseline(h / 2f, fs), fs, true, app.dnshizli.core.ALIGN_CENTER)
    }
}

/** "Birincil  1.1.1.1  [kopyala]" satırı. */
class AddressRow(private val label: String, private val ip: String, private val model: AppModel) : Node() {
    private val copy = IconButton(Icon.COPY, Strings.COPY + " " + ip, 40f) { model.copy(ip) }
    init { add(copy) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW; h = 60f
        copy.layout(env, maxW)
        copy.x = w - copy.w - 10f; copy.y = (h - copy.h) / 2f
    }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, 18f, shadow = 0.4f)
        g.paint(env.theme.textSoft)
        g.text(label, 16f, h / 2f - 6f, env.sz(12.5f), false, ALIGN_LEFT)
        g.paint(env.theme.text)
        g.text(ip, 16f, h / 2f + 15f, env.sz(17f), true, ALIGN_LEFT)
        drawKids(g, env)
    }
    override fun a11y(): A11y = A11y("$label adres: $ip", Role.TEXT)
}

/** Sunucu ayrıntıları: etiketler, adresler, son ölçüm ve eylemler. Model değişince kendini günceller. */
class DetailsContent(
    private val server: DnsServer,
    private val model: AppModel,
    private val close: () -> Unit,
) : Column(gap = 12f, padL = 20f, padT = 4f, padR = 20f, padB = 22f) {
    private val note = Label(server.note, 15f, ink = Ink.SOFT, maxLines = 0)
    private val lat = Label("", 14f, ink = Ink.SOFT)
    private val connectBtn = ActionButton("", true) { model.tapServer(server.id); close() }
    private val favBtn = ActionButton("", false) { model.toggleFavorite(server.id) }
    private val measureBtn = ActionButton(Strings.MEASURE_THIS, false) { model.measure(listOf(server.id)) }
    private var seen = -1

    init {
        add(SheetTitle(server.name, close))
        add(note)
        val tags = Row(gap = 8f)
        for (t in server.tags) tags.add(TagPill(t.label))
        add(tags)
        add(AddressRow(Strings.PRIMARY, server.primary, model))
        server.secondary?.let { add(AddressRow(Strings.SECONDARY, it, model)) }
        add(lat)
        add(connectBtn)
        add(ButtonsRow(listOf(favBtn, measureBtn)))
        refresh(true)
    }

    private fun refresh(force: Boolean) {
        if (!force && seen == model.version) return
        seen = model.version
        val connectedHere = model.vpn.active && model.vpn.serverId == server.id
        connectBtn.text = when {
            connectedHere -> Strings.CONNECTED_NOW
            model.vpn.active -> Strings.SWITCH_TO_THIS
            else -> Strings.CONNECT_TO_THIS
        }
        connectBtn.enabled = !connectedHere
        favBtn.text = if (server.id in model.settings.favorites) Strings.REMOVE_FAV else Strings.ADD_FAV
        measureBtn.enabled = !model.measuring
        val l = model.latencies[server.id]
        lat.text = if (l == null) Strings.NEVER_MEASURED else Strings.lastMeasure(l.ms, Format.ago(model.host.now() - l.at))
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(false)
        return super.tick(dt, env)
    }
}

/** Seçenek satırı (radyo işaretli). */
class ChoiceRow(
    private val id: String?,
    private val name: String,
    private val note: String,
    private val selected: Boolean,
    private val onPick: (String?) -> Unit,
) : PressNode() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = 60f }

    override fun draw(g: Gfx, env: Env) {
        if (press.value > 0.01f) {
            g.save(); g.alpha(press.value); g.paint(Rgb.alpha(env.theme.accent, 0.16f)); g.roundRect(0f, 2f, w, h - 2f, 16f); g.restore()
        }
        val cy = h / 2f
        g.strokeWidth(2f)
        g.paint(if (selected) env.theme.link else env.theme.textSoft)
        g.strokeCircle(22f, cy, 10f)
        if (selected) { g.paint(env.theme.link); g.circle(22f, cy, 5.2f) }
        val avail = w - 52f - 12f
        g.paint(env.theme.text)
        g.text(TextFit.ellipsize(env.metrics, name, avail, env.sz(16f), true), 52f, cy - 3f, env.sz(16f), true, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        g.text(TextFit.ellipsize(env.metrics, note, avail, env.sz(13f), false), 52f, cy + 15f, env.sz(13f), false, ALIGN_LEFT)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onPick(id) }
    }

    override fun a11y(): A11y = A11y("$name, $note", Role.BUTTON, checked = selected)
}

/** "Otomatik" + tüm sunucular: Wi-Fi/mobil kuralı seçici. */
class ChoiceContent(
    title: String,
    current: String?,
    private val onPick: (String?) -> Unit,
    close: () -> Unit,
) : Column(gap = 2f, padL = 20f, padT = 4f, padR = 20f, padB = 18f) {
    init {
        add(SheetTitle(title, close))
        add(Spacer(6f))
        add(ChoiceRow(null, Strings.RULE_AUTO, Strings.RULE_AUTO_NOTE, current == null) { onPick(null); close() })
        for (s in Catalog.all) add(ChoiceRow(s.id, s.name, s.note, current == s.id) { onPick(s.id); close() })
    }
}

/** İlk açılış bilgilendirmesi: Google Play VPN politikası için açık, sade metin. */
class ConsentContent(private val model: AppModel, close: () -> Unit) : Column(gap = 12f, padL = 20f, padT = 4f, padR = 20f, padB = 22f) {
    init {
        add(SheetTitle(Strings.CONSENT_TITLE, close))
        for (p in Strings.CONSENT_BODY) add(Label(p, 15f, ink = Ink.TEXT, maxLines = 0))
        add(Spacer(4f))
        add(ActionButton(Strings.CONSENT_OK, true, Icon.CHECK) { model.acceptConsent() })
    }
}
