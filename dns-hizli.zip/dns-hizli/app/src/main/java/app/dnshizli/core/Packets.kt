package app.dnshizli.core

/**
 * IPv4 + UDP paketleri için küçük, bellek ayırmayan (allocation-free) yardımcılar.
 * Android'e bağlı değil, bu yüzden normal JVM'de test edilebilir.
 */
internal object Packets {
    const val IP_HDR = 20
    const val UDP_HDR = 8
    const val HDR = IP_HDR + UDP_HDR
    const val DNS_HDR = 12
    const val DNS_PORT = 53

    fun u16(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    fun put16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }

    fun i32(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or
            ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or
            (b[o + 3].toInt() and 0xFF)

    fun put32(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    /** Standart IPv4 başlık sağlama toplamı. Başlıktaki checksum alanı dahilse geçerli paket için 0 döner. */
    fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i + 1 < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum ushr 16) != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv() and 0xFFFF
    }

    /**
     * Paket "IPv4 + UDP + hedef port 53 + parçalı değil" ise IP başlık uzunluğunu döner,
     * aksi halde -1 (paket yok sayılır).
     */
    fun queryHeaderLen(p: ByteArray, len: Int): Int {
        if (len < HDR + DNS_HDR) return -1
        if (((p[0].toInt() and 0xF0) shr 4) != 4) return -1
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < IP_HDR || len < ihl + UDP_HDR + DNS_HDR) return -1
        if ((p[9].toInt() and 0xFF) != 17) return -1          // UDP değil
        if ((u16(p, 6) and 0x3FFF) != 0) return -1            // parçalı paket
        if (u16(p, 2) > len) return -1                        // kesik paket
        if (u16(p, ihl + 2) != DNS_PORT) return -1            // DNS değil
        return ihl
    }

    /** UDP verisinin (DNS mesajı) uzunluğu. Negatif çıkarsa paket bozuktur. */
    fun dnsLength(p: ByteArray, ihl: Int): Int {
        val total = u16(p, 2)
        val udp = u16(p, ihl + 4) - UDP_HDR
        return minOf(udp, total - ihl - UDP_HDR)
    }

    fun ip(a: Int, b: Int, c: Int, d: Int): Int = (a shl 24) or (b shl 16) or (c shl 8) or d

    /**
     * [out] içinde HDR (28) bayttan sonra DNS verisi hazırsa, öndeki IPv4 + UDP başlıklarını doldurur.
     * UDP checksum IPv4'te 0 (kullanılmıyor) olabilir.
     */
    fun writeHeaders(out: ByteArray, srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, dnsLen: Int) {
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, HDR + dnsLen)
        put16(out, 4, 0)
        put16(out, 6, 0x4000)          // DF
        out[8] = 64                    // TTL
        out[9] = 17                    // UDP
        put16(out, 10, 0)
        put32(out, 12, srcIp)
        put32(out, 16, dstIp)
        put16(out, 10, checksum(out, 0, IP_HDR))
        put16(out, 20, srcPort)
        put16(out, 22, dstPort)
        put16(out, 24, UDP_HDR + dnsLen)
        put16(out, 26, 0)
    }
}

internal object Dns {

    /**
     * DNS cevabı önbelleğe alınabilir mi? Alınabilirse cevap bölümündeki en kısa TTL'i (saniye),
     * alınamazsa 0 döner. Hatalı, kesilmiş (TC) veya cevapsız mesajlar önbelleğe girmez.
     */
    fun cacheTtl(b: ByteArray, len: Int): Int {
        if (len < Packets.DNS_HDR) return 0
        val flags = Packets.u16(b, 2)
        if ((flags and 0x8000) == 0) return 0      // cevap değil
        if ((flags and 0x0200) != 0) return 0      // TC: kesilmiş
        if ((flags and 0x000F) != 0) return 0      // NOERROR değil
        val qd = Packets.u16(b, 4)
        val an = Packets.u16(b, 6)
        if (an == 0) return 0

        var p = Packets.DNS_HDR
        repeat(qd) {
            p = skipName(b, p, len)
            if (p < 0 || p + 4 > len) return 0
            p += 4
        }
        var lowest = Int.MAX_VALUE
        repeat(an) {
            p = skipName(b, p, len)
            if (p < 0 || p + 10 > len) return 0
            val ttl = Packets.i32(b, p + 4)
            val rdLen = Packets.u16(b, p + 8)
            p += 10
            if (p + rdLen > len) return 0
            p += rdLen
            lowest = minOf(lowest, if (ttl < 0) 0 else ttl)
        }
        return if (lowest == Int.MAX_VALUE) 0 else lowest
    }

    /** Alan adını atlar (sıkıştırma işaretçisi dahil). Bozuksa -1. */
    private fun skipName(b: ByteArray, start: Int, end: Int): Int {
        var i = start
        while (true) {
            if (i >= end) return -1
            val l = b[i].toInt() and 0xFF
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return if (i + 2 <= end) i + 2 else -1
            if ((l and 0xC0) != 0) return -1
            i += 1 + l
        }
    }

    /** "name" için A kaydı sorgusu üretir (RD biti açık). */
    fun buildQuery(id: Int, name: String): ByteArray {
        val labels = name.split('.')
        var size = Packets.DNS_HDR + 1 + 4
        for (l in labels) size += 1 + l.length
        val b = ByteArray(size)
        Packets.put16(b, 0, id)
        Packets.put16(b, 2, 0x0100)
        Packets.put16(b, 4, 1)
        var p = Packets.DNS_HDR
        for (l in labels) {
            b[p++] = l.length.toByte()
            for (ch in l) b[p++] = ch.code.toByte()
        }
        b[p++] = 0
        Packets.put16(b, p, 1)       // A
        Packets.put16(b, p + 2, 1)   // IN
        return b
    }
}
