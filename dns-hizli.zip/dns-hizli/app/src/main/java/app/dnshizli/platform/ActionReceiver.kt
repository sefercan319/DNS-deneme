package app.dnshizli.platform

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.SystemClock
import app.dnshizli.core.Journal

/**
 * Bildirim düğmeleri ve duraklatma alarmı için dışa kapalı alıcı: yalnızca uygulamanın kendi PendingIntent'leri
 * tetikleyebilir (başka uygulamalar VPN'i açıp kapatamaz).
 *
 * Neden doğrudan servis başlatılmıyor: VPN izni bu arada geri alınmışsa (ör. kullanıcı sistem ayarlarından "VPN'i unut"
 * dedi) önplan servisi başlatmak uygulamayı çökertebilir. Burada önce izin denetlenir; izin yoksa kesme isteği yine
 * yerine getirilir (bildirimler temizlenir), diğerleri için kullanıcı uygulamayı açmaya davet edilir.
 */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val action = intent.action ?: return
        val prefs = PrefsStore(ctx)
        App.applyLanguage(ctx, prefs.loadSettings().lang)
        val ready = try { VpnService.prepare(ctx) == null } catch (_: Exception) { false }
        if (action == ACTION_ALARM_RESUME) {
            // Eski ya da ikinci (yedek) alarm: duraklatma çoktan bitmiş ya da iptal edilmişse hiçbir şey yapma.
            if (prefs.pausedUntil() == 0L) return
            if (!ready) { stopNow(ctx, prefs); Notifier.needApp(ctx); return }
            // Başlatılamazsa (arka plan kısıtı) sessizce kalma: duraklatmayı bitir ve kullanıcıyı uygulamayı açmaya çağır.
            if (!start(ctx, DnsVpnService.resumeIntent(ctx, auto = true))) { stopNow(ctx, prefs); Notifier.needApp(ctx) }
            return
        }
        if (action == ACTION_STOP) {
            // Kesme izne bağlı değildir: servis bunu milisaniyeler içinde işler ve kendini kapatır. Başlatılamazsa servis durdurulur.
            if (!start(ctx, DnsVpnService.disconnectIntent(ctx))) stopNow(ctx, prefs)
            return
        }
        if (!ready) { Notifier.needApp(ctx); return }
        val i = when (action) {
            ACTION_NEXT -> DnsVpnService.nextIntent(ctx)
            ACTION_RESUME -> DnsVpnService.resumeIntent(ctx)
            ACTION_PAUSE -> DnsVpnService.pauseIntent(ctx, intent.getIntExtra(EXTRA_MINUTES, Notifier.PAUSE_MIN).coerceIn(1, 24 * 60))
            else -> return
        }
        start(ctx, i)
    }

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startForegroundService(i)
        true
    } catch (e: Exception) {
        Journal.add("bildirim eylemi başlatılamadı: ${e.javaClass.simpleName}")
        false
    }

    /** Servis komut alamıyorsa: duraklatma ve "açıktı" bilgisi silinir, alarmlar iptal edilir, servis durdurulur (önplan bildirimi asılı kalmasın). */
    private fun stopNow(ctx: Context, prefs: PrefsStore) {
        prefs.setPausedUntil(0L)
        prefs.setWasActive(false)
        PauseAlarm.cancel(ctx)
        try { ctx.stopService(Intent(ctx, DnsVpnService::class.java)) } catch (_: Exception) {}
        Notifier.cancel(ctx)
    }

    companion object {
        const val ACTION_STOP = "app.dnshizli.action.STOP"
        const val ACTION_NEXT = "app.dnshizli.action.NEXT"
        const val ACTION_RESUME = "app.dnshizli.action.RESUME"
        const val ACTION_PAUSE = "app.dnshizli.action.PAUSE"
        const val ACTION_ALARM_RESUME = "app.dnshizli.action.ALARM_RESUME"
        const val EXTRA_MINUTES = "minutes"
    }
}

/**
 * Duraklatma bitince servisi yeniden başlatan sistem alarmı (servis ya da süreç bu arada kapanmış olsa bile).
 * Kesin alarm izni (manifestte istenmez) yoksa, ki Android 12 ve üstünde varsayılan budur, cihaz uykudayken de çalışan
 * yaklaşık alarm kullanılır. Servis çalışıyorsa ayrıca kendi içinde izin gerektirmeyen bir zamanlayıcı kurar;
 * hangisi önce çalışırsa devam eder, ikincisi duraklatma bittiği için hiçbir şey yapmaz.
 */
object PauseAlarm {
    private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 9, Intent(ctx, ActionReceiver::class.java).setAction(ActionReceiver.ACTION_ALARM_RESUME),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun schedule(ctx: Context, untilMs: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val at = SystemClock.elapsedRealtime() + maxOf(0L, untilMs - System.currentTimeMillis())
        try {
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pending(ctx))
            else am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pending(ctx))
        } catch (e: Exception) {
            Journal.add("alarm kurulamadı: ${e.javaClass.simpleName}")
        }
    }

    fun cancel(ctx: Context) {
        try { ctx.getSystemService(AlarmManager::class.java)?.cancel(pending(ctx)) } catch (_: Exception) {}
    }
}
