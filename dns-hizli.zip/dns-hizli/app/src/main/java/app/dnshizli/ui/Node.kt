package app.dnshizli.ui

import app.dnshizli.core.AeroArt
import app.dnshizli.core.AeroTheme
import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.Gfx
import app.dnshizli.core.Rgb
import app.dnshizli.core.TextFit
import app.dnshizli.core.TextMetrics
import app.dnshizli.core.Themes

/** Metin renk rolleri: gerçek renk o anki temadan gelir (tema geçişinde renkler akar). */
enum class Ink { TEXT, SOFT, LINK, ON_CONTROL }

/** Ölçüler (dp). Hepsi tek yerde: tasarımı değiştirmek için buraya bakın. */
object M {
    const val PAD = 20f
    const val MAX_W = 480f
    const val HEADER_H = 56f
    const val ORB_R = 92f
    const val CHIP_H = 38f
    const val ROW_H = 68f
    const val ROW_H_COMPACT = 52f
    const val ROW_GAP = 10f
    const val CARD_R = 22f
    const val MIN_TAP = 44f
}

/** Her karede çizim ve yerleşim kodlarının paylaştığı bağlam. */
class Env(val model: AppModel, val metrics: TextMetrics) {
    var theme: AeroTheme = Themes.aqua
    var art: AeroArt = AeroArt(Themes.aqua, 0.55f)

    /** Yazı ölçeği (sistem yazı boyutu, 1..1.3 arasına kırpılır). */
    var fs: Float = 1f

    /** Animasyon süre çarpanı; 0 ise animasyon yoktur. */
    var motion: Float = 1f

    /** Sahne saati (sn). */
    var time: Float = 0f

    /** Süs (sürekli) animasyonlar açık mı: kabarcıklar, küre dalgası. */
    var ambient: Boolean = true

    var width = 0f
    var height = 0f
    var insetTop = 0f
    var insetBottom = 0f

    fun dur(sec: Float): Float = sec * motion
    fun sz(size: Float): Float = size * fs

    /** Dokunuşta hafif titreşim (ayar açıksa). */
    fun tap(strong: Boolean = false) { if (model.settings.haptics) model.host.haptic(strong) }

    fun color(ink: Ink): Int = when (ink) {
        Ink.TEXT -> theme.text
        Ink.SOFT -> theme.textSoft
        Ink.LINK -> theme.link
        Ink.ON_CONTROL -> Rgb.WHITE
    }
}

enum class Role { BUTTON, SWITCH, SLIDER, TEXT, HEADING }

/** Erişilebilirlik (TalkBack) açıklaması. Etiketi olan düğümler görünür. */
class A11y(
    val label: String,
    val role: Role = Role.BUTTON,
    val checked: Boolean? = null,
    val value: String? = null,
    val longClick: Boolean = false,
)

/** Ekran tarafından okunan düğüm: ekran koordinatlarında sınır + açıklama. */
class A11yItem(val node: Node, val info: A11y, val l: Float, val t: Float, val r: Float, val b: Float)

interface Scrollable {
    val canScroll: Boolean
    fun dragBy(d: Float)
    fun flingBy(v: Float)
    fun stopScroll(): Boolean
}

/**
 * Sahne ağacının temel düğümü. Konum ve boyut (dp) üst düğüme göre; çocuklar [scrollY] kadar kayar.
 * Çizim, yerleşim, dokunma ve erişilebilirlik burada tanımlanır; bileşenler yalnızca ilgili yerleri geçersiz kılar.
 */
abstract class Node {
    var x = 0f
    var y = 0f
    var w = 0f
    var h = 0f
    var parent: Node? = null
    var visible = true

    protected val kids = ArrayList<Node>(4)
    val children: List<Node> get() = kids

    open val scrollY: Float get() = 0f

    fun <T : Node> add(n: T): T { n.parent?.kids?.remove(n); n.parent = this; kids.add(n); return n }

    fun removeAll() { for (k in kids) k.parent = null; kids.clear() }

    fun remove(n: Node) { if (kids.remove(n)) n.parent = null }

    // ---- yerleşim / çizim / zaman
    open fun layout(env: Env, maxW: Float) {}

    open fun draw(g: Gfx, env: Env) = drawKids(g, env)

    protected fun drawKids(g: Gfx, env: Env) {
        // Dizinli döngü: Iterator nesnesi ayırmaz (her karede çalışan yol).
        var i = 0
        while (i < kids.size) {
            val k = kids[i++]
            if (!k.visible) continue
            g.save()
            g.translate(k.x, k.y - scrollY)
            k.draw(g, env)
            g.restore()
        }
    }

    /** [dt] saniye ilerlet. Etkileşimli bir animasyon sürüyorsa true (tam hızda kare ister). */
    open fun tick(dt: Float, env: Env): Boolean = tickKids(dt, env)

    protected fun tickKids(dt: Float, env: Env): Boolean {
        var any = false
        var i = 0
        while (i < kids.size) { val k = kids[i++]; if (k.visible && k.tick(dt, env)) any = true }
        return any
    }

    /** Yalnızca süs amaçlı sürekli animasyon var mı (düşük hızda kare yeter). */
    open fun ambient(env: Env): Boolean = ambientKids(env)

    protected fun ambientKids(env: Env): Boolean {
        var i = 0
        while (i < kids.size) { val k = kids[i++]; if (k.visible && k.ambient(env)) return true }
        return false
    }

    // ---- dokunma
    open val tappable: Boolean get() = false
    open val dragCapture: Boolean get() = false

    /** [dragCapture] düğümü sürüklemeyi şu an yönetiyor mu (ör. kaydırıcının topuzu tutuldu mu)? */
    open val dragActive: Boolean get() = false

    /** Yatay sürükleme eşiği aşıldı ve düğüm sürüklemeyi devralıyor (dikey hareket sayfayı kaydırmaya gider). */
    open fun onDragStart(lx: Float, ly: Float, env: Env) {}
    open val longPressable: Boolean get() = false
    open val hitSlop: Float get() = 0f

    /** (lx, ly) bu düğümün yerel koordinatlarında mı? */
    open fun contains(lx: Float, ly: Float): Boolean {
        val s = hitSlop
        return lx >= -s && ly >= -s && lx <= w + s && ly <= h + s
    }

    open fun onDown(lx: Float, ly: Float, env: Env) {}
    open fun onDrag(lx: Float, ly: Float, env: Env) {}

    /** Parmak kalktı. [tap] true ise düğümün içinde kalktı (tıklama). */
    open fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {}
    open fun onCancel(env: Env) {}
    open fun onLongPress(env: Env): Boolean = false

    /** En üstteki dokunulabilir düğümü bulur. (lx, ly) bu düğümün yerel koordinatlarıdır. */
    open fun hit(lx: Float, ly: Float): Node? {
        if (!visible) return null
        for (i in kids.size - 1 downTo 0) {
            val k = kids[i]
            if (!k.visible) continue
            val r = k.hit(lx - k.x, ly + scrollY - k.y)
            if (r != null) return r
        }
        return if ((tappable || dragCapture) && contains(lx, ly)) this else null
    }

    /** (lx, ly) noktasındaki en içteki kaydırılabilir düğüm (varsa). */
    fun hitScrollable(lx: Float, ly: Float): Node? {
        if (!visible) return null
        for (i in kids.size - 1 downTo 0) {
            val k = kids[i]
            if (!k.visible) continue
            val r = k.hitScrollable(lx - k.x, ly + scrollY - k.y)
            if (r != null) return r
        }
        return if (this is Scrollable && lx >= 0f && ly >= 0f && lx <= w && ly <= h) this else null
    }

    /** Bu düğümün [root] içindeki mutlak sol-üst konumu. */
    fun absX(): Float { var v = 0f; var n: Node? = this; while (n != null) { v += n.x; n = n.parent }; return v }
    fun absY(): Float { var v = 0f; var n: Node? = this; while (n != null) { val p = n.parent; v += n.y - (p?.scrollY ?: 0f); n = p }; return v }

    // ---- erişilebilirlik
    open fun a11y(): A11y? = null
    open fun a11yClick(env: Env) { onUp(w / 2, h / 2, true, env) }
    open fun a11yAdjust(dir: Int, env: Env) {}

    /** Ekranda görünen ve etiketi olan tüm düğümleri sırayla toplar. [clip]: görünür alan (ekran koordinatları). */
    fun collectA11y(out: MutableList<A11yItem>, ox: Float, oy: Float, clipT: Float, clipB: Float) {
        if (!visible) return
        val info = a11y()
        if (info != null) {
            val t = oy
            val b = oy + h
            if (b > clipT && t < clipB) out.add(A11yItem(this, info, ox, maxOf(t, clipT), ox + w, minOf(b, clipB)))
        }
        for (k in kids) {
            if (!k.visible) continue
            var ct = clipT
            var cb = clipB
            if (this is ClipsChildren) { ct = maxOf(ct, oy + clipInsetTop); cb = minOf(cb, oy + h) }
            k.collectA11y(out, ox + k.x, oy + k.y - scrollY, ct, cb)
        }
    }
}

/** Çocuklarını kendi sınırlarına kırpan düğümler (kaydırma alanları). [clipInsetTop]: üstte başka bir öğenin (üst çubuk) örttüğü pay. */
interface ClipsChildren {
    val clipInsetTop: Float get() = 0f
}

/** Basınca küçülüp bırakınca geri dönen düğümler için ortak taban. */
abstract class PressNode : Node() {
    val press = Anim(0f)
    protected var down = false

    override val tappable: Boolean get() = true

    override fun onDown(lx: Float, ly: Float, env: Env) { down = true; press.go(1f, env.dur(0.08f)) }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { release(env) }
    override fun onCancel(env: Env) { release(env) }

    private fun release(env: Env) { down = false; press.go(0f, env.dur(0.30f), Ease.OUT) }

    override fun tick(dt: Float, env: Env): Boolean {
        val a = press.step(dt)
        val b = tickKids(dt, env)
        return a || b
    }

    /** Basılıyken hafifçe küçült (cam damlası hissi). */
    protected fun pressScale(g: Gfx, cx: Float, cy: Float, amount: Float = 0.035f) {
        val s = 1f - amount * press.value
        if (s != 1f) { g.translate(cx, cy); g.scale(s, s); g.translate(-cx, -cy) }
    }
}

/** Tek veya çok satırlı metin. Sığmayan satır "…" ile kısalır. [maxLines] 0 ise sınırsız (sözcüklerden kaydırır). */
class Label(
    text: String,
    private val size: Float,
    private val bold: Boolean = false,
    private val ink: Ink = Ink.TEXT,
    private val align: Int = ALIGN_LEFT,
    private val maxLines: Int = 1,
) : Node() {
    var text: String = text
        set(v) { if (v != field) { field = v; laidW = -1f } }
    var alpha = 1f
    var dy = 0f

    private var lines: List<String> = emptyList()
    private var laidW = -1f
    private var laidFs = 0f
    private var lineH = 0f

    private fun relay(env: Env, maxW: Float) {
        val s = env.sz(size)
        laidW = maxW
        laidFs = env.fs
        lineH = s * 1.32f
        lines = if (maxLines == 1) {
            listOf(TextFit.ellipsize(env.metrics, text, maxW, s, bold))
        } else {
            val l = TextFit.wrap(env.metrics, text, maxW, s, bold)
            if (maxLines > 0 && l.size > maxLines) {
                val cut = ArrayList(l.subList(0, maxLines))
                cut[maxLines - 1] = TextFit.ellipsize(env.metrics, cut[maxLines - 1] + " …", maxW, s, bold)
                cut
            } else l
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        relay(env, maxW)
        h = lines.size * lineH
    }

    override fun draw(g: Gfx, env: Env) {
        if (w <= 0f || alpha <= 0.01f) return
        if (laidW != w || laidFs != env.fs) relay(env, w)
        val s = env.sz(size)
        g.save()
        if (alpha < 1f) g.alpha(alpha)
        g.paint(env.color(ink))
        val px = when (align) { ALIGN_CENTER -> w / 2f; ALIGN_RIGHT -> w; else -> 0f }
        for (i in lines.indices) g.text(lines[i], px, dy + s * 1.0f + i * lineH, s, bold, align)
        g.restore()
    }

    override fun a11y(): A11y? = if (text.isEmpty()) null else A11y(text, Role.TEXT)
}

class Spacer(private val height: Float) : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = height }
}

/** Dikey yığın: çocukları üst üste dizer. */
open class Column(
    var gap: Float = 0f,
    var padL: Float = 0f,
    var padT: Float = 0f,
    var padR: Float = 0f,
    var padB: Float = 0f,
) : Node() {
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = padT
        var first = true
        for (k in kids) {
            if (!k.visible) continue
            if (!first) cy += gap
            first = false
            k.layout(env, maxW - padL - padR)
            k.x = padL
            k.y = cy
            cy += k.h
        }
        h = cy + padB
    }
}

/** Dikey kaydırılan alan. Boyutunu sahip belirler ([setViewport]); içerik kendi ölçüsünü hesaplar. */
open class ScrollView : Node(), Scrollable, ClipsChildren {
    private val sc = Scroller()

    /** Üstteki opak çubuğun örttüğü yükseklik: bu bölgedeki içerik erişilebilirlik ağacına girmez. */
    override var clipInsetTop: Float = 0f
    var content: Node? = null
        private set

    override val scrollY: Float get() = sc.pos

    val offset: Float get() = sc.pos

    /** En fazla kaydırma konumu (içerik sığıyorsa 0). */
    val maxOffset: Float get() = sc.max
    override val canScroll: Boolean get() = sc.max > sc.min + 0.5f || sc.pullable

    /** En üstte aşağı çekmeyi aç; bırakıldığında çekme mesafesiyle [onPullRelease] çağrılır. */
    var pullable: Boolean
        get() = sc.pullable
        set(v) { sc.pullable = v }
    var onPullRelease: ((Float) -> Unit)? = null

    /** Şu anki çekme mesafesi (dp); çekilmiyorsa 0. */
    val pull: Float get() = sc.pull

    fun setContent(n: Node) {
        content?.let { remove(it) }
        content = n
        add(n)
    }

    /** Görünür alanın boyutunu ve içerik yerleşimini ayarla. [pad]: kaydırma sonunda ek boşluk. */
    fun setViewport(env: Env, vw: Float, vh: Float, pad: Float = 0f) {
        w = vw
        h = vh
        val c = content ?: return
        c.layout(env, vw)
        c.x = 0f; c.y = 0f
        sc.min = 0f
        sc.max = maxOf(0f, c.h + pad - vh)
        sc.clampNow()
    }

    fun scrollTo(p: Float) = sc.jump(p)

    override fun dragBy(d: Float) = sc.drag(d)
    override fun flingBy(v: Float) {
        val p = sc.pull
        sc.fling(v)
        if (p > 0f) onPullRelease?.invoke(p)
    }
    override fun stopScroll(): Boolean = sc.stop()

    override fun tick(dt: Float, env: Env): Boolean {
        val a = sc.step(dt)
        val b = tickKids(dt, env)
        return a || b
    }

    override fun draw(g: Gfx, env: Env) {
        g.save()
        g.clipRect(0f, 0f, w, h)
        val c = content
        if (c != null) {
            // Görünür olmayan çocukları çizme (uzun listelerde işi azaltır).
            val vt = scrollY
            val vb = scrollY + h
            val ck = c.children
            var i = 0
            while (i < ck.size) {
                val k = ck[i++]
                if (!k.visible) continue
                val ky = k.y + c.y
                if (ky + k.h < vt - 40f || ky > vb + 40f) continue
                g.save()
                g.translate(k.x + c.x, ky - scrollY)
                k.draw(g, env)
                g.restore()
            }
            // İçerik düğümünün kendi çizimi (zemin vb.) gerekmiyor; yalnızca çocukları çizilir.
        }
        g.restore()
    }

    override fun hit(lx: Float, ly: Float): Node? {
        if (!visible || lx < 0f || ly < 0f || lx > w || ly > h) return null
        return super.hit(lx, ly)
    }
}
