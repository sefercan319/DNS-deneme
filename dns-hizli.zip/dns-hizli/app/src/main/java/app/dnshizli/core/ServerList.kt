package app.dnshizli.core

/** Bir sunucunun son gecikme ölçümü. [ms] null ise sunucu cevap vermedi. */
data class Latency(val ms: Int?, val at: Long)

object ServerList {

    /**
     * Listede görünecek sunucular.
     *  - [tag] doluysa yalnızca o etikete sahip olanlar.
     *  - Favoriler her zaman en üstte (kendi içinde katalog sırasıyla).
     *  - [sortBySpeed] açıksa her grup kendi içinde gecikmeye göre sıralanır: ölçülmüşler hızlıdan yavaşa,
     *    sonra ölçülmemişler (katalog sırası), en sonda cevap vermeyenler.
     */
    fun visible(
        all: List<DnsServer>,
        tag: Tag?,
        favorites: Set<String>,
        latencies: Map<String, Latency>,
        sortBySpeed: Boolean,
    ): List<DnsServer> {
        val filtered = if (tag == null) all else all.filter { tag in it.tags }
        val (fav, rest) = filtered.partition { it.id in favorites }
        return order(fav, latencies, sortBySpeed) + order(rest, latencies, sortBySpeed)
    }

    private fun order(list: List<DnsServer>, lat: Map<String, Latency>, bySpeed: Boolean): List<DnsServer> {
        if (!bySpeed) return list
        fun rank(s: DnsServer): Int {
            val l = lat[s.id] ?: return 1                 // ölçülmemiş
            return if (l.ms == null) 2 else 0             // cevapsız / ölçülmüş
        }
        return list.withIndex()
            .sortedWith(compareBy({ rank(it.value) }, { lat[it.value.id]?.ms ?: Int.MAX_VALUE }, { it.index }))
            .map { it.value }
    }

    /** Ölçülmüşler arasında en hızlı sunucu (eşitlikte katalog sırası). Hiç ölçüm yoksa null. */
    fun fastest(all: List<DnsServer>, latencies: Map<String, Latency>): Pair<DnsServer, Int>? {
        var best: Pair<DnsServer, Int>? = null
        for (s in all) {
            val ms = latencies[s.id]?.ms ?: continue
            if (best == null || ms < best.second) best = s to ms
        }
        return best
    }

    /** 1..4 arası sinyal çubuğu sayısı: gecikme ne kadar düşükse o kadar çok çubuk. */
    fun bars(ms: Int?): Int = when {
        ms == null -> 0
        ms <= 25 -> 4
        ms <= 50 -> 3
        ms <= 100 -> 2
        else -> 1
    }
}

/** Gecikme ölçümlerini tek bir metin olarak saklamak için: "id=ms@zaman;..." (ms=-1: cevapsız). */
object LatencyCodec {
    fun encode(m: Map<String, Latency>): String =
        m.entries.joinToString(";") { (id, l) -> "$id=${l.ms ?: -1}@${l.at}" }

    fun decode(s: String?): Map<String, Latency> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<String, Latency>()
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            val at = part.indexOf('@')
            if (eq <= 0 || at <= eq) continue
            val id = part.substring(0, eq)
            if (Catalog.byId(id) == null) continue
            val ms = part.substring(eq + 1, at).toIntOrNull() ?: continue
            val time = part.substring(at + 1).toLongOrNull() ?: continue
            out[id] = Latency(if (ms < 0) null else ms, time)
        }
        return out
    }
}
