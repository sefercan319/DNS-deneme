package app.dnshizli.core

/** Bir sunucunun son gecikme ölçümü. [ms] null ise sunucu cevap vermedi. [loss]: cevapsız deneme yüzdesi. */
data class Latency(val ms: Int?, val at: Long, val loss: Int = 0)

object ServerList {

    /**
     * Listede görünecek sunucular.
     *  - [tag] doluysa yalnızca o etikete sahip olanlar.
     *  - Favoriler her zaman en üstte (kendi içinde katalog sırasıyla).
     *  - [sortBySpeed] açıksa her grup kendi içinde gecikmeye göre sıralanır: ölçülmüşler hızlıdan yavaşa,
     *    sonra ölçülmemişler (katalog sırası), en sonda cevap vermeyenler.
     */
    fun visible(
        all: List<DnsServer>,
        tag: Tag?,
        favorites: Set<String>,
        latencies: Map<String, Latency>,
        sortBySpeed: Boolean,
        hidden: Set<String> = emptySet(),
    ): List<DnsServer> = visible(all, tag, favorites, latencies, if (sortBySpeed) SortMode.SPEED else SortMode.DEFAULT, hidden)

    /**
     * [sort]: katalog sırası, hız ya da ada göre. [extra] doluysa yalnızca ona uyanlar (ör. "şifreli", "filtresiz" süzgeçleri).
     */
    fun visible(
        all: List<DnsServer>,
        tag: Tag?,
        favorites: Set<String>,
        latencies: Map<String, Latency>,
        sort: SortMode,
        hidden: Set<String> = emptySet(),
        extra: ((DnsServer) -> Boolean)? = null,
    ): List<DnsServer> {
        val filtered = all.filter { (tag == null || tag in it.tags) && it.id !in hidden && (extra == null || extra(it)) }
        val (fav, rest) = filtered.partition { it.id in favorites }
        return order(fav, latencies, sort) + order(rest, latencies, sort)
    }

    /** Şifreli DNS (DoT ya da DoH) destekleyen sunucu mu? */
    fun encrypted(s: DnsServer): Boolean = s.encrypted

    /** Hiçbir şey engellemeyen (reklam, aile ya da güvenlik süzgeci olmayan) sunucu mu? */
    fun unfiltered(s: DnsServer): Boolean = Tag.ADS !in s.tags && Tag.FAMILY !in s.tags && Tag.SECURITY !in s.tags

    /**
     * Amaca göre öneri: [goal] etiketli (null ise hepsi) ve kullanılabilir sunucular arasında ölçülmüş en hızlısı;
     * hiç ölçüm yoksa katalogdaki ilk uygun sunucu. Uygun sunucu yoksa null.
     */
    fun recommend(
        all: List<DnsServer>, goal: Tag?, latencies: Map<String, Latency>, usable: (DnsServer) -> Boolean = { true },
    ): DnsServer? {
        val cands = all.filter { (goal == null || goal in it.tags) && usable(it) }
        if (cands.isEmpty()) return null
        return fastest(cands, latencies)?.first ?: cands.first()
    }

    private fun order(list: List<DnsServer>, lat: Map<String, Latency>, sort: SortMode): List<DnsServer> {
        if (sort == SortMode.NAME) return list.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        if (sort != SortMode.SPEED) return list
        fun rank(s: DnsServer): Int {
            val l = lat[s.id] ?: return 1                 // ölçülmemiş
            return if (l.ms == null) 2 else 0             // cevapsız / ölçülmüş
        }
        return list.withIndex()
            .sortedWith(compareBy({ rank(it.value) }, { lat[it.value.id]?.ms ?: Int.MAX_VALUE }, { it.index }))
            .map { it.value }
    }

    /**
     * Ölçülmüşler arasında en hızlı sunucu (eşitlikte katalog sırası). Hiç ölçüm yoksa null.
     * [usable] false dönenler (ör. seçili şifreleme türünü desteklemeyen, gizlenmiş) atlanır.
     */
    fun fastest(
        all: List<DnsServer>, latencies: Map<String, Latency>, usable: (DnsServer) -> Boolean = { true },
    ): Pair<DnsServer, Int>? {
        var best: Pair<DnsServer, Int>? = null
        for (s in all) {
            if (!usable(s)) continue
            val ms = latencies[s.id]?.ms ?: continue
            if (best == null || ms < best.second) best = s to ms
        }
        return best
    }

    /** 1..4 arası sinyal çubuğu sayısı: gecikme ne kadar düşükse o kadar çok çubuk. */
    fun bars(ms: Int?): Int = when {
        ms == null -> 0
        ms <= 25 -> 4
        ms <= 50 -> 3
        ms <= 100 -> 2
        else -> 1
    }
}

/** Gecikme ölçümlerini tek bir metin olarak saklamak için: "id=ms@zaman[~kayıp];..." (ms=-1: cevapsız). */
object LatencyCodec {
    fun encode(m: Map<String, Latency>): String =
        m.entries.joinToString(";") { (id, l) -> "$id=${l.ms ?: -1}@${l.at}" + (if (l.loss > 0) "~${l.loss}" else "") }

    fun decode(s: String?): Map<String, Latency> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<String, Latency>()
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            val at = part.indexOf('@')
            if (eq <= 0 || at <= eq) continue
            val id = part.substring(0, eq)
            if (Catalog.byId(id) == null) continue
            val ms = part.substring(eq + 1, at).toIntOrNull() ?: continue
            val rest = part.substring(at + 1)
            val time = rest.substringBefore('~').toLongOrNull() ?: continue
            val loss = if ('~' in rest) rest.substringAfter('~').toIntOrNull()?.coerceIn(0, 100) ?: 0 else 0
            out[id] = Latency(if (ms < 0) null else ms, time, loss)
        }
        return out
    }
}

/**
 * Sunucu başına son [KEEP] ölçüm (ms; cevapsız: null). Ayrıntı panelindeki küçük grafik ve ortanca bunu kullanır.
 * Metin biçimi: "id=12,15,-1;id2=…".
 */
object LatencyHistory {
    const val KEEP = 12

    fun add(h: Map<String, List<Int?>>, id: String, ms: Int?): Map<String, List<Int?>> {
        val cur = h[id] ?: emptyList()
        val next = (cur + ms).takeLast(KEEP)
        return h + (id to next)
    }

    fun encode(h: Map<String, List<Int?>>): String =
        h.entries.joinToString(";") { (id, l) -> id + "=" + l.joinToString(",") { (it ?: -1).toString() } }

    fun decode(s: String?): Map<String, List<Int?>> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<String, List<Int?>>()
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            if (eq <= 0) continue
            val id = part.substring(0, eq)
            if (Catalog.byId(id) == null) continue
            val vals = part.substring(eq + 1).split(',').mapNotNull { it.toIntOrNull() }.map { if (it < 0) null else it }
            if (vals.isNotEmpty()) out[id] = vals.takeLast(KEEP)
        }
        return out
    }

    /** Cevaplanan ölçümlerin ortancası; hiç yoksa null. */
    fun median(l: List<Int?>): Int? {
        val v = l.filterNotNull().sorted()
        return if (v.isEmpty()) null else v[(v.size - 1) / 2]
    }

    fun best(l: List<Int?>): Int? = l.filterNotNull().minOrNull()

    fun lossPct(l: List<Int?>): Int = if (l.isEmpty()) 0 else (l.count { it == null } * 100 + l.size / 2) / l.size
}
