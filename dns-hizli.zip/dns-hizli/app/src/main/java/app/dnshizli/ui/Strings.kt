package app.dnshizli.ui

import app.dnshizli.core.Format

/**
 * Uygulamadaki tüm Türkçe metinler tek yerde. Başka bir dil eklemek isterseniz bu nesneyi bir arayüze
 * çevirip dile göre seçmeniz yeterli olur (bkz. OKUBENI.md "Geliştirme önerileri").
 */
object Strings {
    const val APP = "DNS Hızlı"

    // --- Ana ekran durumu
    const val OFF = "Bağlı değil"
    const val CONNECTING = "Bağlanıyor…"
    const val ON = "Bağlı"
    const val ERROR = "Bağlanamadı"
    const val HINT_OFF = "Bağlanmak için küreye dokun"
    const val HINT_CONNECTING = "Birkaç saniye sürebilir"
    const val HINT_ERROR = "Tekrar denemek için dokun"
    const val ERR_DEFAULT = "Bağlantı kurulamadı"

    fun selected(name: String) = "$name seçili"
    fun onLine(name: String, ms: Int?) = if (ms == null) name else "$name · $ms ms"
    fun statsLine(seconds: Long, queries: Long, hitPercent: Int) =
        "${Format.clock(seconds)} · ${Format.count(queries)} sorgu · %$hitPercent önbellek"

    // --- Liste
    const val SERVERS = "Sunucular"
    const val FILTER_ALL = "Tümü"
    const val FILTER_FAV = "Favoriler"
    const val EMPTY_FAV = "Henüz favori yok. Bir sunucunun yıldızına dokun."
    const val EMPTY_FILTER = "Bu kategoride sunucu yok."
    const val MEASURE = "Hızları ölç"
    const val MEASURING = "Ölçülüyor…"
    const val SORT = "Hıza göre sırala"
    const val SORT_ON = "Hıza göre sıralı"
    fun serversCount(n: Int) = "$n sunucu"

    // --- Bildirim mesajları (kısa, geçici)
    const val COPIED = "Panoya kopyalandı"
    const val DISCONNECTED = "Bağlantı kesildi"
    const val BACKUP = "Yedek sunucuya geçildi"
    const val NO_REPLY = "Hiçbir sunucu yanıt vermedi"
    const val MEASURE_FIRST = "Önce hızları ölç"
    const val CONNECT = "Bağlan"
    fun fastest(name: String, ms: Int) = "En hızlı: $name · $ms ms"
    fun switched(name: String) = "$name sunucusuna geçiliyor"

    // --- Ayrıntı sayfası
    const val PRIMARY = "Birincil"
    const val SECONDARY = "İkincil"
    const val COPY = "Kopyala"
    const val CONNECT_TO_THIS = "Bu sunucuya bağlan"
    const val SWITCH_TO_THIS = "Bu sunucuya geç"
    const val CONNECTED_NOW = "Şu an bağlı"
    const val ADD_FAV = "Favori yap"
    const val REMOVE_FAV = "Favoriden çıkar"
    const val MEASURE_THIS = "Hızı ölç"
    fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Son ölçüm: yanıt yok · $ago" else "Son ölçüm: $ms ms · $ago"
    const val NEVER_MEASURED = "Henüz ölçülmedi"

    // --- Ayarlar
    const val SETTINGS = "Ayarlar"
    const val SEC_LOOK = "Görünüm"
    const val SEC_CONNECTION = "Bağlantı"
    const val SEC_INFO = "Bilgi"
    const val THEME = "Tema"
    const val THEME_AUTO = "Otomatik"
    const val THEME_AUTO_NOTE = "Otomatik · sistemin açık/koyu ayarını izler"
    const val GLASS = "Cam şeffaflığı"
    const val BUBBLES = "Kabarcıklar"
    const val MOTION = "Animasyonlar"
    const val LOW_POWER = "Düşük güç modu"
    const val LOW_POWER_NOTE = "Tüm hareketleri kapatır, pil dostu"
    const val HAPTICS = "Titreşim"
    const val HAPTICS_NOTE = "Dokunuşlarda hafif geri bildirim"
    const val AUTO_CONNECT = "Uygulama açılınca bağlan"
    const val AUTO_CONNECT_NOTE = "Uygulamayı açtığında son sunucuya bağlanır"
    const val CONNECT_ON_BOOT = "Telefon açılınca bağlan"
    const val CONNECT_ON_BOOT_NOTE = "Telefon yeniden başlayınca kendiliğinden bağlanır"
    const val REFRESH_ON_NET = "Ağ değişince yenile"
    const val REFRESH_ON_NET_NOTE = "Wi-Fi ve mobil veri arasında geçişte DNS yenilenir"
    const val CACHE = "DNS önbelleği"
    const val RULE_WIFI = "Wi-Fi sunucusu"
    const val RULE_MOBILE = "Mobil veri sunucusu"
    const val RULE_AUTO = "Otomatik"
    const val RULE_AUTO_NOTE = "Son kullandığın sunucu"
    const val RULE_WIFI_TITLE = "Wi-Fi sunucusu"
    const val RULE_MOBILE_TITLE = "Mobil veri sunucusu"
    const val STATS = "İstatistikler"
    const val STAT_QUERIES = "Toplam sorgu"
    const val STAT_HITS = "Önbellekten yanıt"
    const val STAT_TIME = "Toplam bağlı kalma"
    const val LOG = "Tanılama günlüğü"
    const val HELP = "Nasıl çalışır?"
    const val VPN_SETTINGS = "Sistem VPN ayarları"
    const val VERSION = "Sürüm"

    val OPT_BUBBLES = listOf("Kapalı", "Az", "Çok")
    val OPT_MOTION = listOf("Tam", "Az", "Kapalı")
    val OPT_CACHE = listOf("Kapalı", "Küçük", "Normal", "Büyük")

    // --- Günlük
    const val LOG_NOTE = "Yalnızca bağlantı olayları tutulur. Sorgu adları ve kişisel veri kaydedilmez."
    const val LOG_EMPTY = "Henüz kayıt yok."
    const val SHARE = "Paylaş"
    const val CLEAR = "Temizle"
    const val CLEARED = "Temizlendi"

    // --- Yardım
    val HELP_SECTIONS: List<Pair<String, String>> = listOf(
        "DNS nedir?" to
            "DNS, internet adreslerini (örneğin ornek.com) cihazların anladığı numaralara çeviren servistir. " +
            "Kullandığın DNS; hızı, gizliliği ve engellenen içerikleri etkileyebilir.",
        "Uygulama ne yapar?" to
            "Seçtiğin DNS sunucusunu tüm uygulamalarda kullanır. Bunun için telefonunda yerel bir VPN arayüzü açar; " +
            "ama trafiğin bir VPN sunucusuna gitmez. Yalnızca DNS sorguları seçtiğin sunucuya yönlendirilir, " +
            "diğer her şey normal yolundan devam eder.",
        "Gizlilik" to
            "Hesap istemez, veri toplamaz, reklam göstermez. Uygulama sorgu adlarını kaydetmez ve kendi adına hiçbir yere göndermez. " +
            "DNS sorguların, seçtiğin sağlayıcıya şifrelenmeden (düz DNS) iletilir; sağlayıcının kendi gizlilik politikası geçerlidir. " +
            "Tanılama günlüğünde yalnızca bağlantı olayları bulunur.",
        "Pil ve kaynak" to
            "Arka planda çok az kaynak kullanır. Ekran kapalıyken sürekli çalışan bir döngüsü yoktur; " +
            "yalnızca DNS sorgusu geldiğinde iş yapar.",
        "Bilmen gerekenler" to
            "Android aynı anda yalnızca bir VPN'e izin verir; başka bir VPN uygulaması açıkken bu uygulama bağlanamaz. " +
            "Bazı tarayıcılardaki \"güvenli DNS\" ayarı ve Android'in belirli bir sunucu adına sabitlenmiş \"Özel DNS\" ayarı, " +
            "kendi sunucusunu kullandığı için bu yönlendirmeyi atlayabilir; \"Otomatik\" ya da \"Kapalı\" bırakman yeterli.",
    )

    // --- Bildirim, hızlı ayar kutucuğu ve servis hataları
    const val NOTIF_CHANNEL = "Bağlantı durumu"
    const val NOTIF_CHANNEL_NOTE = "DNS bağlantısı açıkken gösterilen bildirim"
    const val NOTIF_CONNECTING = "Bağlanıyor…"
    const val NOTIF_STOP = "Kes"
    fun notifOn(name: String) = "$name sunucusuna bağlı"
    const val TILE_ON = "Bağlı"
    const val TILE_OFF = "Kapalı"
    const val ERR_PERMISSION = "VPN izni verilmedi"
    const val ERR_ESTABLISH = "VPN arayüzü açılamadı. Başka bir VPN açık olabilir."
    fun errNoReply(name: String) = "$name yanıt vermedi"
    const val ERR_SOCKET = "Ağ bağlantısı kurulamadı"
    const val ERR_REVOKED = "Bağlantı sistem tarafından kapatıldı"
    const val ERR_TUNNEL = "Tünel beklenmedik şekilde kapandı"
    const val ERR_UNKNOWN = "Beklenmeyen bir hata oldu"

    // --- İlk açılış bilgilendirmesi (Google Play VPN politikası için açık bilgilendirme)
    const val CONSENT_TITLE = "Bağlanmadan önce"
    val CONSENT_BODY: List<String> = listOf(
        "$APP, DNS sorgularını (girdiğin sitelerin adlarını) seçtiğin DNS sunucusuna yönlendirmek için Android'in VPN arayüzünü kullanır.",
        "Trafiğin bir VPN sunucusuna gönderilmez; yalnızca DNS sorguları seçtiğin sağlayıcıya şifrelenmeden iletilir ve sağlayıcının kendi gizlilik politikası geçerlidir.",
        "Uygulama kişisel veri toplamaz, sorgu adlarını kaydetmez ve kimseyle paylaşmaz.",
        "Devam edersen Android bir VPN bağlantı isteği gösterecek; \"Tamam\" demen gerekir.",
    )
    const val CONSENT_OK = "Anladım, devam et"
    const val CLOSE = "Kapat"
    const val BACK = "Geri"
}
