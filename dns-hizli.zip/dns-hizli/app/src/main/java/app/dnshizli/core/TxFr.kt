package app.dnshizli.core

/** Français. */
object TxFr : Tx() {
    override val lang = Lang.FR

    override val decimalSep = ','
    override val thousand = " k"
    override val million = " M"
    override fun percent(n: Int) = "$n %"
    override val dayU = "j"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "à l'instant"
    override fun ago(span: String) = "il y a $span"

    override val OFF = "Non connecté"
    override val CONNECTING = "Connexion…"
    override val ON = "Connecté"
    override val ERROR = "Connexion impossible"
    override val PAUSED = "En pause"
    override val HINT_OFF = "Touchez la sphère pour vous connecter"
    override val HINT_CONNECTING = "Cela peut prendre quelques secondes"
    override val HINT_ERROR = "Touchez pour réessayer"
    override val HINT_PAUSED = "Touchez pour reprendre maintenant"
    override val ERR_DEFAULT = "La connexion a échoué"
    override fun selected(name: String) = "$name sélectionné"
    override fun pausedUntil(time: String) = "Reprise à $time"
    override fun blockedShort(n: String) = "$n bloquées"
    override fun queriesShort(n: String) = "$n requêtes"
    override fun cacheShort(pct: String) = "$pct en cache"

    override val SERVERS = "Serveurs"
    override val FILTER_ALL = "Tous"
    override val FILTER_FAV = "Favoris"
    override val FILTER_RECENT = "Récents"
    override val EMPTY_FAV = "Pas encore de favoris. Touchez l'étoile d'un serveur."
    override val EMPTY_RECENT = "Vous ne vous êtes encore connecté à aucun serveur."
    override val EMPTY_FILTER = "Aucun serveur dans cette catégorie."
    override val MEASURE = "Mesurer les vitesses"
    override val MEASURING = "Mesure…"
    override val SORT = "Trier par vitesse"
    override val PULL_TO_MEASURE = "Tirez pour mesurer"
    override val RELEASE_TO_MEASURE = "Relâchez pour mesurer"
    override fun serversCount(n: Int) = if (n == 1) "1 serveur" else "$n serveurs"
    override val TAG_FAST = "Rapide"
    override val TAG_PRIVACY = "Vie privée"
    override val TAG_ADS = "Pubs"
    override val TAG_FAMILY = "Famille"
    override val TAG_SECURITY = "Sécurité"
    override val VAR_OPEN = "Sans filtre"
    override val VAR_ADS = "Anti-pub"
    override val VAR_SECURITY = "Sécurité"
    override val VAR_FAMILY = "Famille"
    override val A11Y_CONNECTED = "connecté"
    override val A11Y_ENCRYPTED = "chiffré"
    override fun favA11y(name: String) = "$name favori"

    override val COPIED = "Copié dans le presse-papiers"
    override val DISCONNECTED = "Déconnecté"
    override val BACKUP = "Passage au serveur de secours"
    override val NO_REPLY = "Aucun serveur n'a répondu"
    override val MEASURE_FIRST = "Mesurez d'abord les vitesses"
    override val CONNECT = "Connecter"
    override val UNDO = "Annuler"
    override fun fastest(name: String, ms: Int) = "Le plus rapide : $name · $ms ms"
    override fun switched(name: String) = "Passage à $name"
    override fun hiddenToast(name: String) = "$name masqué"

    override val PRIMARY = "Principal"
    override val SECONDARY = "Secondaire"
    override val COPY = "Copier"
    override fun addressA11y(label: String, ip: String) = "Adresse $label : $ip"
    override val CONNECT_TO_THIS = "Se connecter à ce serveur"
    override val SWITCH_TO_THIS = "Passer à ce serveur"
    override val CONNECTED_NOW = "Connecté maintenant"
    override val ADD_FAV = "Ajouter aux favoris"
    override val REMOVE_FAV = "Retirer des favoris"
    override val MEASURE_THIS = "Mesurer la vitesse"
    override val HIDE = "Masquer de la liste"
    override val UNHIDE = "Afficher dans la liste"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Dernière mesure : pas de réponse · $ago" else "Dernière mesure : $ms ms · $ago"
    override val NEVER_MEASURED = "Pas encore mesuré"
    override val ENC_SUPPORT = "DNS chiffré"
    override val ENC_NONE = "Non pris en charge"
    override val ENC_ONLY = "N'accepte que les connexions chiffrées"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Meilleur $best ms · médiane $median ms · perte $lossPct %"
    override val HISTORY = "Historique des mesures"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY : $n mesures, pas de réponse" else "$HISTORY : $n mesures, médiane $median ms"

    override val QUICK_TITLE = "Choix rapide"
    override val QUICK_FAVORITES = "Favoris"
    override val QUICK_RECENT = "Utilisés récemment"
    override val PAUSE_FOR = "Mettre en pause"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Reprendre"

    override val SETTINGS = "Réglages"
    override val SEC_LOOK = "Apparence"
    override val SEC_CONNECTION = "Connexion"
    override val SEC_PRIVACY = "Confidentialité et sécurité"
    override val SEC_LIST = "Liste des serveurs"
    override val SEC_INFO = "Statistiques"
    override val SEC_DATA = "Données"
    override val SEC_ABOUT = "À propos"
    override val LANGUAGE = "Langue"
    override val LANG_AUTO = "Automatique (langue du système)"
    override val THEME = "Thème"
    override val THEME_AUTO = "Automatique"
    override val THEME_AUTO_NOTE = "Automatique · suit le mode clair/sombre"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prairie"
        "ocean" -> "Océan"
        "sunset" -> "Crépuscule"
        "lavender" -> "Lavande"
        "coral" -> "Corail"
        "mint" -> "Menthe"
        "night" -> "Nuit"
        "amoled" -> "Noir (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Thème : $name"
    override val THEME_SCHEDULE = "Thème nuit selon l'heure"
    override val THEME_SCHEDULE_NOTE = "En Automatique, Nuit de 22:00 à 07:00"
    override val GLASS = "Opacité du verre"
    override val BUBBLES = "Bulles"
    override val MOTION = "Animations"
    override val TEXT_SIZE = "Taille du texte"
    override val HIGH_CONTRAST = "Contraste élevé"
    override val HIGH_CONTRAST_NOTE = "Verre plus opaque et texte plus foncé"
    override val MINIMAL = "Vue épurée"
    override val MINIMAL_NOTE = "Masque les filtres et la ligne de statistiques"
    override val LOW_POWER = "Mode économie"
    override val LOW_POWER_NOTE = "Coupe toutes les animations, ménage la batterie"
    override val HAPTICS = "Vibration"
    override val HAPTICS_NOTE = "Léger retour au toucher"
    override val ENCRYPTION = "DNS chiffré"
    override val ENCRYPTION_NOTE = "Auto : d'abord DoT, puis DoH, enfin DNS non chiffré"
    override val AUTO_CONNECT = "Connexion à l'ouverture"
    override val AUTO_CONNECT_NOTE = "Se connecte au dernier serveur à l'ouverture de l'app"
    override val CONNECT_ON_BOOT = "Connexion au démarrage"
    override val CONNECT_ON_BOOT_NOTE = "Se connecte seul après un redémarrage du téléphone"
    override val AUTO_FASTEST = "Connexion au plus rapide"
    override val AUTO_FASTEST_NOTE = "La sphère choisit le serveur le plus rapide de la dernière mesure"
    override val REFRESH_ON_NET = "Actualiser au changement de réseau"
    override val REFRESH_ON_NET_NOTE = "Le DNS est actualisé lors du passage Wi-Fi / données mobiles"
    override val NOTIFY_DROP = "Prévenir en cas de coupure"
    override val NOTIFY_DROP_NOTE = "Notification avec bouton de reconnexion en cas de coupure"
    override val CACHE = "Cache DNS"
    override val CLEAR_CACHE = "Vider le cache"
    override val CACHE_CLEARED = "Cache vidé"
    override val ONLY_CONNECTED = "Disponible une fois connecté"
    override val RULE_WIFI = "Serveur Wi-Fi"
    override val RULE_MOBILE = "Serveur données mobiles"
    override val RULE_AUTO = "Automatique"
    override val RULE_AUTO_NOTE = "Le dernier serveur utilisé"
    override val COMPACT = "Liste compacte"
    override val COMPACT_NOTE = "Lignes plus courtes, sans description"
    override val HIDDEN = "Serveurs masqués"
    override val HIDDEN_NONE = "Aucun"
    override val STAT_QUERIES = "Requêtes au total"
    override val STAT_HITS = "Servies par le cache"
    override val STAT_BLOCKED = "Bloquées (estimation)"
    override val STAT_TIME = "Temps connecté au total"
    override val WEEK = "7 derniers jours"
    override fun weekA11y(total: String) = "$total requêtes sur les 7 derniers jours"
    override val WEEKDAYS = listOf("Lu", "Ma", "Me", "Je", "Ve", "Sa", "Di")
    override val EXPORT = "Exporter les réglages"
    override val IMPORT = "Importer les réglages"
    override val EXPORTED = "Code des réglages copié"
    override val IMPORTED = "Réglages chargés"
    override val IMPORT_BAD = "Aucun code de réglages valide dans le presse-papiers"
    override val RESET_SETTINGS = "Réinitialiser les réglages"
    override val RESET_STATS = "Réinitialiser les statistiques"
    override val CONFIRM = "Vous êtes sûr ?"
    override val RESET = "Réinitialiser"
    override val RESET_DONE = "Réinitialisé"
    override val LOG = "Journal de diagnostic"
    override val HELP = "Comment ça marche ?"
    override val VPN_SETTINGS = "Réglages VPN du système"
    override val SHARE_APP = "Partager l'app"
    override val RATE_APP = "Noter l'app"
    override val FEEDBACK = "Envoyer un avis"
    override fun shareAppText(url: String) = "$APP vous connecte d'un geste aux DNS populaires : $url"
    override val VERSION = "Version"
    override val OPT_BUBBLES = listOf("Non", "Peu", "Beaucoup")
    override val OPT_MOTION = listOf("Toutes", "Réduites", "Non")
    override val OPT_CACHE = listOf("Non", "Petit", "Normal", "Grand")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Non")
    override val PLAIN_DNS = "DNS non chiffré"

    override val LOG_NOTE = "Seuls les événements de connexion sont conservés. Jamais les noms de requêtes ni de données personnelles."
    override val LOG_EMPTY = "Aucune entrée pour l'instant."
    override val SHARE = "Partager"
    override val CLEAR = "Effacer"
    override val CLEARED = "Effacé"
    override val HELP_SECTIONS = listOf(
        "Qu'est-ce que le DNS ?" to
            "Le DNS est le service qui traduit les adresses internet (comme example.com) en numéros compris par les appareils. " +
            "Le DNS utilisé peut influencer la vitesse, la confidentialité et les contenus bloqués.",
        "Que fait l'app ?" to
            "Elle utilise le serveur DNS choisi dans toutes les apps. Pour cela, elle ouvre une interface VPN locale sur votre téléphone, " +
            "mais votre trafic ne passe par aucun serveur VPN. Seules les requêtes DNS sont envoyées au serveur choisi ; " +
            "tout le reste suit son chemin habituel.",
        "DNS chiffré (DoT / DoH)" to
            "Avec les serveurs compatibles, les requêtes sont chiffrées : personne sur le réseau (propriétaire du Wi-Fi, opérateur) " +
            "ne voit les sites visités ni ne peut modifier les réponses. En Automatique, DoT est essayé d'abord, puis DoH ; " +
            "si aucun ne fonctionne, le DNS non chiffré est utilisé. Vous en êtes averti, et l'app tente de revenir au chiffrement " +
            "à chaque changement de réseau et toutes les 10 minutes. Avec \"Chiffrement strict\", le DNS non chiffré n'est jamais utilisé. " +
            "L'écran d'accueil indique la méthode utilisée.",
        "Test de connexion" to
            "Réglages > Confidentialité et sécurité > Test de connexion envoie de vraies requêtes DNS à travers le tunnel. Il montre que " +
            "le DNS répond bien depuis le serveur choisi, à quelle vitesse, si le serveur valide les signatures DNSSEC " +
            "et s'il bloque un domaine publicitaire connu.",
        "Confidentialité" to
            "Pas de compte, pas de collecte de données, pas de publicité. L'app n'enregistre pas les noms de requêtes et n'envoie rien d'elle-même. " +
            "Vos requêtes vont uniquement au fournisseur DNS choisi, selon sa propre politique de confidentialité. " +
            "Le journal de diagnostic ne contient que des événements de connexion.",
        "Batterie et ressources" to
            "Elle consomme très peu en arrière-plan. Aucune boucle ne tourne écran éteint ; " +
            "elle ne travaille que lorsqu'une requête DNS arrive. Les connexions chiffrées se ferment seules quand elles sont inactives.",
        "Bon à savoir" to
            "Android n'autorise qu'un seul VPN à la fois ; si une autre app VPN est active, celle-ci ne peut pas se connecter. " +
            "Le réglage \"DNS sécurisé\" de certains navigateurs et le \"DNS privé\" d'Android fixé sur un nom utilisent leur propre serveur " +
            "et peuvent contourner cette redirection ; il suffit de les laisser sur \"Automatique\" ou \"Désactivé\". " +
            "Appui long sur la sphère : changer vite de serveur ou mettre la connexion en pause.",
    )

    override val NOTIF_CHANNEL = "État de la connexion"
    override val NOTIF_CHANNEL_NOTE = "Affichée tant que la connexion DNS est active"
    override val NOTIF_ALERT_CHANNEL = "Alertes de connexion"
    override val NOTIF_CONNECTING = "Connexion…"
    override val NOTIF_STOP = "Déconnecter"
    override val NOTIF_NEXT = "Suivant"
    override val NOTIF_DROP_TITLE = "Connexion DNS perdue"
    override val NOTIF_RECONNECT = "Reconnecter"
    override fun notifOn(name: String, proto: String) = "Connecté à $name · $proto"
    override fun notifPaused(time: String) = "En pause · reprise à $time"
    override val TILE_ON = "Connecté"
    override val TILE_OFF = "Désactivé"
    override val WIDGET_TAP = "Touchez : connecter / déconnecter"
    override val ERR_PERMISSION = "L'autorisation VPN n'a pas été accordée"
    override val ERR_ESTABLISH = "Impossible d'ouvrir l'interface VPN. Un autre VPN est peut-être actif."
    override fun errNoReply(name: String) = "$name n'a pas répondu"
    override fun errNoProto(name: String, proto: String) = "$name ne prend pas en charge $proto"
    override val ERR_SOCKET = "Réseau inaccessible"
    override fun errPrivateDns(host: String) = "Le DNS privé d'Android est fixé sur $host et contourne l'app. Réglez Paramètres > Réseau > DNS privé sur Automatique ou Désactivé."
    override val ERR_REVOKED = "Le système a fermé la connexion"
    override val ERR_TUNNEL = "Le tunnel s'est fermé de façon inattendue"
    override val ERR_UNKNOWN = "Une erreur inattendue s'est produite"

    override val CONSENT_TITLE = "Avant de vous connecter"
    override val CONSENT_BODY = listOf(
        "$APP utilise l'interface VPN d'Android pour diriger vos requêtes DNS (les noms des sites visités) vers le serveur DNS choisi.",
        "Votre trafic n'est envoyé à aucun serveur VPN ; seules les requêtes DNS vont au fournisseur choisi. Avec les serveurs compatibles, " +
            "elles sont chiffrées (DoT/DoH) ; sinon elles circulent en clair. La politique de confidentialité du fournisseur s'applique.",
        "L'app ne collecte aucune donnée personnelle, n'enregistre pas les noms de requêtes et ne partage rien.",
        "Si vous continuez, Android affichera une demande de connexion VPN ; touchez \"OK\".",
    )
    override val CONSENT_OK = "Compris, continuer"
    override val CLOSE = "Fermer"
    override val BACK = "Retour"

    // ---- 3. sürüm ----
    override val RESUMING = "Reprise…"
    override val DOWNGRADED = "Chiffrement impossible, DNS non chiffré"
    override val UPGRADED = "DNS chiffré rétabli"
    override val NOTIF_DOWNGRADE_TITLE = "Le DNS n'est pas chiffré"
    override fun notifDowngrade(name: String) = "Impossible d'établir une connexion chiffrée avec $name. Le DNS non chiffré est utilisé ; l'app tentera de revenir au chiffrement."
    override fun backupUsed(failed: String, used: String) = "$failed n'a pas répondu, connecté à $used"
    override val NOTIF_RETRYING = "Connexion perdue, nouvel essai…"
    override fun errNoEncrypted(name: String) = "Impossible d'établir une connexion chiffrée avec $name"
    override val APPLYING = "Application du nouveau réglage à la connexion"
    override val CONFIRM_DISCONNECT = "Se déconnecter ?"
    override val DISCONNECT = "Déconnecter"

    override val SEC_NOTIF = "Notifications"
    override val STRICT_ENC = "Chiffrement strict"
    override val STRICT_ENC_NOTE = "Ne jamais revenir au DNS non chiffré"
    override val AUTO_RECONNECT = "Reconnexion automatique"
    override val AUTO_RECONNECT_NOTE = "En cas de coupure, nouvel essai après 5 s, 30 s et 2 min"
    override val BACKUP_SERVER = "Serveur de secours"
    override val BACKUP_OFF = "Désactivé"
    override val BACKUP_OFF_NOTE = "Pas de connexion si le serveur choisi ne répond pas"
    override val BACKUP_FASTEST = "Le plus rapide"
    override val BACKUP_FASTEST_NOTE = "L'autre serveur le plus rapide de la dernière mesure"
    override val CONFIRM_OFF = "Confirmer la déconnexion"
    override val CONFIRM_OFF_NOTE = "Un appui accidentel sur la sphère ne déconnecte pas"
    override val LOCK_HIDE = "Masquer sur écran verrouillé"
    override val LOCK_HIDE_NOTE = "Nom du serveur absent de la notification sur l'écran verrouillé"
    override val QUIET_NOTIF = "Notification discrète"
    override val QUIET_NOTIF_NOTE = "Sans icône dans la barre d'état, silencieuse"
    override val REMEMBER_FILTER = "Mémoriser le dernier filtre"
    override val REMEMBER_FILTER_NOTE = "Le dernier filtre choisi revient à l'ouverture de l'app"
    override val AUTO_MEASURE = "Mesurer au démarrage"
    override val AUTO_MEASURE_NOTE = "Mesure automatiquement si la dernière mesure date de plus d'un jour"
    override val MEASURE_ENC = "Mesure chiffrée"
    override val MEASURE_ENC_NOTE = "Mesure la vitesse via DoT, plus proche d'un usage chiffré réel"
    override val OPT_SORT = listOf("Par défaut", "Vitesse", "Nom")
    override fun sortA11y(mode: String) = "Tri : $mode"
    override val AUTO_LIGHT = "Automatique : thème clair"
    override val AUTO_DARK = "Automatique : thème sombre"
    override val NIGHT_HOURS = "Heures de nuit"
    override val FILTER_ENCRYPTED = "Chiffrés"
    override val FILTER_UNFILTERED = "Sans filtre"

    override val TEST = "Tester la connexion"
    override val TEST_NOTE = "DNS, DNSSEC et blocage des pubs"
    override val TESTING = "Test en cours…"
    override val TEST_TITLE = "Test de connexion"
    override val TEST_OK = "Le DNS fonctionne"
    override val TEST_FAIL = "Pas de réponse"
    override val TEST_SERVER = "Serveur"
    override val TEST_METHOD = "Méthode"
    override val TEST_LATENCY = "Temps de réponse"
    override val TEST_DNSSEC = "Validation DNSSEC"
    override val TEST_ADS = "Blocage des pubs"
    override val DNSSEC_YES = "Active"
    override val DNSSEC_NO = "Inactive"
    override val ADS_YES = "Actif"
    override val ADS_NO = "Inactif"
    override val UNKNOWN = "Inconnu"
    override val TEST_EXPLAIN = "Les requêtes sont passées par le tunnel, comme celles d'une app ; les réponses venaient du serveur choisi."
    override val TEST_AGAIN = "Tester à nouveau"

    override val RECOMMEND = "Trouver un serveur pour moi"
    override val RECOMMEND_NOTE = "Choisissez un objectif : connexion au serveur adapté le plus rapide"
    override val GOAL_SPEED = "Vitesse"
    override val GOAL_SPEED_NOTE = "Le serveur le plus rapide selon vos mesures"
    override val GOAL_PRIVACY_NOTE = "Sans journaux, axé sur la vie privée"
    override val GOAL_ADS_NOTE = "Bloque pubs et traqueurs"
    override val GOAL_FAMILY_NOTE = "Bloque les contenus pour adultes"
    override val GOAL_SECURITY_NOTE = "Bloque les sites malveillants et d'hameçonnage"
    override fun recommended(name: String) = "Recommandé : $name"

    override val PRIVATE_DNS = "Nom DNS privé"
    override val PRIVATE_DNS_NOTE = "Vous pouvez le coller dans le réglage \"DNS privé\" d'Android. Le système utilise alors ce serveur directement et cette app est contournée."
    override val CLEAR_HISTORY = "Effacer les mesures"
    override val HISTORY_CLEARED = "Mesures effacées"

    override val GUARD = "Protection permanente"
    override val GUARD_NOTE = "VPN permanent"
    override val GUARD_BODY = listOf(
        "Tant que l'app n'est pas connectée (désactivée, en pause ou après une coupure), vos requêtes DNS vont au serveur de votre fournisseur d'accès.",
        "Pour l'éviter, activez \"VPN permanent\" pour cette app dans les réglages VPN d'Android. Si \"Bloquer les connexions sans VPN\" est aussi activé, internet ne fonctionne plus du tout tant que l'app n'est pas connectée : rien ne fuit, mais une pause signifie aussi pas d'internet.",
        "Avec le VPN permanent, le système lance l'app automatiquement au démarrage du téléphone et après son arrêt.",
    )
    override val GUARD_BUTTON = "Ouvrir les réglages VPN"
    override val BATTERY = "Réglages de batterie"
    override val BATTERY_OK = "Non restreinte"
    override val BATTERY_LIMITED = "Peut être restreinte"
    override val BATTERY_BODY = listOf(
        "Android protège généralement les apps VPN. Certains fabricants (Xiaomi, Huawei, Oppo, Vivo, certaines versions de Samsung) peuvent toutefois fermer les apps en arrière-plan pour économiser la batterie.",
        "Si la connexion se coupe d'elle-même, réglez l'utilisation de la batterie de cette app sur \"Non restreinte\" ou \"Non optimisée\" ; sur certains téléphones, autorisez aussi le \"Démarrage automatique\".",
    )
    override val BATTERY_BUTTON = "Ouvrir les réglages batterie"

    override val STAT_AVG = "Temps de réponse moyen"
    override val STAT_SAVED = "Temps gagné grâce au cache"
    override val STAT_TRAFFIC = "Trafic DNS"
    override val SESSIONS = "Historique des connexions"
    override val SESSIONS_NOTE = "30 dernières connexions ; aucun nom de requête n'est enregistré"
    override val SESSIONS_EMPTY = "Aucune connexion enregistrée pour l'instant."
    override val MOST_USED = "Les plus utilisés"
    override val TODAY = "Aujourd'hui"
    override val YESTERDAY = "Hier"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Déconnecté par vous"
        EndReason.PAUSE -> "En pause"
        EndReason.SWITCH -> "Serveur changé"
        EndReason.DROP -> "Coupure"
        EndReason.REVOKED -> "Fermée par le système"
        EndReason.FAILED -> "Pas de réponse"
        EndReason.NETWORK -> "Réseau changé"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries requêtes"

    override val WHATS_NEW = "Quoi de neuf ?"
    override val WHATS_NEW_TOAST = "L'app a été mise à jour"
    override val SHOW = "Afficher"
    override val WHATS_NEW_ITEMS = listOf(
        "Connexion plus sûre : contrôles supplémentaires contre les fausses réponses DNS, alerte en cas de repli sur le DNS non chiffré, option de chiffrement strict et retour automatique au chiffrement.",
        "Test de connexion : vérifiez d'un geste que le DNS répond bien depuis le serveur choisi, ainsi que la validation DNSSEC et le blocage des pubs.",
        "Serveur de secours et reconnexion automatique : l'app se rétablit seule si le serveur choisi ne répond pas ou si la connexion se coupe.",
        "Historique des connexions, serveurs les plus utilisés, temps de réponse moyen et trafic DNS.",
        "Nouveaux filtres (Chiffrés, Sans filtre), tri par nom, \"Trouver un serveur pour moi\" et mesure au démarrage.",
        "Compteurs en direct dans la notification, bouton de pause de 15 minutes, masquage sur l'écran verrouillé et option de notification discrète.",
        "Trois nouveaux thèmes (Sakura, Miel, Aurore boréale), un thème tiré de votre fond d'écran et le choix clair/sombre pour le thème automatique.",
        "Quatre nouvelles langues : indonésien, vietnamien, polonais et ukrainien.",
    )
    override fun importedWith(changes: String) = "Réglages chargés · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "chiffrement affaibli"
        SensitiveChange.AUTO_START -> "connexion auto activée"
        SensitiveChange.RULES -> "règles de serveur modifiées"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries requêtes · $blocked bloquées"
    override val NOTIF_LOCKED = "Protection DNS active"
    override val NOTIF_QUIET_CHANNEL = "État de la connexion (discret)"
    override fun widgetToday(queries: String) = "Aujourd'hui $queries requêtes"
    override fun pauseAction(minutes: Int) = "Pause ${minutes(minutes)}"


    override val NOTES = mapOf(
        "cloudflare" to "Rapide, axé sur la vie privée",
        "google" to "Stable, très répandu",
        "quad9" to "Bloque les domaines malveillants",
        "adguard" to "Bloque pubs et traqueurs",
        "controld" to "Sans filtre, rapide",
        "opendns" to "Cisco, protection anti-phishing",
        "mullvad" to "Sans journaux, chiffré uniquement",
        "dnssb" to "Axé sur la vie privée, rapide",
        "dns4eu" to "DNS de l'UE, anti-malware",
        "uncensored" to "Ni filtre ni redirection",
        "quad9-open" to "Ne bloque rien",
        "adguard-open" to "Sans blocage, axé vie privée",
        "dns4eu-open" to "DNS de l'UE, sans filtre",
        "controld-ads" to "Pubs, traqueurs, malwares",
        "mullvad-ads" to "Pubs et traqueurs, chiffré uniquement",
        "dns4eu-ads" to "DNS de l'UE, pubs et malwares",
        "cloudflare-security" to "Bloque les sites malveillants",
        "controld-malware" to "Bloque les sites malveillants",
        "cleanbrowsing-security" to "Phishing et sites malveillants",
        "cloudflare-family" to "Filtre malwares et contenu adulte",
        "opendns-family" to "Filtre de contenu adulte",
        "adguard-family" to "Filtre pubs et contenu adulte",
        "cleanbrowsing-family" to "Contenu adulte, recherche sûre",
        "dns4eu-child" to "DNS de l'UE, protection enfants",
        "mullvad-family" to "Filtre familial, chiffré uniquement",
        "controld-family" to "Filtre de contenu adulte",
    )
}
