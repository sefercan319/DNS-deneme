package app.dnshizli.platform

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.CheckResult
import app.dnshizli.core.ConnectionCheck
import app.dnshizli.core.DnsForwarder
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Journal
import app.dnshizli.core.NetKind
import app.dnshizli.core.OrbState
import app.dnshizli.core.Rules
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi
import java.io.FileDescriptor
import java.net.InetAddress
import java.net.InetSocketAddress
import java.security.SecureRandom
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * DNS-only VPN: telefonda yerel bir tünel arayüzü açar, yalnızca sahte DNS adresine (10.111.222.2) giden
 * paketleri bu arayüze yönlendirir. Gelen DNS sorgularını [DnsForwarder] seçilen sunucuya iletir; diğer tüm trafik
 * normal yolundan, hiç dokunulmadan devam eder.
 *
 * Kaynak kullanımı:
 *  - Tünel okuyucu `poll()` ile bloklanır: paket yokken hiç uyanmaz (zamanlayıcı, yoklama yok).
 *  - Durum değişiklikleri tek bir çalışan iş parçacığında sıralanır; yarış durumu ve kilit karmaşası yok.
 *  - Ağ izleme sistem olaylarıyla çalışır; arayüz istatistikleri kendisi çeker ([VpnStatus.snapshot]).
 *
 * Her şey `cancelGen` ile iptal edilebilir: kullanıcı bağlanırken "kes" derse süren deneme en yakın noktada bırakılır.
 */
class DnsVpnService : VpnService() {

    private lateinit var prefs: PrefsStore
    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor { r -> Thread(r, "dns-vpn").also { it.isDaemon = true } }
    private val lock = Any()
    private val random = SecureRandom()
    private val live: () -> VpnUi = { snapshot() }

    @Volatile private var watcher: NetworkWatcher? = null

    // Tünel durumu: yazma yalnızca çalışan iş parçacığında (ve [lock] altında); okuma her yerden.
    @Volatile private var tun: Tunnel? = null
    @Volatile private var fw: DnsForwarder? = null
    @Volatile private var state = OrbState.OFF
    @Volatile private var serverId: String? = null
    @Volatile private var sinceMs = 0L
    @Volatile private var lastError: String? = null
    @Volatile private var baseQueries = 0L
    @Volatile private var baseHits = 0L

    @Volatile private var cancelGen = 0
    @Volatile private var lastStartId = 0
    @Volatile private var destroyed = false
    @Volatile private var lastFlushPull = 0L

    // Toplamlara aktarım sayaçları (yalnızca [lock] altında)
    private var flushedQueries = 0L
    private var flushedHits = 0L
    private var flushedAt = 0L
    private val retired = ArrayList<DnsForwarder>()

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsStore(this)
        Notifier.ensureChannel(this)
        VpnStatus.live = live
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        // startForegroundService() sözü: kısa sürede startForeground() çağrılmalı. Her komutta, durumu yansıtan bildirimle çağırırız.
        foreground(currentNotification())

        val action = intent?.action
        val wanted = intent?.getStringExtra(EXTRA_SERVER)
        if (action == ACTION_DISCONNECT) cancelGen++
        // Komutun geldiği andaki iptal numarası: sıradayken "kes" gelirse bu komut hiç başlamadan düşer.
        val gen = cancelGen

        submit(startId) {
            when {
                action == ACTION_DISCONNECT -> disconnect(startId)
                action == ACTION_CONNECT -> connect(wanted, startId, gen)
                // Sistemden (her zaman açık VPN) ya da süreç öldürüldükten sonra yeniden başlatma: açıksa yeniden bağlan.
                action == SERVICE_INTERFACE || prefs.loadSettings().wasActive -> connect(null, startId, gen)
                else -> shutdown(startId)
            }
        }
        return START_STICKY
    }

    /** Sistem VPN'i iptal etti (başka bir VPN uygulaması veya kullanıcı). Temizle ve durumu bildir. */
    override fun onRevoke() {
        Journal.add("sistem VPN bağlantısını iptal etti")
        cancelGen++
        teardown()
        prefs.setWasActive(false)
        synchronized(lock) { state = OrbState.ERROR; lastError = Strings.ERR_REVOKED }
        publish()
        super.onRevoke()   // servisi durdurur
    }

    override fun onDestroy() {
        destroyed = true
        cancelGen++
        worker.shutdownNow()
        teardown()
        Notifier.cancel(this)
        if (VpnStatus.live === live) VpnStatus.live = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ komutlar (çalışan iş parçacığı)

    private fun submit(startId: Int, task: () -> Unit) {
        try {
            worker.execute {
                try {
                    task()
                } catch (e: Throwable) {
                    Journal.add("beklenmeyen hata: ${e.javaClass.simpleName}")
                    try { fail(Strings.ERR_UNKNOWN, startId) } catch (_: Throwable) {}
                }
            }
        } catch (_: RejectedExecutionException) {
            // servis kapanıyor
        }
    }

    private fun connect(requested: String?, startId: Int, gen: Int) {
        if (destroyed || cancelGen != gen) return     // servis kapanıyor ya da komut sıradayken iptal edildi
        val settings = prefs.loadSettings()
        val kind = NetworkWatcher.currentKind(this)
        val id = requested?.takeIf { Catalog.byId(it) != null } ?: Rules.initialServer(settings, kind)
        val server = Catalog.byId(id) ?: Catalog.default
        if (tun != null && state == OrbState.ON) {
            if (server.id == serverId) publish() else switchServer(server, settings, gen)
        } else {
            startTunnel(server, settings, kind, startId, gen)
        }
    }

    private fun startTunnel(server: DnsServer, settings: AppSettings, kind: NetKind, startId: Int, gen: Int) {
        Journal.add("bağlanıyor: ${server.name}")
        synchronized(lock) {
            state = OrbState.CONNECTING
            serverId = server.id
            lastError = null
            sinceMs = System.currentTimeMillis()
            baseQueries = 0
            baseHits = 0
        }
        publish()

        if (prepare(this) != null) { fail(Strings.ERR_PERMISSION, startId); return }

        val pfd = try {
            establishTunnel()
        } catch (e: Exception) {
            Journal.add("tünel açılamadı: ${e.javaClass.simpleName}")
            null
        }
        if (pfd == null) { fail(Strings.ERR_ESTABLISH, startId); return }

        val t: Tunnel
        val f: DnsForwarder
        try {
            t = Tunnel(pfd) { tunnel, why -> tunnelEnded(tunnel, why) }
            f = try {
                newForwarder(server, settings, t)
            } catch (e: Exception) {
                t.close()
                throw e
            }
        } catch (e: Exception) {
            try { pfd.close() } catch (_: Exception) {}
            Journal.add("yönlendirici başlatılamadı: ${e.javaClass.simpleName}")
            fail(Strings.ERR_SOCKET, startId)
            return
        }
        t.forwarder = f
        synchronized(lock) { tun = t; fw = f }
        if (destroyed) { teardown(); return }     // servis tam bu sırada kapandı: açılan tüneli bırakma
        t.start()

        // Ağ varken sunucunun gerçekten cevap verdiğini doğrula; yanıtsız bir sunucuyla internet kesilmesin.
        // Ağ yoksa (ör. açılışta) doğrulama atlanır; ağ gelince izleyici soketi yeniler.
        if (kind != NetKind.NONE && !verify(f, gen)) {
            if (cancelGen != gen) return          // kullanıcı vazgeçti; kes komutu temizler
            fail(Strings.errNoReply(server.name), startId)
            return
        }
        if (cancelGen != gen) return

        synchronized(lock) {
            state = OrbState.ON
            sinceMs = System.currentTimeMillis()
            flushedQueries = 0
            flushedHits = 0
            flushedAt = SystemClock.elapsedRealtime()
        }
        prefs.setWasActive(true)
        updateNotification(Strings.notifOn(server.name))
        startWatcher()
        Journal.add("bağlandı: ${server.name}")
        publish()
    }

    /** Bağlıyken tüneli koparmadan sunucuyu değiştirir. Yeni sunucu cevap vermezse eskisi korunur. */
    private fun switchServer(server: DnsServer, settings: AppSettings, gen: Int = cancelGen) {
        val t = tun ?: return
        val old = fw ?: return
        Journal.add("sunucu değişiyor: ${server.name}")
        val fresh = try {
            newForwarder(server, settings, t)
        } catch (e: Exception) {
            Journal.add("yeni yönlendirici başlatılamadı: ${e.javaClass.simpleName}")
            publish(Strings.ERR_SOCKET)
            return
        }
        t.forwarder = fresh
        if (!verify(fresh, gen)) {
            t.forwarder = old
            fresh.close()
            if (cancelGen != gen) return
            Journal.add("sunucu değişmedi: ${server.name} yanıt vermedi")
            publish(Strings.errNoReply(server.name))
            return
        }
        synchronized(lock) {
            flushTotalsLocked()
            val os = old.stats()
            baseQueries += os.queries
            baseHits += os.cacheHits
            fw = fresh
            serverId = server.id
            flushedQueries = 0
            flushedHits = 0
            retired.add(old)
        }
        // Eski yönlendiricinin son cevapları gelsin diye kısa süre açık tutulur.
        main.postDelayed({ retire(old) }, RETIRE_MS)
        updateNotification(Strings.notifOn(server.name))
        publish()
    }

    private fun retire(f: DnsForwarder) {
        synchronized(lock) { retired.remove(f) }
        f.close()
    }

    /** Sistemin kendi çözümleyicisiyle rastgele bir ad çözdürüp sorgunun [f] üzerinden cevaplandığını doğrular. */
    private fun verify(f: DnsForwarder, gen: Int): Boolean {
        for (attempt in 0 until CHECK_TRIES) {
            if (cancelGen != gen || destroyed) return false
            val r = ConnectionCheck.run(f, { InetAddress.getByName(randomName()) }, CHECK_MS)
            if (r is CheckResult.Ok) {
                Journal.add("bağlantı testi: ${r.ms} ms")
                return true
            }
        }
        Journal.add("bağlantı testi başarısız")
        return false
    }

    private fun randomName(): String = "dh" + java.lang.Long.toString(random.nextLong() ushr 1, 36) + ".example.com"

    private fun disconnect(startId: Int) {
        Journal.add("bağlantı kesildi")
        teardown()
        prefs.setWasActive(false)
        synchronized(lock) { state = OrbState.OFF; lastError = null; serverId = null }
        publish()
        shutdown(startId)
    }

    private fun fail(message: String, startId: Int) {
        Journal.add("bağlanamadı: $message")
        teardown()
        prefs.setWasActive(false)
        synchronized(lock) { state = OrbState.ERROR; lastError = message }
        publish()
        shutdown(startId)
    }

    private fun tunnelEnded(t: Tunnel, why: String) {
        val sid = lastStartId
        submit(sid) {
            if (tun !== t) return@submit        // zaten kapatıldı ya da değiştirildi
            Journal.add("tünel kapandı: $why")
            fail(Strings.ERR_TUNNEL, sid)
        }
    }

    private fun onNetwork(kind: NetKind) {
        if (state != OrbState.ON || kind == NetKind.NONE) return
        Journal.add("ağ değişti: $kind")
        val settings = prefs.loadSettings()
        if (settings.refreshOnNetwork) fw?.resetNetwork("ağ: $kind")
        val rule = Rules.ruleFor(settings, kind)
        if (rule != null && rule != serverId) {
            Catalog.byId(rule)?.let { switchServer(it, settings) }
        }
    }

    // ------------------------------------------------------------------ temizlik, durum

    /** Tüneli, yönlendiriciyi ve ağ izleyiciyi kapatır; toplamları depoya aktarır. Birden çok kez çağrılabilir. */
    private fun teardown() {
        var t: Tunnel? = null
        var f: DnsForwarder? = null
        var old: List<DnsForwarder> = emptyList()
        synchronized(lock) {
            flushTotalsLocked()
            t = tun; f = fw
            tun = null; fw = null
            old = retired.toList()
            retired.clear()
        }
        stopWatcher()
        t?.close()
        f?.close()
        for (x in old) x.close()
    }

    /** [lock] altında çağrılır. */
    private fun flushTotalsLocked() {
        val f = fw ?: return
        val st = f.stats()
        val now = SystemClock.elapsedRealtime()
        val secs = if (state == OrbState.ON) maxOf(0L, (now - flushedAt) / 1000) else 0L
        prefs.addTotals(st.queries - flushedQueries, st.cacheHits - flushedHits, secs)
        flushedQueries = st.queries
        flushedHits = st.cacheHits
        flushedAt += secs * 1000
    }

    /** Arayüzün gördüğü canlı durum. Her iş parçacığından çağrılabilir. */
    private fun snapshot(): VpnUi {
        val st = fw?.stats()
        val s = state
        // Arayüz görünürken (istatistik çekerken) toplamlar arada bir depoya aktarılır; ek zamanlayıcı yok.
        if (s == OrbState.ON) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFlushPull > FLUSH_MS) {
                lastFlushPull = now
                submit(lastStartId) { synchronized(lock) { flushTotalsLocked() } }
            }
        }
        return VpnUi(
            state = s,
            serverId = serverId,
            sinceMs = sinceMs,
            queries = baseQueries + (st?.queries ?: 0L),
            cacheHits = baseHits + (st?.cacheHits ?: 0L),
            avgMs = st?.avgMs ?: 0,
            error = if (s == OrbState.ERROR) lastError else null,
            onBackup = st?.backup ?: false,
        )
    }

    /** Güncel durumu yayınlar. [error] doluysa bu yayına tek seferlik hata olarak eklenir (ör. başarısız sunucu geçişi). */
    private fun publish(error: String? = null) {
        val s = snapshot()
        VpnStatus.publish(if (error != null) s.copy(error = error) else s)
    }

    private fun startWatcher() {
        stopWatcher()
        val sid = lastStartId
        val w = NetworkWatcher(this) { kind -> submit(sid) { onNetwork(kind) } }
        watcher = w
        w.start()
    }

    private fun stopWatcher() {
        watcher?.stop()
        watcher = null
    }

    /** Servisi durdurur. Bu arada daha yeni bir başlatma komutu geldiyse ([startId] eskiyse) dokunmaz; yeni komut devralır. */
    private fun shutdown(startId: Int) {
        main.post {
            if (startId == lastStartId) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }
    }

    // ------------------------------------------------------------------ bildirim

    private fun currentNotification(): Notification =
        if (state == OrbState.ON) {
            Notifier.build(this, Strings.notifOn(Catalog.byId(serverId)?.name ?: Catalog.default.name), true)
        } else {
            Notifier.build(this, Strings.NOTIF_CONNECTING, true)
        }

    private fun updateNotification(text: String) {
        if (!destroyed) Notifier.update(this, Notifier.build(this, text, true))
    }

    private fun foreground(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            } else {
                startForeground(Notifier.NOTIF_ID, n)
            }
        } catch (e: Exception) {
            // Önplana alınamazsa (ör. arka plandan başlatma kısıtı) servis yine çalışır; VPN uygulaması sistemce korunur.
            Journal.add("önplan bildirimi açılamadı: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ tünel kurulumu

    private fun establishTunnel(): ParcelFileDescriptor? {
        val configure = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = Builder()
            .setSession(Strings.APP)
            .setMtu(MTU)
            .addAddress(CLIENT_ADDR, 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)      // yalnızca DNS adresi tünele girer; diğer tüm trafik normal gider
            .setBlocking(false)
            .setConfigureIntent(configure)
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        return b.establish()
    }

    private fun newForwarder(server: DnsServer, settings: AppSettings, t: Tunnel): DnsForwarder {
        val upstreams = server.addresses.map { InetSocketAddress(InetAddress.getByAddress(ipv4(it)), 53) }
        val f = DnsForwarder(
            upstreams = upstreams,
            writeToTun = { b, off, len -> t.write(b, off, len) },
            protect = { s -> protect(s) },
            cacheEntries = settings.cache.entries,
            log = { Journal.add(it) },
        )
        f.start()
        return f
    }

    private fun ipv4(s: String): ByteArray {
        val p = s.split('.')
        return ByteArray(4) { p[it].toInt().toByte() }
    }

    // ------------------------------------------------------------------ tünel okuyucu

    /**
     * Tünel arayüzünü okuyan tek iş parçacığı. `poll()` tünel ile bir "durdur" borusunu birlikte bekler: paket
     * yokken hiç uyanmaz, kapatılırken boruya yazılarak anında uyandırılır.
     */
    private class Tunnel(
        private val pfd: ParcelFileDescriptor,
        private val onEnded: (Tunnel, String) -> Unit,
    ) {
        @Volatile var forwarder: DnsForwarder? = null
        @Volatile private var stopping = false

        private val fd: FileDescriptor = pfd.fileDescriptor
        private val pipe: Array<FileDescriptor> = Os.pipe()
        private val thread = Thread({ loop() }, "dns-tun").also { it.isDaemon = true }

        // Yazma ve kapatma birbirini dışlar: kapanan bir dosya tanıtıcısının numarası başka bir dosyaya verilmişken
        // gecikmiş bir cevabın oraya yazılması (klasik fd yeniden kullanım hatası) böylece imkânsız olur.
        private val writeLock = Any()
        private var closed = false
        private val closing = AtomicBoolean(false)

        fun start() = thread.start()

        /** Cevabı tünele yazar. Kuyruk doluysa ya da arayüz kapandıysa paket sessizce atılır; istemci yeniden dener. */
        fun write(b: ByteArray, off: Int, len: Int) {
            synchronized(writeLock) {
                if (closed) return
                try { Os.write(fd, b, off, len) } catch (_: Exception) {}
            }
        }

        fun close() {
            if (!closing.compareAndSet(false, true)) return     // ikinci çağrı: borular zaten kapalı olabilir
            stopping = true
            try { Os.write(pipe[1], byteArrayOf(1), 0, 1) } catch (_: Exception) {}
            if (Thread.currentThread() !== thread && thread.isAlive) {
                try { thread.join(1000) } catch (_: InterruptedException) {}
            }
            synchronized(writeLock) {
                if (closed) return
                closed = true
                try { pfd.close() } catch (_: Exception) {}
            }
            try { Os.close(pipe[0]) } catch (_: Exception) {}
            try { Os.close(pipe[1]) } catch (_: Exception) {}
        }

        private fun loop() {
            var why = "okuma bitti"
            try {
                val tunPoll = StructPollfd()
                tunPoll.fd = fd
                tunPoll.events = OsConstants.POLLIN.toShort()
                val stopPoll = StructPollfd()
                stopPoll.fd = pipe[0]
                stopPoll.events = OsConstants.POLLIN.toShort()
                val fds = arrayOf(tunPoll, stopPoll)
                val buf = ByteArray(BUF)
                val bad = OsConstants.POLLERR or OsConstants.POLLHUP or OsConstants.POLLNVAL
                while (!stopping) {
                    tunPoll.revents = 0
                    stopPoll.revents = 0
                    try {
                        Os.poll(fds, -1)
                    } catch (e: ErrnoException) {
                        if (e.errno == OsConstants.EINTR) continue
                        throw e
                    }
                    if (stopping || stopPoll.revents.toInt() != 0) break
                    val r = tunPoll.revents.toInt()
                    if (r and OsConstants.POLLIN != 0) drain(buf)
                    else if (r and bad != 0) { why = "tünel arayüzü kapandı"; break }
                }
            } catch (e: Exception) {
                why = "hata: ${e.javaClass.simpleName}"
            }
            if (!stopping) onEnded(this, why)
        }

        /** Hazır paketleri (en çok [MAX_BURST]) okuyup yönlendiriciye verir. Okunacak kalmayınca döner. */
        private fun drain(buf: ByteArray) {
            var n = 0
            while (n++ < MAX_BURST && !stopping) {
                val len = try {
                    Os.read(fd, buf, 0, buf.size)
                } catch (e: ErrnoException) {
                    if (e.errno == OsConstants.EAGAIN) return
                    if (e.errno == OsConstants.EINTR) continue
                    throw e
                }
                if (len <= 0) throw IllegalStateException("tünel okuması 0 bayt döndü")
                // Tek bir bozuk paket tüneli düşürmesin.
                try { forwarder?.onPacket(buf, len) } catch (_: Exception) {}
            }
        }

        private companion object {
            const val BUF = 4096
            const val MAX_BURST = 32
        }
    }

    companion object {
        const val ACTION_CONNECT = "app.dnshizli.CONNECT"
        const val ACTION_DISCONNECT = "app.dnshizli.DISCONNECT"
        const val EXTRA_SERVER = "server"

        /** Tünelin istemci adresi ve sahte DNS adresi (özel aralık; gerçek bir cihazla çakışmaz). */
        const val CLIENT_ADDR = "10.111.222.1"
        const val FAKE_DNS = "10.111.222.2"
        const val MTU = 1500

        private const val CHECK_TRIES = 4
        private const val CHECK_MS = 1500L
        private const val RETIRE_MS = 3000L
        private const val FLUSH_MS = 60_000L

        /** [serverId] boşsa servis ağ kuralına, yoksa son kullanılan sunucuya bakar. */
        fun connectIntent(ctx: Context, serverId: String?): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_CONNECT).also {
                if (serverId != null) it.putExtra(EXTRA_SERVER, serverId)
            }

        fun disconnectIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_DISCONNECT)
    }
}
