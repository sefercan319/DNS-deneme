package app.dnshizli.core

/** Українська */
object TxUk : Tx() {
    override val lang = Lang.UK

    override val decimalSep = ','
    override val thousand = " тис."
    override val million = " млн"
    override fun percent(n: Int) = "$n%"
    override val dayU = "д"
    override val hourU = "год"
    override val minU = "хв"
    override val secU = "с"
    override val msU = "мс"
    override val byteUnits = listOf("Б", "КБ", "МБ", "ГБ")
    override val justNow = "щойно"
    override fun ago(span: String) = "$span тому"

    override val OFF = "Не підключено"
    override val CONNECTING = "Підключення…"
    override val ON = "Підключено"
    override val ERROR = "Не вдалося підключитися"
    override val PAUSED = "Пауза"
    override val HINT_OFF = "Торкніться сфери, щоб підключитися"
    override val HINT_CONNECTING = "Це може тривати кілька секунд"
    override val HINT_ERROR = "Торкніться, щоб повторити"
    override val HINT_PAUSED = "Торкніться, щоб продовжити зараз"
    override val ERR_DEFAULT = "Не вдалося встановити з'єднання"
    override fun selected(name: String) = "Обрано $name"
    override fun pausedUntil(time: String) = "Продовження о $time"
    override fun blockedShort(n: String) = "заблоковано: $n"
    override fun queriesShort(n: String) = "запитів: $n"
    override fun cacheShort(pct: String) = "кеш $pct"

    override val SERVERS = "Сервери"
    override val FILTER_ALL = "Усі"
    override val FILTER_FAV = "Обране"
    override val FILTER_RECENT = "Нещодавні"
    override val EMPTY_FAV = "Обраного поки немає. Торкніться зірочки біля сервера."
    override val EMPTY_RECENT = "Ви ще не підключалися до жодного сервера."
    override val EMPTY_FILTER = "У цій категорії немає серверів."
    override val MEASURE = "Виміряти швидкість"
    override val MEASURING = "Вимірювання…"
    override val SORT = "Порядок сортування"
    override val PULL_TO_MEASURE = "Потягніть, щоб виміряти швидкість"
    override val RELEASE_TO_MEASURE = "Відпустіть для вимірювання"
    override fun serversCount(n: Int) = "серверів: $n"
    override val TAG_FAST = "Швидкі"
    override val TAG_PRIVACY = "Приватність"
    override val TAG_ADS = "Без реклами"
    override val TAG_FAMILY = "Сім'я"
    override val TAG_SECURITY = "Захист"
    override val VAR_OPEN = "Без фільтра"
    override val VAR_ADS = "Без реклами"
    override val VAR_SECURITY = "Захист"
    override val VAR_FAMILY = "Сім'я"
    override val A11Y_CONNECTED = "підключено"
    override val A11Y_ENCRYPTED = "зашифровано"
    override fun favA11y(name: String) = "$name в обраному"

    override val COPIED = "Скопійовано в буфер обміну"
    override val DISCONNECTED = "Відключено"
    override val BACKUP = "Перемкнено на резервний сервер"
    override val NO_REPLY = "Жоден сервер не відповів"
    override val MEASURE_FIRST = "Спершу виміряйте швидкість"
    override val CONNECT = "Підключити"
    override val UNDO = "Скасувати"
    override fun fastest(name: String, ms: Int) = "Найшвидший: $name · $ms мс"
    override fun switched(name: String) = "Перемикання на $name"
    override fun hiddenToast(name: String) = "$name приховано"

    override val PRIMARY = "Основний"
    override val SECONDARY = "Додатковий"
    override val COPY = "Копіювати"
    override fun addressA11y(label: String, ip: String) = "$label адреса: $ip"
    override val CONNECT_TO_THIS = "Підключитися до цього сервера"
    override val SWITCH_TO_THIS = "Перейти на цей сервер"
    override val CONNECTED_NOW = "Зараз підключено"
    override val ADD_FAV = "Додати до обраного"
    override val REMOVE_FAV = "Прибрати з обраного"
    override val MEASURE_THIS = "Виміряти швидкість"
    override val HIDE = "Приховати зі списку"
    override val UNHIDE = "Показати у списку"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Останній замір: немає відповіді · $ago" else "Останній замір: $ms мс · $ago"
    override val NEVER_MEASURED = "Ще не вимірювався"
    override val ENC_SUPPORT = "Шифрований DNS"
    override val ENC_NONE = "Не підтримується"
    override val ENC_ONLY = "Приймає лише шифровані підключення"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Найкращий $best мс · медіана $median мс · втрати $lossPct%"
    override val HISTORY = "Історія замірів"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: замірів $n, немає відповіді" else "$HISTORY: замірів $n, медіана $median мс"

    override val QUICK_TITLE = "Швидкий вибір"
    override val QUICK_FAVORITES = "Обране"
    override val QUICK_RECENT = "Нещодавно використані"
    override val PAUSE_FOR = "Пауза"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} год" else "$n хв"
    override val RESUME = "Продовжити"

    override val SETTINGS = "Налаштування"
    override val SEC_LOOK = "Вигляд"
    override val SEC_CONNECTION = "Підключення"
    override val SEC_PRIVACY = "Приватність і захист"
    override val SEC_LIST = "Список серверів"
    override val SEC_INFO = "Статистика"
    override val SEC_DATA = "Дані"
    override val SEC_ABOUT = "Про застосунок"
    override val LANGUAGE = "Мова"
    override val LANG_AUTO = "Автоматично (мова системи)"
    override val THEME = "Тема"
    override val THEME_AUTO = "Авто"
    override val THEME_AUTO_NOTE = "Авто · за світлою/темною темою системи"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Аква"
        "meadow" -> "Луг"
        "ocean" -> "Океан"
        "sunset" -> "Захід сонця"
        "lavender" -> "Лаванда"
        "coral" -> "Корал"
        "mint" -> "М'ята"
        "sakura" -> "Сакура"
        "honey" -> "Мед"
        "night" -> "Ніч"
        "amoled" -> "Чорна (AMOLED)"
        "aurora" -> "Північне сяйво"
        "dynamic" -> "Шпалери"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Тема: $name"
    override val THEME_SCHEDULE = "Нічна тема за розкладом"
    override val THEME_SCHEDULE_NOTE = "У режимі Авто темна тема в обрані вами години"
    override val GLASS = "Прозорість скла"
    override val BUBBLES = "Бульбашки"
    override val MOTION = "Анімації"
    override val TEXT_SIZE = "Розмір тексту"
    override val HIGH_CONTRAST = "Високий контраст"
    override val HIGH_CONTRAST_NOTE = "Щільніше скло й темніший текст"
    override val MINIMAL = "Простий вигляд"
    override val MINIMAL_NOTE = "Приховує фільтри та рядок статистики"
    override val LOW_POWER = "Енергозбереження"
    override val LOW_POWER_NOTE = "Вимикає всю анімацію, береже батарею"
    override val HAPTICS = "Вібрація"
    override val HAPTICS_NOTE = "Легкий відгук на дотик"
    override val ENCRYPTION = "Шифрований DNS"
    override val ENCRYPTION_NOTE = "Авто: спершу DoT, потім DoH, наприкінці звичайний DNS"
    override val AUTO_CONNECT = "Підключатися під час запуску"
    override val AUTO_CONNECT_NOTE = "Під час відкриття застосунку підключається до останнього сервера"
    override val CONNECT_ON_BOOT = "Підключатися під час увімкнення"
    override val CONNECT_ON_BOOT_NOTE = "Підключається сам після перезавантаження телефона"
    override val AUTO_FASTEST = "До найшвидшого"
    override val AUTO_FASTEST_NOTE = "Сфера обирає найшвидший сервер за останнім заміром"
    override val REFRESH_ON_NET = "Оновлювати під час зміни мережі"
    override val REFRESH_ON_NET_NOTE = "DNS оновлюється під час переходу між Wi-Fi та мобільним інтернетом"
    override val NOTIFY_DROP = "Повідомляти про розрив"
    override val NOTIFY_DROP_NOTE = "Сповіщення з кнопкою перепідключення в разі несподіваного розриву"
    override val CACHE = "Кеш DNS"
    override val CLEAR_CACHE = "Очистити кеш"
    override val CACHE_CLEARED = "Кеш очищено"
    override val ONLY_CONNECTED = "Доступно під час підключення"
    override val RULE_WIFI = "Сервер для Wi-Fi"
    override val RULE_MOBILE = "Сервер для мобільного інтернету"
    override val RULE_AUTO = "Авто"
    override val RULE_AUTO_NOTE = "Останній використаний сервер"
    override val COMPACT = "Компактний список"
    override val COMPACT_NOTE = "Коротші рядки без описів"
    override val HIDDEN = "Приховані сервери"
    override val HIDDEN_NONE = "Немає"
    override val STAT_QUERIES = "Усього запитів"
    override val STAT_HITS = "Відповідей із кешу"
    override val STAT_BLOCKED = "Заблоковано (оцінка)"
    override val STAT_TIME = "Усього підключено"
    override val WEEK = "Останні 7 днів"
    override fun weekA11y(total: String) = "Запитів за 7 днів: $total"
    override val WEEKDAYS = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
    override val EXPORT = "Експорт налаштувань"
    override val IMPORT = "Імпорт налаштувань"
    override val EXPORTED = "Код налаштувань скопійовано в буфер обміну"
    override val IMPORTED = "Налаштування завантажено"
    override val IMPORT_BAD = "У буфері обміну немає чинного коду налаштувань"
    override val RESET_SETTINGS = "Скинути налаштування"
    override val RESET_STATS = "Скинути статистику"
    override val CONFIRM = "Ви впевнені?"
    override val RESET = "Скинути"
    override val RESET_DONE = "Скинуто"
    override val LOG = "Журнал діагностики"
    override val HELP = "Як це працює?"
    override val VPN_SETTINGS = "Налаштування VPN системи"
    override val SHARE_APP = "Поділитися застосунком"
    override val RATE_APP = "Оцінити застосунок"
    override val FEEDBACK = "Надіслати відгук"
    override fun shareAppText(url: String) = "$APP підключає до популярних DNS-серверів одним дотиком: $url"
    override val VERSION = "Версія"
    override val OPT_BUBBLES = listOf("Немає", "Мало", "Багато")
    override val OPT_MOTION = listOf("Повна", "Менше", "Немає")
    override val OPT_CACHE = listOf("Немає", "Малий", "Звичайний", "Великий")
    override val OPT_ENCRYPTION = listOf("Авто", "DoT", "DoH", "Немає")
    override val PLAIN_DNS = "Звичайний DNS"

    override val LOG_NOTE = "Зберігаються лише події підключення. Імена запитів і особисті дані не записуються."
    override val LOG_EMPTY = "Записів поки немає."
    override val SHARE = "Поділитися"
    override val CLEAR = "Очистити"
    override val CLEARED = "Очищено"
    override val HELP_SECTIONS = listOf(
        "Що таке DNS?" to
            "DNS — це служба, яка перетворює інтернет-адреси (наприклад, example.com) на числа, зрозумілі пристроям. " +
            "Від обраного DNS залежать швидкість, приватність і те, що буде заблоковано.",
        "Що робить застосунок?" to
            "Він використовує обраний DNS-сервер у всіх застосунках. Для цього на телефоні відкривається локальний VPN-інтерфейс, " +
            "але ваш трафік не йде на VPN-сервер. На обраний сервер надсилаються лише DNS-запити, " +
            "усе інше йде звичайним шляхом.",
        "Шифрований DNS (DoT / DoH)" to
            "На серверах із підтримкою запити передаються зашифрованими: ніхто в мережі (власник Wi-Fi, оператор) не бачить, " +
            "які сайти ви відкриваєте, і не може підмінити відповіді. У режимі «Авто» спершу пробується DoT, потім DoH; " +
            "якщо не працює жоден, використовується звичайний DNS. Вас про це попередять, а застосунок намагатиметься повернутися до шифрування " +
            "під час кожної зміни мережі та кожні 10 хвилин. Якщо ввімкнено «Суворе шифрування», звичайний DNS не використовується ніколи. " +
            "Головний екран показує, який спосіб зараз використовується.",
        "Перевірка підключення" to
            "Налаштування > Приватність і захист > Перевірка підключення надсилає справжні DNS-запити через тунель. Вона показує, що " +
            "DNS справді відповідає з обраного сервера, наскільки швидко, чи перевіряє сервер підписи DNSSEC " +
            "і чи блокує відомий рекламний домен.",
        "Приватність" to
            "Без облікового запису, без збирання даних, без реклами. Застосунок не зберігає імена запитів і сам нічого нікуди не надсилає. " +
            "Ваші запити йдуть лише обраному DNS-провайдеру, згідно з його політикою конфіденційності. " +
            "У журналі діагностики лише події підключення.",
        "Батарея та ресурси" to
            "У фоні витрачає дуже мало. Коли екран вимкнено, нічого не крутиться в циклі; " +
            "робота відбувається лише тоді, коли надходить DNS-запит. Шифровані з'єднання закриваються самі, коли простоюють.",
        "Корисно знати" to
            "Android дозволяє лише один VPN одночасно; поки активний інший VPN, цей застосунок не підключиться. " +
            "«Безпечний DNS» у браузерах і «Приватний DNS» в Android із вказаним іменем хоста використовують власний сервер " +
            "і можуть оминати це перенаправлення; достатньо залишити їх у режимі «Автоматично» або «Вимкнено». " +
            "Довге натискання на сферу: швидкий перехід на звичні сервери або пауза підключення на деякий час.",
    )

    override val NOTIF_CHANNEL = "Стан підключення"
    override val NOTIF_CHANNEL_NOTE = "Показується, поки DNS-підключення активне"
    override val NOTIF_ALERT_CHANNEL = "Попередження про підключення"
    override val NOTIF_CONNECTING = "Підключення…"
    override val NOTIF_STOP = "Відключити"
    override val NOTIF_NEXT = "Наступний"
    override val NOTIF_DROP_TITLE = "DNS-підключення перервано"
    override val NOTIF_RECONNECT = "Перепідключити"
    override fun notifOn(name: String, proto: String) = "Підключено до $name · $proto"
    override fun notifPaused(time: String) = "Пауза · продовження о $time"
    override val TILE_ON = "Підключено"
    override val TILE_OFF = "Вимк."
    override val WIDGET_TAP = "Дотик: підключити / відключити"
    override val ERR_PERMISSION = "Дозвіл VPN не надано"
    override val ERR_ESTABLISH = "Не вдалося відкрити VPN-інтерфейс. Можливо, активний інший VPN."
    override fun errNoReply(name: String) = "$name не відповів"
    override fun errNoProto(name: String, proto: String) = "$name не підтримує $proto"
    override val ERR_SOCKET = "Мережа недоступна"
    override fun errPrivateDns(host: String) = "Приватний DNS Android закріплено за $host, і він оминає застосунок. Встановіть Налаштування > Мережа > Приватний DNS: Автоматично або Вимкнено."
    override val ERR_REVOKED = "Підключення закрито системою"
    override val ERR_TUNNEL = "Тунель несподівано закрився"
    override val ERR_UNKNOWN = "Сталася непередбачена помилка"

    override val CONSENT_TITLE = "Перед підключенням"
    override val CONSENT_BODY = listOf(
        "$APP використовує VPN-інтерфейс Android, щоб спрямовувати ваші DNS-запити (імена сайтів, які ви відвідуєте) на обраний DNS-сервер.",
        "Ваш трафік не надсилається на VPN-сервер; до обраного провайдера йдуть лише DNS-запити. На серверах із підтримкою " +
            "вони шифруються (DoT/DoH), на решті передаються без шифрування. Діє політика конфіденційності провайдера.",
        "Застосунок не збирає особисті дані, не зберігає імена запитів і нікому нічого не передає.",
        "Якщо продовжити, Android покаже запит на VPN-підключення; потрібно натиснути «OK».",
    )
    override val CONSENT_OK = "Зрозуміло, продовжити"
    override val CLOSE = "Закрити"
    override val BACK = "Назад"

    override val RESUMING = "Відновлення…"
    override val DOWNGRADED = "Шифрування не вдалося, звичайний DNS"
    override val UPGRADED = "Знову шифрований DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS не зашифровано"
    override fun notifDowngrade(name: String) = "Не вдалося встановити шифроване підключення до $name. Використовується звичайний DNS; застосунок спробує повернутися до шифрування."
    override fun backupUsed(failed: String, used: String) = "$failed не відповів, підключено до $used"
    override val NOTIF_RETRYING = "Підключення перервано, повтор…"
    override fun errNoEncrypted(name: String) = "Не вдалося встановити шифроване підключення до $name"
    override val APPLYING = "Нове налаштування застосовується до підключення"
    override val CONFIRM_DISCONNECT = "Відключитися?"
    override val DISCONNECT = "Відключити"

    override val SEC_NOTIF = "Сповіщення"
    override val STRICT_ENC = "Суворе шифрування"
    override val STRICT_ENC_NOTE = "Ніколи не переходити на звичайний DNS"
    override val AUTO_RECONNECT = "Автоперепідключення"
    override val AUTO_RECONNECT_NOTE = "У разі розриву повтор через 5 с, 30 с і 2 хв"
    override val BACKUP_SERVER = "Резервний сервер"
    override val BACKUP_OFF = "Немає"
    override val BACKUP_OFF_NOTE = "Не підключатися, якщо обраний сервер не відповідає"
    override val BACKUP_FASTEST = "Найшвидший"
    override val BACKUP_FASTEST_NOTE = "Найшвидший з інших серверів за останнім заміром"
    override val CONFIRM_OFF = "Питати перед відключенням"
    override val CONFIRM_OFF_NOTE = "Випадковий дотик до сфери не відключить"
    override val LOCK_HIDE = "Приховати на екрані блокування"
    override val LOCK_HIDE_NOTE = "Ім'я сервера не видно у сповіщенні на екрані блокування"
    override val QUIET_NOTIF = "Тихе сповіщення"
    override val QUIET_NOTIF_NOTE = "Без значка в рядку стану, без звуку"
    override val REMEMBER_FILTER = "Запам'ятовувати фільтр"
    override val REMEMBER_FILTER_NOTE = "Під час відкриття застосунку повернеться останній обраний фільтр"
    override val AUTO_MEASURE = "Замір під час запуску"
    override val AUTO_MEASURE_NOTE = "Вимірює сам, якщо останньому заміру понад добу"
    override val MEASURE_ENC = "Шифрований замір"
    override val MEASURE_ENC_NOTE = "Вимірює швидкість через DoT, ближче до реальної роботи із шифруванням"
    override val OPT_SORT = listOf("Звичайний", "Швидкість", "Назва")
    override fun sortA11y(mode: String) = "Сортування: $mode"
    override val AUTO_LIGHT = "Авто: світла тема"
    override val AUTO_DARK = "Авто: темна тема"
    override val NIGHT_HOURS = "Нічні години"
    override val FILTER_ENCRYPTED = "Шифровані"
    override val FILTER_UNFILTERED = "Без фільтра"

    override val TEST = "Перевірити підключення"
    override val TEST_NOTE = "DNS, DNSSEC і блокування реклами"
    override val TESTING = "Перевірка…"
    override val TEST_TITLE = "Перевірка підключення"
    override val TEST_OK = "DNS працює"
    override val TEST_FAIL = "Немає відповіді"
    override val TEST_SERVER = "Сервер"
    override val TEST_METHOD = "Спосіб"
    override val TEST_LATENCY = "Час відповіді"
    override val TEST_DNSSEC = "Перевірка DNSSEC"
    override val TEST_ADS = "Блокування реклами"
    override val DNSSEC_YES = "Перевіряє"
    override val DNSSEC_NO = "Не перевіряє"
    override val ADS_YES = "Увімк."
    override val ADS_NO = "Вимк."
    override val UNKNOWN = "Невідомо"
    override val TEST_EXPLAIN = "Запити надіслано через тунель так само, як їх надіслав би застосунок; відповіді надійшли від обраного сервера."
    override val TEST_AGAIN = "Перевірити знову"

    override val RECOMMEND = "Підібрати сервер"
    override val RECOMMEND_NOTE = "Оберіть мету, і ми підключимо найшвидший відповідний"
    override val GOAL_SPEED = "Швидкість"
    override val GOAL_SPEED_NOTE = "Найшвидший сервер за вашими замірами"
    override val GOAL_PRIVACY_NOTE = "Без журналів, наголос на приватності"
    override val GOAL_ADS_NOTE = "Блокує рекламу й трекери"
    override val GOAL_FAMILY_NOTE = "Блокує вміст для дорослих"
    override val GOAL_SECURITY_NOTE = "Блокує шкідливі та фішингові сайти"
    override fun recommended(name: String) = "Рекомендуємо: $name"

    override val PRIVATE_DNS = "Ім'я для приватного DNS"
    override val PRIVATE_DNS_NOTE = "Його можна вставити в налаштування «Приватний DNS» в Android. Тоді система використовуватиме цей сервер напряму, оминаючи застосунок."
    override val CLEAR_HISTORY = "Очистити історію замірів"
    override val HISTORY_CLEARED = "Заміри очищено"

    override val GUARD = "Постійний захист"
    override val GUARD_NOTE = "Постійний VPN"
    override val GUARD_BODY = listOf(
        "Поки застосунок не підключено (вимкнено, на паузі або після розриву), ваші DNS-запити йдуть на сервер інтернет-провайдера.",
        "Щоб цього уникнути, увімкніть для цього застосунку «Постійний VPN» у налаштуваннях VPN в Android. Якщо також увімкнено «Блокувати з'єднання без VPN», інтернет узагалі не працюватиме, поки застосунок не підключено: витоків немає, але пауза теж означає відсутність інтернету.",
        "З постійним VPN система сама запускає застосунок під час увімкнення телефона та після його зупинки.",
    )
    override val GUARD_BUTTON = "Відкрити налаштування VPN"
    override val BATTERY = "Налаштування батареї"
    override val BATTERY_OK = "Без обмежень"
    override val BATTERY_LIMITED = "Може обмежуватися"
    override val BATTERY_BODY = listOf(
        "Android зазвичай захищає VPN-застосунки. Але деякі виробники (Xiaomi, Huawei, Oppo, Vivo, деякі версії Samsung) можуть закривати фонові застосунки заради економії батареї.",
        "Якщо підключення само обривається, встановіть для цього застосунку витрату батареї «Без обмежень» або «Не оптимізувати»; на деяких телефонах також дозвольте «Автозапуск».",
    )
    override val BATTERY_BUTTON = "Відкрити налаштування батареї"

    override val STAT_AVG = "Середній час відповіді"
    override val STAT_SAVED = "Час, заощаджений кешем"
    override val STAT_TRAFFIC = "DNS-трафік"
    override val SESSIONS = "Історія підключень"
    override val SESSIONS_NOTE = "Останні 30 підключень; імена запитів не зберігаються"
    override val SESSIONS_EMPTY = "Підключень поки не записано."
    override val MOST_USED = "Найчастіше"
    override val TODAY = "Сьогодні"
    override val YESTERDAY = "Учора"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Ви відключили"
        EndReason.PAUSE -> "Пауза"
        EndReason.SWITCH -> "Зміна сервера"
        EndReason.DROP -> "Розрив"
        EndReason.REVOKED -> "Закрито системою"
        EndReason.FAILED -> "Немає відповіді"
        EndReason.NETWORK -> "Зміна мережі"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · запитів: $queries"

    override val WHATS_NEW = "Що нового?"
    override val WHATS_NEW_TOAST = "Застосунок оновлено"
    override val SHOW = "Показати"
    override val WHATS_NEW_ITEMS = listOf(
        "Надійніше підключення: додаткові перевірки проти підроблених відповідей DNS, попередження про перехід на звичайний DNS, суворе шифрування та автоматичне повернення до шифрування.",
        "Перевірка підключення: одним дотиком переконайтеся, що DNS відповідає від обраного сервера, а також перевірте DNSSEC і блокування реклами.",
        "Резервний сервер і автоперепідключення: застосунок сам відновлюється, якщо обраний сервер не відповідає або підключення обривається.",
        "Історія підключень, найвикористаніші сервери, середній час відповіді та DNS-трафік.",
        "Нові фільтри («Шифровані», «Без фільтра»), сортування за назвою, «Підібрати сервер» і замір під час запуску.",
        "Живі лічильники в сповіщенні, кнопка паузи на 15 хвилин, приховування на екрані блокування та тихе сповіщення.",
        "Три нові теми («Сакура», «Мед», «Північне сяйво»), тема за кольором шпалер і вибір світлої/темної теми для режиму Авто.",
        "Чотири нові мови: індонезійська, в'єтнамська, польська та українська.",
    )
    override fun importedWith(changes: String) = "Налаштування завантажено · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "шифрування послаблено"
        SensitiveChange.AUTO_START -> "увімкнено автопідключення"
        SensitiveChange.RULES -> "змінено правила серверів"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · запитів: $queries · заблоковано: $blocked"
    override val NOTIF_LOCKED = "Захист DNS увімкнено"
    override val NOTIF_QUIET_CHANNEL = "Стан підключення (тихо)"
    override fun widgetToday(queries: String) = "Сьогодні запитів: $queries"
    override fun pauseAction(minutes: Int) = "Пауза ${minutes(minutes)}"

    override val NOTES = mapOf(
        "cloudflare" to "Швидкий, дбає про приватність",
        "google" to "Стабільний, популярний",
        "quad9" to "Блокує шкідливі домени",
        "adguard" to "Блокує рекламу й трекери",
        "controld" to "Без фільтрів, швидкий",
        "opendns" to "Cisco, захист від фішингу",
        "mullvad" to "Без логів, лише шифрування",
        "dnssb" to "Дбає про приватність, швидкий",
        "dns4eu" to "DNS ЄС, захист від шкідливих",
        "uncensored" to "Без фільтрів і перенаправлень",
        "quad9-open" to "Нічого не блокує",
        "adguard-open" to "Без блокувань, дбає про приватність",
        "dns4eu-open" to "DNS ЄС, без фільтра",
        "controld-ads" to "Реклама, трекери, шкідливі",
        "mullvad-ads" to "Реклама й трекери, лише шифрування",
        "dns4eu-ads" to "DNS ЄС, реклама й шкідливі",
        "cloudflare-security" to "Блокує шкідливі сайти",
        "controld-malware" to "Блокує шкідливі сайти",
        "cleanbrowsing-security" to "Фішинг і шкідливі сайти",
        "cloudflare-family" to "Фільтр шкідливих і 18+",
        "opendns-family" to "Фільтр вмісту 18+",
        "adguard-family" to "Фільтр реклами та 18+",
        "cleanbrowsing-family" to "Вміст 18+, безпечний пошук",
        "dns4eu-child" to "DNS ЄС, захист дітей",
        "mullvad-family" to "Сімейний фільтр, лише шифрування",
        "controld-family" to "Фільтр вмісту 18+",
    )
}
