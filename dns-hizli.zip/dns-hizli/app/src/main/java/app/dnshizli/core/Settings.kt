package app.dnshizli.core

enum class Motion(val id: String) {
    FULL("full"), REDUCED("reduced"), OFF("off");

    /** Animasyon sürelerinin çarpanı. */
    val scale: Float get() = when (this) { FULL -> 1f; REDUCED -> 0.5f; OFF -> 0f }
}

enum class BubbleLevel(val id: String, val count: Int) {
    OFF("off", 0), FEW("few", 7), MANY("many", 15)
}

enum class CacheLevel(val id: String, val entries: Int) {
    OFF("off", 0), SMALL("small", 64), NORMAL("normal", 256), LARGE("large", 1024)
}

/** Kullanıcının tüm seçimleri. Değişmez; her değişiklik yeni bir kopya üretir. */
data class AppSettings(
    // Görünüm
    val theme: String = Themes.AUTO_ID,
    val glass: Float = 0.55f,
    val bubbles: BubbleLevel = BubbleLevel.FEW,
    val motion: Motion = Motion.FULL,
    val haptics: Boolean = true,
    val lowPower: Boolean = false,
    // Bağlantı
    val autoConnect: Boolean = false,
    val connectOnBoot: Boolean = false,
    val refreshOnNetwork: Boolean = true,
    val cache: CacheLevel = CacheLevel.NORMAL,
    val wifiServer: String? = null,
    val mobileServer: String? = null,
    // Liste
    val lastServer: String? = null,
    val favorites: Set<String> = emptySet(),
    val sortBySpeed: Boolean = false,
    // İlk açılış bilgilendirmesi gösterildi ve kabul edildi mi
    val onboarded: Boolean = false,
    // Durum (servis yazar)
    val wasActive: Boolean = false,
    // Kalıcı toplam istatistik
    val totalQueries: Long = 0,
    val totalHits: Long = 0,
    val totalSeconds: Long = 0,
) {
    /** Düşük güç modu animasyonları ve kabarcıkları kapatır. */
    val effectiveMotion: Motion get() = if (lowPower) Motion.OFF else motion
    val effectiveBubbles: BubbleLevel get() = if (lowPower) BubbleLevel.OFF else bubbles
}

/** Ayarları düz metin sözlüğüne çevirir ve geri okur. Bozuk veya bilinmeyen değerler varsayılana düşer. */
object SettingsCodec {

    fun encode(s: AppSettings): Map<String, String> = linkedMapOf(
        "theme" to s.theme,
        "glass" to s.glass.toString(),
        "bubbles" to s.bubbles.id,
        "motion" to s.motion.id,
        "haptics" to s.haptics.toString(),
        "lowPower" to s.lowPower.toString(),
        "autoConnect" to s.autoConnect.toString(),
        "connectOnBoot" to s.connectOnBoot.toString(),
        "refreshOnNetwork" to s.refreshOnNetwork.toString(),
        "cache" to s.cache.id,
        "wifiServer" to (s.wifiServer ?: ""),
        "mobileServer" to (s.mobileServer ?: ""),
        "lastServer" to (s.lastServer ?: ""),
        "favorites" to s.favorites.joinToString(","),
        "sortBySpeed" to s.sortBySpeed.toString(),
        "onboarded" to s.onboarded.toString(),
        "wasActive" to s.wasActive.toString(),
        "totalQueries" to s.totalQueries.toString(),
        "totalHits" to s.totalHits.toString(),
        "totalSeconds" to s.totalSeconds.toString(),
    )

    fun decode(m: Map<String, String?>): AppSettings {
        val d = AppSettings()
        fun bool(k: String, def: Boolean) = when (m[k]) { "true" -> true; "false" -> false; else -> def }
        fun long(k: String) = m[k]?.toLongOrNull()?.coerceAtLeast(0) ?: 0L
        fun server(k: String) = m[k]?.takeIf { Catalog.byId(it) != null }
        return AppSettings(
            theme = m["theme"]?.takeIf { Themes.isValidId(it) } ?: d.theme,
            glass = m["glass"]?.toFloatOrNull()?.takeIf { !it.isNaN() }?.coerceIn(0f, 1f) ?: d.glass,
            bubbles = BubbleLevel.values().firstOrNull { it.id == m["bubbles"] } ?: d.bubbles,
            motion = Motion.values().firstOrNull { it.id == m["motion"] } ?: d.motion,
            haptics = bool("haptics", d.haptics),
            lowPower = bool("lowPower", d.lowPower),
            autoConnect = bool("autoConnect", d.autoConnect),
            connectOnBoot = bool("connectOnBoot", d.connectOnBoot),
            refreshOnNetwork = bool("refreshOnNetwork", d.refreshOnNetwork),
            cache = CacheLevel.values().firstOrNull { it.id == m["cache"] } ?: d.cache,
            wifiServer = server("wifiServer"),
            mobileServer = server("mobileServer"),
            lastServer = server("lastServer"),
            favorites = m["favorites"]?.split(',')?.filter { Catalog.byId(it) != null }?.toSet() ?: emptySet(),
            sortBySpeed = bool("sortBySpeed", d.sortBySpeed),
            onboarded = bool("onboarded", d.onboarded),
            wasActive = bool("wasActive", d.wasActive),
            totalQueries = long("totalQueries"),
            totalHits = long("totalHits"),
            totalSeconds = long("totalSeconds"),
        )
    }
}
