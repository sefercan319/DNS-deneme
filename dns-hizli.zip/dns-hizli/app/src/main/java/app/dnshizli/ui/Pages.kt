package app.dnshizli.ui

import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.BubbleLevel
import app.dnshizli.core.CacheLevel
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.Encryption
import app.dnshizli.core.Format
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.L
import app.dnshizli.core.Lang
import app.dnshizli.core.TextScale
import app.dnshizli.core.Motion
import app.dnshizli.core.NightHours
import app.dnshizli.core.OrbMath
import app.dnshizli.core.OrbState
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Session
import app.dnshizli.core.SessionLog
import app.dnshizli.core.Tag
import app.dnshizli.core.TextFit
import app.dnshizli.core.Themes
import app.dnshizli.core.UsageStats
import kotlin.math.roundToInt

/** Seçim panelindeki bir seçenek. */
class Option(val id: String?, val name: String, val note: String = "", val selected: Boolean = false)

/** Sayfaların ve alt sayfaların gezinti istekleri (sahne uygular). */
interface Nav {
    fun openSettings()
    fun openLog()
    fun openHelp()
    fun openDetails(server: DnsServer)

    /** "Otomatik" + tüm sunucular arasından seçim (ağ kuralları). */
    fun openChoice(title: String, current: String?, onPick: (String?) -> Unit)

    /** Genel seçim paneli (dil, gizlenen sunucular…). */
    fun openOptions(title: String, options: List<Option>, empty: String = "", onPick: (String?) -> Unit)

    /** Küreye uzun basınca: favoriler, son kullanılanlar, duraklatma. */
    fun openQuickPick()

    /** Bağlantı testini başlatır ve sonucunu panelde gösterir. */
    fun openTest()

    /** "Bana uygun sunucu": amaç seçimi. */
    fun openRecommend()

    /** Başlık, paragraflar ve isteğe bağlı bir eylem düğmesi olan bilgi paneli. */
    fun openInfo(title: String, paragraphs: List<String>, button: String? = null, action: (() -> Unit)? = null)
    fun openSessions()
    fun openWhatsNew()
    fun back()
}

class TopSpacer : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = M.HEADER_H + env.insetTop + 4f }
}

class BottomSpacer : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = 28f + env.insetBottom }
}

/** Üstte cam başlık çubuğu, altında dikey kaydırılan içerik olan sayfa iskeleti. */
abstract class ScrollPage(title: String, back: Boolean, protected val nav: Nav) : Node() {
    protected val header = Header(title, back) { nav.back() }
    protected val scroll = ScrollView()
    protected val col = Column(gap = 14f)

    init {
        col.add(TopSpacer())
        scroll.setContent(col)
        add(scroll)
        add(header)
    }

    /** Alt sınır boşluğunu ekler; alt sınıflar içeriği ekledikten sonra çağırır. */
    protected fun finish() { col.add(BottomSpacer()) }

    val scrollOffset: Float get() = scroll.offset

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = env.height
        val cw = minOf(maxW, M.MAX_W)
        val l = (maxW - cw) / 2f
        col.padL = l + M.PAD
        col.padR = l + M.PAD
        header.layout(env, maxW)
        scroll.clipInsetTop = header.h
        scroll.setViewport(env, maxW, h)
        onLaidOut(env, l)
    }

    protected open fun onLaidOut(env: Env, left: Float) {}

    /** İçerik değişti (satır sayısı vb.): yeniden yerleştir. */
    fun relayoutContent(env: Env) { scroll.setViewport(env, w, h) }

    override fun tick(dt: Float, env: Env): Boolean {
        header.barAlpha = Easing.clamp01((scroll.offset - 6f) / 40f)
        return tickKids(dt, env)
    }
}

// =============================================================================== ana sayfa

/** Üst çubukta, küre kaydırılıp görünmez olunca beliren küçük bağlantı düğmesi. */
class MiniOrb(private val onTap: () -> Unit) : PressNode() {
    var alpha = 0f
    override val tappable: Boolean get() = alpha > 0.5f
    override val hitSlop: Float get() = 2f
    override fun layout(env: Env, maxW: Float) { w = 40f; h = 40f }
    override fun draw(g: Gfx, env: Env) {
        if (alpha <= 0.01f) return
        val st = env.model.vpn.state
        g.save()
        g.alpha(alpha)
        pressScale(g, w / 2f, h / 2f, 0.1f)
        val glow = if (st == OrbState.ON) 0.7f else 0f
        env.art.orb(g, w / 2f, h / 2f, 17f, OrbMath.targetLevel(st), env.time * 1.5f, glow, if (st == OrbState.ERROR) 1f else 0f, press.value * 0.6f)
        g.restore()
    }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { super.onUp(lx, ly, tap, env); if (tap) { env.tap(true); onTap() } }
    override fun a11y(): A11y? = null
    fun label(env: Env): String = Strings.APP + ": " + env.model.statusTitle()
}

/** Süzgeç çipleri: sığdığı kadar satıra dizilir. Yatay kaydırma yok: her çip görünür ve erişilebilir. */
class ChipsRow(private val model: AppModel) : Node() {
    private val filters = Filter.values()
    private val chips = filters.map { f -> Chip(f.label) { model.setFilter(f) } }
    private var seen = -1

    init { for (c in chips) add(c) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var x = 0f
        var y = PAD_T
        for (c in chips) {
            c.layout(env, maxW)
            if (x > 0f && x + c.w > maxW + 0.5f) { x = 0f; y += M.CHIP_H + GAP }
            c.x = x; c.y = y
            x += c.w + GAP
        }
        h = y + M.CHIP_H + PAD_B
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        for (i in filters.indices) chips[i].setSelected(filters[i] == model.filter, env, animate)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    private companion object {
        const val GAP = 8f
        const val PAD_T = 6f
        const val PAD_B = 10f
    }
}

/** "Sunucular" başlığı, sayısı ve sağda sırala / ölç düğmeleri. */
class ListHeader(private val model: AppModel) : Node() {
    private val title = Label(Strings.SERVERS, 18f, bold = true)
    private val count = Label("", 13f, ink = Ink.SOFT)
    private val sortBtn = IconButton(Icon.SORT, Strings.SORT, 40f) { model.toggleSort() }.also {
        it.labelFn = { Strings.sortA11y(Strings.OPT_SORT[model.settings.sortMode.ordinal]) }
    }
    private val measureBtn = IconButton(Icon.REFRESH, Strings.MEASURE, 40f) { model.measureAll() }
    private val spoken = A11yOnly("", Role.HEADING)
    private var seen = -1

    init { add(spoken); add(measureBtn); add(sortBtn) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = 48f
        measureBtn.layout(env, maxW); sortBtn.layout(env, maxW)
        measureBtn.x = w - measureBtn.w; measureBtn.y = (h - measureBtn.h) / 2f
        sortBtn.x = measureBtn.x - 10f - sortBtn.w; sortBtn.y = measureBtn.y
        syncText()
        title.layout(env, maxW - 120f)
        title.x = 4f; title.y = (h - title.h) / 2f
        count.x = 4f + env.metrics.textWidth(title.text, env.sz(18f), true) + 10f
        count.layout(env, maxOf(40f, sortBtn.x - 8f - count.x))   // büyük yazıda da kısalmaz
        count.y = title.y + (title.h - count.h) / 2f + 1f
        spoken.x = 0f; spoken.y = title.y; spoken.h = title.h
        spoken.w = spokenWidth(env)
    }

    private fun spokenWidth(env: Env): Float = minOf(sortBtn.x - 8f, count.x + env.metrics.textWidth(count.text, env.sz(13f), false))

    /** Modelden gelen metin ve düğme durumları. */
    private fun syncText() {
        seen = model.version
        count.text = Strings.serversCount(model.visibleServers().size)
        spoken.label = Strings.SERVERS + ", " + count.text
        sortBtn.active = model.settings.sortMode != app.dnshizli.core.SortMode.DEFAULT
        measureBtn.active = model.measuring
    }

    private fun refresh(env: Env) {
        if (seen == model.version) return
        syncText()
        spoken.w = spokenWidth(env)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env)
        if (model.measuring) measureBtn.spin = (measureBtn.spin + dt * 360f) % 360f else measureBtn.spin = 0f
        return tickKids(dt, env)
    }

    /** Ölçüm dönerken küre gibi süs animasyonudur: 33 ms'lik kareler yeter. */
    override fun ambient(env: Env): Boolean = (env.ambient && model.measuring) || ambientKids(env)

    override fun draw(g: Gfx, env: Env) {
        g.save(); g.translate(title.x, title.y); title.draw(g, env); g.restore()
        g.save(); g.translate(count.x, count.y); count.draw(g, env); g.restore()
        drawKids(g, env)
    }
}

/** Sunucu satırlarını tutar; satır nesneleri kimliğe göre yeniden kullanılır (animasyon durumu korunur). */
class ServerListNode(private val onLong: (DnsServer) -> Unit) : Node() {
    private val rows = HashMap<String, ServerRow>()
    private val empty = Label("", 14f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 0)

    fun sync(env: Env) {
        val m = env.model
        val list = m.visibleServers()
        removeAll()
        for (s in list) add(rows.getOrPut(s.id) { ServerRow(s, onLong) })
        empty.text = when {
            list.isNotEmpty() -> ""
            m.effectiveFilter == Filter.FAVORITES -> Strings.EMPTY_FAV
            m.effectiveFilter == Filter.RECENT -> Strings.EMPTY_RECENT
            else -> Strings.EMPTY_FILTER
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = 0f
        for (k in kids) {
            k.layout(env, maxW)
            k.x = 0f
            k.y = cy
            cy += k.h + M.ROW_GAP
        }
        h = if (kids.isEmpty()) 0f else cy - M.ROW_GAP
        if (empty.text.isNotEmpty()) {
            empty.layout(env, maxW - 24f)
            empty.x = 12f
            empty.y = 16f
            h = empty.h + 32f
        }
    }

    override fun draw(g: Gfx, env: Env) {
        if (empty.text.isNotEmpty()) { g.save(); g.translate(empty.x, empty.y); empty.draw(g, env); g.restore() }
        drawKids(g, env)
    }

    override fun a11y(): A11y? = if (empty.text.isNotEmpty()) A11y(empty.text, Role.TEXT) else null
}

class HomePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.APP, false, nav) {
    private val orb = OrbBlock({ model.tapOrb() }, { nav.openQuickPick() })
    private val chips = ChipsRow(model)
    private val listHead = ListHeader(model)
    private val list = ServerListNode { nav.openDetails(it) }
    private val gear = IconButton(Icon.GEAR, Strings.SETTINGS) { nav.openSettings() }
    private val mini = MiniOrb { model.tapOrb() }
    private var seen = -1

    init {
        header.addRight(gear)
        header.addRight(mini)
        col.add(orb)
        col.add(chips)
        col.add(listHead)
        col.add(list)
        finish()
        col.gap = 10f
        chips.visible = !model.settings.minimal
        // En üstte aşağı çekip bırakınca tüm sunucuların hızı ölçülür.
        scroll.pullable = true
        scroll.onPullRelease = { d -> if (d >= Scroller.PULL_TRIGGER) { model.measureAll() } }
    }

    override fun onLaidOut(env: Env, left: Float) { seen = -1 }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) {
            seen = model.version
            chips.visible = !model.settings.minimal
            list.sync(env)
            relayoutContent(env)
        }
        val a = super.tick(dt, env)
        // Küre görünümden çıkınca üst çubukta mini düğme belirir.
        val orbScreenBottom = orb.y + orb.cy + orb.r * 0.55f - scroll.offset
        val limit = M.HEADER_H + env.insetTop
        mini.alpha = Easing.clamp01((limit - orbScreenBottom + 6f) / 36f)
        return a
    }

    override fun draw(g: Gfx, env: Env) {
        val p = scroll.pull
        if (p > 2f) {
            // Çekme ipucu: içeriğin üstünde açılan boşlukta, çekildikçe belirir ve döner.
            val ready = p >= Scroller.PULL_TRIGGER
            val a = Easing.clamp01(p / 48f)
            val cy = header.h + p * 0.5f + 2f
            g.save()
            g.alpha(a)
            val fs = env.sz(13f)
            val text = if (ready) Strings.RELEASE_TO_MEASURE else Strings.PULL_TO_MEASURE
            val tw = env.metrics.textWidth(text, fs, true)
            val x0 = (w - tw - 26f) / 2f
            g.save()
            g.translate(x0 + 9f, cy)
            g.rotate(p * 2.4f)
            Icons.draw(g, Icon.REFRESH, 0f, 0f, 18f, if (ready) env.theme.link else env.theme.textSoft, 2f)
            g.restore()
            g.paint(if (ready) env.theme.link else env.theme.textSoft)
            g.text(text, x0 + 26f, centerBaseline(cy, fs), fs, true, ALIGN_LEFT)
            g.restore()
        }
        super.draw(g, env)
    }
}

// =============================================================================== ayarlar

class SettingsPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.SETTINGS, true, nav) {
    init {
        col.add(SectionTitle(Strings.SEC_LOOK))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.LANGUAGE, { langName(it.lang) }, Icon.GLOBE) { openLanguage(nav) })
            c.add(SwatchRow())
            c.add(NavRow(Strings.AUTO_LIGHT, { themeName(it.autoLight) }) { openAutoTheme(nav, dark = false) })
            c.add(NavRow(Strings.AUTO_DARK, { themeName(it.autoDark) }) { openAutoTheme(nav, dark = true) })
            c.add(ToggleRow(Strings.THEME_SCHEDULE, Strings.THEME_SCHEDULE_NOTE, { it.themeSchedule }, { s, v -> s.copy(themeSchedule = v) }))
            c.add(SegmentRow(Strings.NIGHT_HOURS, NightHours.values().map { it.label }, { it.nightHours.ordinal }, { s, i -> s.copy(nightHours = NightHours.values()[i]) }))
            c.add(SliderRow(Strings.GLASS, { it.glass }, { s, v -> s.copy(glass = v) }, { Strings.percent((it.glass * 100).roundToInt()) }))
            c.add(SegmentRow(Strings.TEXT_SIZE, Strings.OPT_TEXT, { it.textScale.ordinal }, { s, i -> s.copy(textScale = TextScale.values()[i]) }))
            c.add(SegmentRow(Strings.BUBBLES, Strings.OPT_BUBBLES, { it.bubbles.ordinal }, { s, i -> s.copy(bubbles = BubbleLevel.values()[i]) }))
            c.add(SegmentRow(Strings.MOTION, Strings.OPT_MOTION, { it.motion.ordinal }, { s, i -> s.copy(motion = Motion.values()[i]) }))
            c.add(ToggleRow(Strings.HIGH_CONTRAST, Strings.HIGH_CONTRAST_NOTE, { it.highContrast }, { s, v -> s.copy(highContrast = v) }))
            c.add(ToggleRow(Strings.MINIMAL, Strings.MINIMAL_NOTE, { it.minimal }, { s, v -> s.copy(minimal = v) }))
            c.add(ToggleRow(Strings.LOW_POWER, Strings.LOW_POWER_NOTE, { it.lowPower }, { s, v -> s.copy(lowPower = v) }))
            c.add(ToggleRow(Strings.HAPTICS, Strings.HAPTICS_NOTE, { it.haptics }, { s, v -> s.copy(haptics = v) }))
        })

        col.add(SectionTitle(Strings.SEC_PRIVACY))
        col.add(SettingsCard().also { c ->
            c.add(SegmentRow(Strings.ENCRYPTION, Strings.OPT_ENCRYPTION, { it.encryption.ordinal }, { s, i -> s.copy(encryption = Encryption.values()[i]) }, Strings.ENCRYPTION_NOTE))
            c.add(ToggleRow(Strings.STRICT_ENC, Strings.STRICT_ENC_NOTE, { it.strictEncryption }, { s, v -> s.copy(strictEncryption = v) }))
            c.add(NavRow(Strings.TEST, { if (model.testing) Strings.TESTING else "" }, Icon.CHECK) { nav.openTest() })
            c.add(SegmentRow(Strings.CACHE, Strings.OPT_CACHE, { it.cache.ordinal }, { s, i -> s.copy(cache = CacheLevel.values()[i]) }))
            c.add(NavRow(Strings.CLEAR_CACHE, null, Icon.REFRESH) { model.clearCache() })
        })

        col.add(SectionTitle(Strings.SEC_CONNECTION))
        col.add(SettingsCard().also { c ->
            c.add(ToggleRow(Strings.AUTO_CONNECT, Strings.AUTO_CONNECT_NOTE, { it.autoConnect }, { s, v -> s.copy(autoConnect = v) }))
            c.add(ToggleRow(Strings.CONNECT_ON_BOOT, Strings.CONNECT_ON_BOOT_NOTE, { it.connectOnBoot }, { s, v -> s.copy(connectOnBoot = v) }))
            c.add(ToggleRow(Strings.AUTO_FASTEST, Strings.AUTO_FASTEST_NOTE, { it.autoFastest }, { s, v -> s.copy(autoFastest = v) }))
            c.add(ToggleRow(Strings.AUTO_RECONNECT, Strings.AUTO_RECONNECT_NOTE, { it.autoReconnect }, { s, v -> s.copy(autoReconnect = v) }))
            c.add(ToggleRow(Strings.REFRESH_ON_NET, Strings.REFRESH_ON_NET_NOTE, { it.refreshOnNetwork }, { s, v -> s.copy(refreshOnNetwork = v) }))
            c.add(ToggleRow(Strings.CONFIRM_OFF, Strings.CONFIRM_OFF_NOTE, { it.confirmDisconnect }, { s, v -> s.copy(confirmDisconnect = v) }))
            c.add(NavRow(Strings.BACKUP_SERVER, { backupName(it.backupServer) }) { openBackup(nav) })
            c.add(NavRow(Strings.RULE_WIFI, { ruleName(it.wifiServer) }) {
                nav.openChoice(Strings.RULE_WIFI, model.settings.wifiServer) { id -> model.update { it.copy(wifiServer = id) } }
            })
            c.add(NavRow(Strings.RULE_MOBILE, { ruleName(it.mobileServer) }) {
                nav.openChoice(Strings.RULE_MOBILE, model.settings.mobileServer) { id -> model.update { it.copy(mobileServer = id) } }
            })
            c.add(NavRow(Strings.GUARD, { Strings.GUARD_NOTE }, Icon.SHIELD) {
                nav.openInfo(Strings.GUARD, Strings.GUARD_BODY, Strings.GUARD_BUTTON) { model.host.openVpnSettings() }
            })
            c.add(NavRow(Strings.BATTERY, { batteryText() }, Icon.BOLT) {
                nav.openInfo(Strings.BATTERY, Strings.BATTERY_BODY, Strings.BATTERY_BUTTON) { model.host.openBatterySettings() }
            })
        })

        col.add(SectionTitle(Strings.SEC_NOTIF))
        col.add(SettingsCard().also { c ->
            c.add(ToggleRow(Strings.NOTIFY_DROP, Strings.NOTIFY_DROP_NOTE, { it.notifyDrop }, { s, v -> s.copy(notifyDrop = v) }))
            c.add(ToggleRow(Strings.LOCK_HIDE, Strings.LOCK_HIDE_NOTE, { it.hideOnLockscreen }, { s, v -> s.copy(hideOnLockscreen = v) }))
            c.add(ToggleRow(Strings.QUIET_NOTIF, Strings.QUIET_NOTIF_NOTE, { it.quietNotification }, { s, v -> s.copy(quietNotification = v) }))
        })

        col.add(SectionTitle(Strings.SEC_LIST))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.RECOMMEND, null, Icon.STAR) { nav.openRecommend() })
            c.add(ToggleRow(Strings.COMPACT, Strings.COMPACT_NOTE, { it.compact }, { s, v -> s.copy(compact = v) }))
            c.add(ToggleRow(Strings.REMEMBER_FILTER, Strings.REMEMBER_FILTER_NOTE, { it.rememberFilter }, { s, v -> s.copy(rememberFilter = v) }))
            c.add(ToggleRow(Strings.AUTO_MEASURE, Strings.AUTO_MEASURE_NOTE, { it.autoMeasure }, { s, v -> s.copy(autoMeasure = v) }))
            c.add(ToggleRow(Strings.MEASURE_ENC, Strings.MEASURE_ENC_NOTE, { it.measureEncrypted }, { s, v -> s.copy(measureEncrypted = v) }))
            c.add(NavRow(Strings.HIDDEN, { if (it.hidden.isEmpty()) Strings.HIDDEN_NONE else it.hidden.size.toString() }) { openHidden(nav) })
        })

        col.add(SectionTitle(Strings.SEC_INFO))
        col.add(SettingsCard().also { c ->
            c.add(InfoRow(Strings.STAT_QUERIES) { Format.count(it.totalQueries) })
            c.add(InfoRow(Strings.STAT_HITS) { Strings.percent(model.hitPercentTotal()) })
            c.add(InfoRow(Strings.STAT_BLOCKED) { Format.count(it.totalBlocked) })
            c.add(InfoRow(Strings.STAT_TIME) { Format.span(it.totalSeconds) })
            c.add(InfoRow(Strings.STAT_AVG) { s -> s.avgLatencyMs?.let { Format.ms(it) } ?: "—" })
            c.add(InfoRow(Strings.STAT_SAVED) { Format.span(it.savedSeconds) })
            c.add(InfoRow(Strings.STAT_TRAFFIC) { Strings.traffic(Format.bytes(it.bytesUp), Format.bytes(it.bytesDown)) })
            c.add(WeekChart())
            c.add(NavRow(Strings.SESSIONS, { SessionLog.decode(it.sessions).size.toString() }, Icon.LOG) { nav.openSessions() })
        })

        col.add(SectionTitle(Strings.SEC_DATA))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.EXPORT, null, Icon.COPY) { model.exportSettings() })
            c.add(NavRow(Strings.IMPORT, null, Icon.LOG) { model.importSettings() })
            c.add(NavRow(Strings.CLEAR_HISTORY, null, Icon.REFRESH) { model.clearHistory() })
            c.add(NavRow(Strings.RESET_SETTINGS, null, Icon.REFRESH) { model.askResetSettings() })
            c.add(NavRow(Strings.RESET_STATS, null, Icon.BLOCK) { model.askResetStats() })
        })

        col.add(SectionTitle(Strings.SEC_ABOUT))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.WHATS_NEW, null, Icon.INFO) { nav.openWhatsNew() })
            c.add(NavRow(Strings.LOG, null, Icon.LOG) { nav.openLog() })
            c.add(NavRow(Strings.HELP, null, Icon.INFO) { nav.openHelp() })
            c.add(NavRow(Strings.VPN_SETTINGS, null, Icon.SHIELD) { model.host.openVpnSettings() })
            c.add(NavRow(Strings.SHARE_APP, null, Icon.HEART) { model.host.shareApp() })
            c.add(NavRow(Strings.RATE_APP, null, Icon.STAR) { model.host.rateApp() })
            c.add(NavRow(Strings.FEEDBACK, null, Icon.LOG) { model.host.shareText(model.host.diagnostics()) })
            c.add(InfoRow(Strings.VERSION) { model.host.versionName() })
        })
        finish()
    }

    private fun ruleName(id: String?): String = id?.let { Catalog.byId(it)?.name } ?: Strings.RULE_AUTO

    private fun backupName(id: String?): String = when (id) {
        null -> Strings.BACKUP_OFF
        AppSettings.BACKUP_AUTO -> Strings.BACKUP_FASTEST
        else -> Catalog.byId(id)?.name ?: Strings.BACKUP_OFF
    }

    private fun batteryText(): String = when (model.host.batteryRestricted()) {
        true -> Strings.BATTERY_LIMITED
        false -> Strings.BATTERY_OK
        null -> ""
    }

    private fun themeName(id: String): String = if (id == Themes.DYNAMIC_ID) Strings.themeName(id) else (Themes.byId(id)?.name ?: id)

    /** Satırdaki kısa değer: "Otomatik" ya da dilin kendi adı. */
    private fun langName(setting: String): String = if (setting == L.AUTO) Strings.THEME_AUTO else (Lang.byCode(setting)?.native ?: Strings.THEME_AUTO)

    private fun openLanguage(nav: Nav) {
        val cur = model.settings.lang
        val opts = ArrayList<Option>()
        opts.add(Option(L.AUTO, Strings.LANG_AUTO, L.lang.native, cur == L.AUTO))
        for (l in Lang.values()) opts.add(Option(l.code, l.native, "", cur == l.code))
        nav.openOptions(Strings.LANGUAGE, opts) { id -> if (id != null) model.setLanguage(id) }
    }

    /** "Otomatik" temanın açık ya da koyu modda kullanacağı tema; duvar kağıdı teması varsa o da seçilebilir. */
    private fun openAutoTheme(nav: Nav, dark: Boolean) {
        val cur = if (dark) model.settings.autoDark else model.settings.autoLight
        val opts = ArrayList<Option>()
        if (model.accentSeed != null) opts.add(Option(Themes.DYNAMIC_ID, Strings.themeName(Themes.DYNAMIC_ID), "", cur == Themes.DYNAMIC_ID))
        for (t in Themes.all.filter { it.dark == dark }) opts.add(Option(t.id, t.name, "", cur == t.id))
        nav.openOptions(if (dark) Strings.AUTO_DARK else Strings.AUTO_LIGHT, opts) { id ->
            if (id != null) model.update { if (dark) it.copy(autoDark = id) else it.copy(autoLight = id) }
        }
    }

    private fun openBackup(nav: Nav) {
        val cur = model.settings.backupServer
        val opts = ArrayList<Option>()
        opts.add(Option(OFF_ID, Strings.BACKUP_OFF, Strings.BACKUP_OFF_NOTE, cur == null))
        opts.add(Option(AppSettings.BACKUP_AUTO, Strings.BACKUP_FASTEST, Strings.BACKUP_FASTEST_NOTE, cur == AppSettings.BACKUP_AUTO))
        for (s in Catalog.all) opts.add(Option(s.id, s.name, s.note, cur == s.id))
        nav.openOptions(Strings.BACKUP_SERVER, opts) { id -> model.update { it.copy(backupServer = if (id == OFF_ID) null else id) } }
    }

    private fun openHidden(nav: Nav) {
        val opts = model.hiddenServers().map { Option(it.id, it.name, Strings.UNHIDE) }
        nav.openOptions(Strings.HIDDEN, opts, Strings.HIDDEN_NONE) { id -> if (id != null) model.unhide(id) }
    }

    private companion object {
        const val OFF_ID = "off"
    }
}

// =============================================================================== bağlantı geçmişi

/** En çok kullanılan sunucular ve son oturumlar (yalnızca sunucu, yöntem, süre, sorgu sayısı; ad tutulmaz). */
class SessionsPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.SESSIONS, true, nav) {
    init {
        col.add(Label(Strings.SESSIONS_NOTE, 13f, ink = Ink.SOFT, maxLines = 0))
        val top = UsageStats.top(model.settings.usage, 3)
        if (top.isNotEmpty()) {
            col.add(SectionTitle(Strings.MOST_USED))
            col.add(SettingsCard().also { c ->
                for ((id, secs) in top) c.add(InfoRow(Catalog.byId(id)?.name ?: id) { Format.span(secs) })
            })
        }
        val sessions = SessionLog.decode(model.settings.sessions).asReversed()
        col.add(SectionTitle(Strings.SESSIONS))
        if (sessions.isEmpty()) col.add(ParagraphCard(Strings.SESSIONS_EMPTY))
        else col.add(SettingsCard().also { c -> for (x in sessions) c.add(SessionRow(x, model)) })
        finish()
    }
}

/** Bağlantı geçmişinde tek satır: sunucu · yöntem, zaman, süre ve bitiş nedeni. */
class SessionRow(private val s: Session, private val model: AppModel) : Node() {
    private val title = (Catalog.byId(s.serverId)?.name ?: s.serverId) + " · " + Strings.protoName(s.proto)
    private val line1 = whenText() + " · " + Strings.endReason(s.end)
    private val line2 = Strings.sessionLine(Format.span(s.seconds), Format.count(s.queries))
    private var shown = arrayOf(title, line1, line2)
    private var laidW = -1f
    private var laidFs = 0f

    private fun whenText(): String {
        val now = model.host.now()
        val day = app.dnshizli.core.DailyStats.today(s.startMs)
        val today = app.dnshizli.core.DailyStats.today(now)
        val yesterday = app.dnshizli.core.DailyStats.today(now - 86_400_000L)
        val d = when (day) { today -> Strings.TODAY; yesterday -> Strings.YESTERDAY; else -> String.format(java.util.Locale.ROOT, "%02d.%02d", day % 100, (day / 100) % 100) }
        return d + " " + Format.hm(s.startMs)
    }

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 74f; laidW = -1f }

    private fun relay(env: Env) {
        laidW = w; laidFs = env.fs
        shown = arrayOf(
            TextFit.ellipsize(env.metrics, title, w - 32f, env.sz(15f), true),
            TextFit.ellipsize(env.metrics, line1, w - 32f, env.sz(13f), false),
            TextFit.ellipsize(env.metrics, line2, w - 32f, env.sz(13f), false),
        )
    }

    override fun draw(g: Gfx, env: Env) {
        if (laidW != w || laidFs != env.fs) relay(env)
        g.paint(env.theme.text)
        g.text(shown[0], 16f, 24f, env.sz(15f), true, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        g.text(shown[1], 16f, 44f, env.sz(13f), false, ALIGN_LEFT)
        g.text(shown[2], 16f, 62f, env.sz(13f), false, ALIGN_LEFT)
    }

    override fun a11y(): A11y = A11y("$title. $line1. $line2", Role.TEXT)
}

// =============================================================================== neler yeni

class WhatsNewPage(nav: Nav) : ScrollPage(Strings.WHATS_NEW, true, nav) {
    init {
        for (item in Strings.WHATS_NEW_ITEMS) col.add(ParagraphCard("• $item"))
        finish()
        col.gap = 8f
    }
}

// =============================================================================== yardım ve günlük

/** İçinde çok satırlı yazı olan cam kart. */
class ParagraphCard(text: String) : Node() {
    private val label = Label(text, 15f, ink = Ink.TEXT, maxLines = 0)
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        label.layout(env, maxW - 32f)
        label.x = 16f; label.y = 14f
        h = label.h + 28f
    }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        g.save(); g.translate(label.x, label.y); label.draw(g, env); g.restore()
    }
    override fun a11y(): A11y = A11y(label.text, Role.TEXT)
}

class HelpPage(nav: Nav) : ScrollPage(Strings.HELP, true, nav) {
    init {
        for ((title, body) in Strings.HELP_SECTIONS) {
            col.add(SectionTitle(title))
            col.add(ParagraphCard(body))
        }
        finish()
        col.gap = 8f
    }
}

/** Günlük satırlarını gösteren cam kart. */
class LogView(private val host: Host) : Node() {
    private var lines: List<String> = emptyList()
    private var shown: List<String> = emptyList()
    private var empty = true

    /** Kayıtları yeniden okur. Ardından üst sayfa yerleşimi yenilemelidir (satır sayısı değişir). */
    fun refresh() {
        val raw = host.diagnostics().trim()
        empty = raw.isEmpty()
        lines = if (empty) listOf(Strings.LOG_EMPTY) else raw.split('\n').asReversed()   // en yeni üstte
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        if (lines.isEmpty()) refresh()
        shown = lines.map { TextFit.ellipsize(env.metrics, it, maxW - 32f, env.sz(12f), false) }
        h = shown.size * env.sz(12f) * 1.5f + 28f
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        val s = env.sz(12f)
        g.paint(env.theme.text)
        for (i in 0 until shown.size) g.text(shown[i], 16f, 14f + s + i * s * 1.5f, s, false, ALIGN_LEFT)
    }

    /** Kopyalanacak/paylaşılacak metin (en eski üstte). Kayıt yoksa boş: "Henüz kayıt yok." yer tutucusu kopyalanmaz. */
    fun text(): String = if (empty) "" else lines.asReversed().joinToString("\n")
    override fun a11y(): A11y = A11y(shown.take(8).joinToString(". "), Role.TEXT)
}

/** Eşit genişlikte yan yana düğmeler. */
class ButtonsRow(private val buttons: List<ActionButton>) : Node() {
    init { for (b in buttons) add(b) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        val gap = 10f
        val bw = (maxW - gap * (buttons.size - 1)) / buttons.size
        var cx = 0f
        for (b in buttons) { b.layout(env, bw); b.x = cx; b.y = 0f; cx += bw + gap }
        h = buttons.maxOf { it.h }
    }
}

class LogPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.LOG, true, nav) {
    private val view = LogView(model.host)
    private val note = Label(Strings.LOG_NOTE, 13f, ink = Ink.SOFT, maxLines = 0)
    private var envRef: Env? = null

    init {
        view.refresh()
        col.add(note)
        col.add(ButtonsRow(listOf(
            ActionButton(Strings.COPY, false) { model.copy(view.text()) },
            ActionButton(Strings.SHARE, false) { model.host.shareText(view.text()) },
            ActionButton(Strings.CLEAR, false) { clear() },
        )))
        col.add(view)
        finish()
    }

    override fun onLaidOut(env: Env, left: Float) { envRef = env }

    private fun clear() {
        model.host.clearDiagnostics()
        view.refresh()
        envRef?.let { relayoutContent(it) }
        model.toast(Strings.CLEARED)
    }
}
