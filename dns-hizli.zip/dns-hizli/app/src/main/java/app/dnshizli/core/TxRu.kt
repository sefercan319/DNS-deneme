package app.dnshizli.core

/** Русский. */
object TxRu : Tx() {
    override val lang = Lang.RU

    override val decimalSep = ','
    override val thousand = " тыс."
    override val million = " млн"
    override fun percent(n: Int) = "$n%"
    override val dayU = "д"
    override val hourU = "ч"
    override val minU = "мин"
    override val secU = "с"
    override val msU = "мс"
    override val justNow = "только что"
    override fun ago(span: String) = "$span назад"

    override val OFF = "Не подключено"
    override val CONNECTING = "Подключение…"
    override val ON = "Подключено"
    override val ERROR = "Не удалось подключиться"
    override val PAUSED = "Пауза"
    override val HINT_OFF = "Коснитесь сферы, чтобы подключиться"
    override val HINT_CONNECTING = "Это может занять несколько секунд"
    override val HINT_ERROR = "Коснитесь, чтобы повторить"
    override val HINT_PAUSED = "Коснитесь, чтобы продолжить сейчас"
    override val ERR_DEFAULT = "Не удалось установить соединение"
    override fun selected(name: String) = "Выбран $name"
    override fun pausedUntil(time: String) = "Продолжение в $time"
    override fun blockedShort(n: String) = "заблокировано: $n"
    override fun queriesShort(n: String) = "запросов: $n"
    override fun cacheShort(pct: String) = "кэш $pct"

    override val SERVERS = "Серверы"
    override val FILTER_ALL = "Все"
    override val FILTER_FAV = "Избранное"
    override val FILTER_RECENT = "Недавние"
    override val EMPTY_FAV = "Избранного пока нет. Коснитесь звёздочки у сервера."
    override val EMPTY_RECENT = "Вы ещё не подключались ни к одному серверу."
    override val EMPTY_FILTER = "В этой категории нет серверов."
    override val MEASURE = "Измерить скорость"
    override val MEASURING = "Измерение…"
    override val SORT = "Сортировать по скорости"
    override val PULL_TO_MEASURE = "Потяните, чтобы измерить"
    override val RELEASE_TO_MEASURE = "Отпустите для измерения"
    override fun serversCount(n: Int) = "серверов: $n"
    override val TAG_FAST = "Быстрые"
    override val TAG_PRIVACY = "Приватность"
    override val TAG_ADS = "Реклама"
    override val TAG_FAMILY = "Семья"
    override val TAG_SECURITY = "Защита"
    override val VAR_OPEN = "без фильтра"
    override val VAR_ADS = "без рекламы"
    override val VAR_SECURITY = "Защита"
    override val VAR_FAMILY = "Семья"
    override val A11Y_CONNECTED = "подключено"
    override val A11Y_ENCRYPTED = "зашифровано"
    override fun favA11y(name: String) = "$name в избранном"

    override val COPIED = "Скопировано в буфер обмена"
    override val DISCONNECTED = "Отключено"
    override val BACKUP = "Переключено на резервный сервер"
    override val NO_REPLY = "Ни один сервер не ответил"
    override val MEASURE_FIRST = "Сначала измерьте скорость"
    override val CONNECT = "Подключить"
    override val UNDO = "Отменить"
    override fun fastest(name: String, ms: Int) = "Быстрее всех: $name · $ms мс"
    override fun switched(name: String) = "Переключение на $name"
    override fun hiddenToast(name: String) = "$name скрыт"

    override val PRIMARY = "Основной"
    override val SECONDARY = "Дополнительный"
    override val COPY = "Копировать"
    override fun addressA11y(label: String, ip: String) = "$label адрес: $ip"
    override val CONNECT_TO_THIS = "Подключиться к этому серверу"
    override val SWITCH_TO_THIS = "Перейти на этот сервер"
    override val CONNECTED_NOW = "Сейчас подключено"
    override val ADD_FAV = "В избранное"
    override val REMOVE_FAV = "Убрать из избранного"
    override val MEASURE_THIS = "Измерить"
    override val HIDE = "Скрыть из списка"
    override val UNHIDE = "Показать в списке"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Последний замер: нет ответа · $ago" else "Последний замер: $ms мс · $ago"
    override val NEVER_MEASURED = "Ещё не измерялся"
    override val ENC_SUPPORT = "Шифрованный DNS"
    override val ENC_NONE = "Не поддерживается"
    override val ENC_ONLY = "Принимает только шифрованные подключения"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Лучший $best мс · медиана $median мс · потери $lossPct%"
    override val HISTORY = "История замеров"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: замеров $n, нет ответа" else "$HISTORY: замеров $n, медиана $median мс"

    override val QUICK_TITLE = "Быстрый выбор"
    override val QUICK_FAVORITES = "Избранное"
    override val QUICK_RECENT = "Недавние"
    override val PAUSE_FOR = "Пауза"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} ч" else "$n мин"
    override val RESUME = "Продолжить"

    override val SETTINGS = "Настройки"
    override val SEC_LOOK = "Внешний вид"
    override val SEC_CONNECTION = "Подключение"
    override val SEC_PRIVACY = "Приватность и защита"
    override val SEC_LIST = "Список серверов"
    override val SEC_INFO = "Статистика"
    override val SEC_DATA = "Данные"
    override val SEC_ABOUT = "О приложении"
    override val LANGUAGE = "Язык"
    override val LANG_AUTO = "Автоматически (язык системы)"
    override val THEME = "Тема"
    override val THEME_AUTO = "Авто"
    override val THEME_AUTO_NOTE = "Авто · по светлой/тёмной теме системы"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Аква"
        "meadow" -> "Луг"
        "ocean" -> "Океан"
        "sunset" -> "Закат"
        "lavender" -> "Лаванда"
        "coral" -> "Коралл"
        "mint" -> "Мята"
        "night" -> "Ночь"
        "amoled" -> "Чёрная (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Тема: $name"
    override val THEME_SCHEDULE = "Ночная тема по расписанию"
    override val THEME_SCHEDULE_NOTE = "В режиме Авто «Ночь» с 22:00 до 07:00"
    override val GLASS = "Прозрачность стекла"
    override val BUBBLES = "Пузырьки"
    override val MOTION = "Анимации"
    override val TEXT_SIZE = "Размер текста"
    override val HIGH_CONTRAST = "Высокий контраст"
    override val HIGH_CONTRAST_NOTE = "Более плотное стекло и тёмный текст"
    override val MINIMAL = "Простой вид"
    override val MINIMAL_NOTE = "Скрывает фильтры и строку статистики"
    override val LOW_POWER = "Энергосбережение"
    override val LOW_POWER_NOTE = "Отключает всю анимацию, бережёт батарею"
    override val HAPTICS = "Вибрация"
    override val HAPTICS_NOTE = "Лёгкий отклик при касании"
    override val ENCRYPTION = "Шифрованный DNS"
    override val ENCRYPTION_NOTE = "Авто: сначала DoT, затем DoH, в конце обычный DNS"
    override val AUTO_CONNECT = "Подключаться при запуске"
    override val AUTO_CONNECT_NOTE = "При открытии приложения подключается к последнему серверу"
    override val CONNECT_ON_BOOT = "Подключаться при включении"
    override val CONNECT_ON_BOOT_NOTE = "Подключается сам после перезагрузки телефона"
    override val AUTO_FASTEST = "К самому быстрому"
    override val AUTO_FASTEST_NOTE = "Сфера выбирает самый быстрый сервер по последнему замеру"
    override val REFRESH_ON_NET = "Обновлять при смене сети"
    override val REFRESH_ON_NET_NOTE = "DNS обновляется при переходе между Wi-Fi и мобильной сетью"
    override val NOTIFY_DROP = "Сообщать о разрыве"
    override val NOTIFY_DROP_NOTE = "Уведомление с кнопкой переподключения при обрыве"
    override val CACHE = "Кэш DNS"
    override val CLEAR_CACHE = "Очистить кэш"
    override val CACHE_CLEARED = "Кэш очищен"
    override val ONLY_CONNECTED = "Доступно при подключении"
    override val RULE_WIFI = "Сервер для Wi-Fi"
    override val RULE_MOBILE = "Сервер для мобильной сети"
    override val RULE_AUTO = "Авто"
    override val RULE_AUTO_NOTE = "Последний использованный сервер"
    override val COMPACT = "Компактный список"
    override val COMPACT_NOTE = "Короткие строки без описания"
    override val HIDDEN = "Скрытые серверы"
    override val HIDDEN_NONE = "Нет"
    override val STAT_QUERIES = "Всего запросов"
    override val STAT_HITS = "Ответов из кэша"
    override val STAT_BLOCKED = "Заблокировано (оценка)"
    override val STAT_TIME = "Всего подключено"
    override val WEEK = "Последние 7 дней"
    override fun weekA11y(total: String) = "Запросов за 7 дней: $total"
    override val WEEKDAYS = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    override val EXPORT = "Экспорт настроек"
    override val IMPORT = "Импорт настроек"
    override val EXPORTED = "Код настроек скопирован"
    override val IMPORTED = "Настройки загружены"
    override val IMPORT_BAD = "В буфере обмена нет корректного кода настроек"
    override val RESET_SETTINGS = "Сбросить настройки"
    override val RESET_STATS = "Сбросить статистику"
    override val CONFIRM = "Вы уверены?"
    override val RESET = "Сбросить"
    override val RESET_DONE = "Сброшено"
    override val LOG = "Журнал диагностики"
    override val HELP = "Как это работает?"
    override val VPN_SETTINGS = "Настройки VPN системы"
    override val SHARE_APP = "Поделиться приложением"
    override val RATE_APP = "Оценить приложение"
    override val FEEDBACK = "Отправить отзыв"
    override fun shareAppText(url: String) = "$APP подключает к популярным DNS одним касанием: $url"
    override val VERSION = "Версия"
    override val OPT_BUBBLES = listOf("Нет", "Мало", "Много")
    override val OPT_MOTION = listOf("Все", "Меньше", "Нет")
    override val OPT_CACHE = listOf("Нет", "Малый", "Обычный", "Большой")
    override val OPT_ENCRYPTION = listOf("Авто", "DoT", "DoH", "Нет")
    override val PLAIN_DNS = "Обычный DNS"

    override val LOG_NOTE = "Хранятся только события подключения. Имена запросов и личные данные не записываются."
    override val LOG_EMPTY = "Записей пока нет."
    override val SHARE = "Поделиться"
    override val CLEAR = "Очистить"
    override val CLEARED = "Очищено"
    override val HELP_SECTIONS = listOf(
        "Что такое DNS?" to
            "DNS — это служба, которая превращает интернет-адреса (например, example.com) в числа, понятные устройствам. " +
            "От выбранного DNS зависят скорость, приватность и то, что будет заблокировано.",
        "Что делает приложение?" to
            "Оно использует выбранный DNS-сервер во всех приложениях. Для этого на телефоне открывается локальный VPN-интерфейс, " +
            "но ваш трафик не идёт на VPN-сервер. На выбранный сервер отправляются только DNS-запросы, " +
            "всё остальное идёт обычным путём.",
        "Шифрованный DNS (DoT / DoH)" to
            "На серверах с поддержкой запросы передаются зашифрованными: никто в сети (владелец Wi-Fi, оператор) не видит, " +
            "какие сайты вы открываете, и не может подменить ответы. В режиме «Авто» сначала пробуется DoT, затем DoH; " +
            "если не работает ни один, используется обычный DNS. Вас об этом предупредят, а приложение будет пытаться вернуться к шифрованию " +
            "при каждой смене сети и каждые 10 минут. При включённом «Строгом шифровании» обычный DNS не используется никогда. " +
            "Главный экран показывает, какой способ сейчас используется.",
        "Проверка подключения" to
            "Настройки > Приватность и защита > Проверка подключения отправляет настоящие DNS-запросы через туннель. Она показывает, что " +
            "DNS действительно отвечает с выбранного сервера, как быстро, проверяет ли сервер подписи DNSSEC " +
            "и блокирует ли известный рекламный домен.",
        "Приватность" to
            "Без аккаунта, без сбора данных, без рекламы. Приложение не хранит имена запросов и ничего не отправляет само. " +
            "Ваши запросы идут только выбранному DNS-провайдеру, по его политике конфиденциальности. " +
            "В журнале диагностики только события подключения.",
        "Батарея и ресурсы" to
            "В фоне расходует очень мало. При выключенном экране ничего не крутится в цикле; " +
            "работа идёт только при поступлении DNS-запроса. Шифрованные соединения закрываются сами при простое.",
        "Полезно знать" to
            "Android разрешает только один VPN одновременно; при активном другом VPN это приложение не подключится. " +
            "«Безопасный DNS» в браузерах и «Частный DNS» Android с указанным именем используют свой сервер " +
            "и могут обходить это перенаправление; достаточно оставить их в режиме «Автоматически» или «Отключено». " +
            "Долгое нажатие на сферу: быстрый выбор сервера или пауза подключения.",
    )

    override val NOTIF_CHANNEL = "Состояние подключения"
    override val NOTIF_CHANNEL_NOTE = "Показывается, пока DNS-подключение активно"
    override val NOTIF_ALERT_CHANNEL = "Предупреждения о подключении"
    override val NOTIF_CONNECTING = "Подключение…"
    override val NOTIF_STOP = "Отключить"
    override val NOTIF_NEXT = "Следующий"
    override val NOTIF_DROP_TITLE = "DNS-подключение прервано"
    override val NOTIF_RECONNECT = "Переподключить"
    override fun notifOn(name: String, proto: String) = "Подключено к $name · $proto"
    override fun notifPaused(time: String) = "Пауза · продолжение в $time"
    override val TILE_ON = "Подключено"
    override val TILE_OFF = "Выкл."
    override val WIDGET_TAP = "Касание: подключить / отключить"
    override val ERR_PERMISSION = "Разрешение VPN не выдано"
    override val ERR_ESTABLISH = "Не удалось открыть VPN-интерфейс. Возможно, активен другой VPN."
    override fun errNoReply(name: String) = "$name не ответил"
    override fun errNoProto(name: String, proto: String) = "$name не поддерживает $proto"
    override val ERR_SOCKET = "Сеть недоступна"
    override fun errPrivateDns(host: String) = "Частный DNS Android закреплён за $host и обходит приложение. Установите Настройки > Сеть > Частный DNS: Автоматически или Отключено."
    override val ERR_REVOKED = "Подключение закрыто системой"
    override val ERR_TUNNEL = "Туннель неожиданно закрылся"
    override val ERR_UNKNOWN = "Произошла непредвиденная ошибка"

    override val CONSENT_TITLE = "Перед подключением"
    override val CONSENT_BODY = listOf(
        "$APP использует VPN-интерфейс Android, чтобы направлять ваши DNS-запросы (имена посещаемых сайтов) на выбранный DNS-сервер.",
        "Ваш трафик не отправляется на VPN-сервер; к выбранному провайдеру идут только DNS-запросы. На серверах с поддержкой " +
            "они шифруются (DoT/DoH), на остальных передаются без шифрования. Действует политика конфиденциальности провайдера.",
        "Приложение не собирает личные данные, не хранит имена запросов и ничего никому не передаёт.",
        "Если продолжить, Android покажет запрос на VPN-подключение; нужно нажать «ОК».",
    )
    override val CONSENT_OK = "Понятно, продолжить"
    override val CLOSE = "Закрыть"
    override val BACK = "Назад"

    // ---- 3. sürüm ----
    override val RESUMING = "Возобновление…"
    override val DOWNGRADED = "Шифрование не удалось, обычный DNS"
    override val UPGRADED = "Снова шифрованный DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS не зашифрован"
    override fun notifDowngrade(name: String) = "Не удалось установить шифрованное подключение к $name. Используется обычный DNS; приложение попробует вернуться к шифрованию."
    override fun backupUsed(failed: String, used: String) = "$failed не ответил, подключено к $used"
    override val NOTIF_RETRYING = "Подключение прервано, повтор…"
    override fun errNoEncrypted(name: String) = "Не удалось установить шифрованное подключение к $name"
    override val APPLYING = "Новая настройка применяется к подключению"
    override val CONFIRM_DISCONNECT = "Отключиться?"
    override val DISCONNECT = "Отключить"

    override val SEC_NOTIF = "Уведомления"
    override val STRICT_ENC = "Строгое шифрование"
    override val STRICT_ENC_NOTE = "Никогда не переходить на обычный DNS"
    override val AUTO_RECONNECT = "Автопереподключение"
    override val AUTO_RECONNECT_NOTE = "При разрыве повтор через 5 с, 30 с и 2 мин"
    override val BACKUP_SERVER = "Резервный сервер"
    override val BACKUP_OFF = "Нет"
    override val BACKUP_OFF_NOTE = "Не подключаться, если выбранный сервер не отвечает"
    override val BACKUP_FASTEST = "Самый быстрый"
    override val BACKUP_FASTEST_NOTE = "Самый быстрый из других серверов по последнему замеру"
    override val CONFIRM_OFF = "Спрашивать перед отключением"
    override val CONFIRM_OFF_NOTE = "Случайное касание сферы не отключит"
    override val LOCK_HIDE = "Скрыть на экране блокировки"
    override val LOCK_HIDE_NOTE = "Имя сервера не видно в уведомлении на экране блокировки"
    override val QUIET_NOTIF = "Тихое уведомление"
    override val QUIET_NOTIF_NOTE = "Без значка в строке состояния, без звука"
    override val REMEMBER_FILTER = "Запоминать фильтр"
    override val REMEMBER_FILTER_NOTE = "При открытии приложения вернётся последний выбранный фильтр"
    override val AUTO_MEASURE = "Замер при запуске"
    override val AUTO_MEASURE_NOTE = "Измеряет сам, если последнему замеру больше суток"
    override val MEASURE_ENC = "Шифрованный замер"
    override val MEASURE_ENC_NOTE = "Измеряет скорость через DoT, ближе к реальной работе с шифрованием"
    override val OPT_SORT = listOf("Обычный", "Скорость", "Название")
    override fun sortA11y(mode: String) = "Сортировка: $mode"
    override val AUTO_LIGHT = "Авто: светлая тема"
    override val AUTO_DARK = "Авто: тёмная тема"
    override val NIGHT_HOURS = "Ночные часы"
    override val FILTER_ENCRYPTED = "Шифрованные"
    override val FILTER_UNFILTERED = "Без фильтра"

    override val TEST = "Проверить подключение"
    override val TEST_NOTE = "DNS, DNSSEC и блокировка рекламы"
    override val TESTING = "Проверка…"
    override val TEST_TITLE = "Проверка подключения"
    override val TEST_OK = "DNS работает"
    override val TEST_FAIL = "Нет ответа"
    override val TEST_SERVER = "Сервер"
    override val TEST_METHOD = "Способ"
    override val TEST_LATENCY = "Время ответа"
    override val TEST_DNSSEC = "Проверка DNSSEC"
    override val TEST_ADS = "Блокировка рекламы"
    override val DNSSEC_YES = "Проверяет"
    override val DNSSEC_NO = "Не проверяет"
    override val ADS_YES = "Вкл."
    override val ADS_NO = "Выкл."
    override val UNKNOWN = "Неизвестно"
    override val TEST_EXPLAIN = "Запросы отправлены через туннель так же, как их отправило бы приложение; ответы пришли от выбранного сервера."
    override val TEST_AGAIN = "Проверить снова"

    override val RECOMMEND = "Подобрать сервер"
    override val RECOMMEND_NOTE = "Выберите цель, и мы подключим самый быстрый подходящий"
    override val GOAL_SPEED = "Скорость"
    override val GOAL_SPEED_NOTE = "Самый быстрый сервер по вашим замерам"
    override val GOAL_PRIVACY_NOTE = "Без журналов, упор на приватность"
    override val GOAL_ADS_NOTE = "Блокирует рекламу и трекеры"
    override val GOAL_FAMILY_NOTE = "Блокирует контент для взрослых"
    override val GOAL_SECURITY_NOTE = "Блокирует вредоносные и фишинговые сайты"
    override fun recommended(name: String) = "Рекомендуем: $name"

    override val PRIVATE_DNS = "Имя для частного DNS"
    override val PRIVATE_DNS_NOTE = "Его можно вставить в настройку «Частный DNS» Android. Тогда система будет использовать этот сервер напрямую, в обход приложения."
    override val CLEAR_HISTORY = "Очистить историю замеров"
    override val HISTORY_CLEARED = "Замеры очищены"

    override val GUARD = "Постоянная защита"
    override val GUARD_NOTE = "Постоянная VPN"
    override val GUARD_BODY = listOf(
        "Пока приложение не подключено (выключено, на паузе или после разрыва), ваши DNS-запросы идут на сервер интернет-провайдера.",
        "Чтобы этого избежать, включите для этого приложения «Постоянная VPN» в настройках VPN Android. Если также включено «Блокировать соединения без VPN», интернет совсем не будет работать, пока приложение не подключено: утечек нет, но пауза тоже означает отсутствие интернета.",
        "С постоянной VPN система сама запускает приложение при включении телефона и после его остановки.",
    )
    override val GUARD_BUTTON = "Открыть настройки VPN"
    override val BATTERY = "Настройки батареи"
    override val BATTERY_OK = "Без ограничений"
    override val BATTERY_LIMITED = "Может ограничиваться"
    override val BATTERY_BODY = listOf(
        "Android обычно защищает VPN-приложения. Но некоторые производители (Xiaomi, Huawei, Oppo, Vivo, некоторые версии Samsung) могут закрывать фоновые приложения ради экономии батареи.",
        "Если подключение само обрывается, установите для этого приложения расход батареи «Без ограничений» или «Не оптимизировать»; на некоторых телефонах также разрешите «Автозапуск».",
    )
    override val BATTERY_BUTTON = "Открыть настройки батареи"

    override val STAT_AVG = "Среднее время ответа"
    override val STAT_SAVED = "Время, сэкономленное кэшем"
    override val STAT_TRAFFIC = "DNS-трафик"
    override val SESSIONS = "История подключений"
    override val SESSIONS_NOTE = "Последние 30 подключений; имена запросов не хранятся"
    override val SESSIONS_EMPTY = "Подключений пока не записано."
    override val MOST_USED = "Чаще всего"
    override val TODAY = "Сегодня"
    override val YESTERDAY = "Вчера"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Вы отключили"
        EndReason.PAUSE -> "Пауза"
        EndReason.SWITCH -> "Смена сервера"
        EndReason.DROP -> "Разрыв"
        EndReason.REVOKED -> "Закрыто системой"
        EndReason.FAILED -> "Нет ответа"
        EndReason.NETWORK -> "Смена сети"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · запросов: $queries"

    override val WHATS_NEW = "Что нового?"
    override val WHATS_NEW_TOAST = "Приложение обновлено"
    override val SHOW = "Показать"
    override val WHATS_NEW_ITEMS = listOf(
        "Более надёжное подключение: дополнительные проверки против поддельных ответов DNS, предупреждение при переходе на обычный DNS, строгое шифрование и автоматический возврат к шифрованию.",
        "Проверка подключения: одним касанием убедитесь, что DNS отвечает от выбранного сервера, а также проверьте DNSSEC и блокировку рекламы.",
        "Резервный сервер и автопереподключение: приложение само восстанавливается, если выбранный сервер не отвечает или подключение обрывается.",
        "История подключений, самые используемые серверы, среднее время ответа и DNS-трафик.",
        "Новые фильтры («Шифрованные», «Без фильтра»), сортировка по названию, «Подобрать сервер» и замер при запуске.",
        "Живые счётчики в уведомлении, кнопка паузы на 15 минут, скрытие на экране блокировки и тихое уведомление.",
        "Три новые темы («Сакура», «Мёд», «Северное сияние»), тема по цвету обоев и выбор светлой/тёмной темы для режима Авто.",
        "Четыре новых языка: индонезийский, вьетнамский, польский и украинский.",
    )
    override fun importedWith(changes: String) = "Настройки загружены · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "шифрование ослаблено"
        SensitiveChange.AUTO_START -> "включено автоподключение"
        SensitiveChange.RULES -> "изменены правила серверов"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · запросов: $queries · заблокировано: $blocked"
    override val NOTIF_LOCKED = "Защита DNS включена"
    override val NOTIF_QUIET_CHANNEL = "Состояние подключения (тихое)"
    override fun widgetToday(queries: String) = "Сегодня запросов: $queries"
    override fun pauseAction(minutes: Int) = "Пауза ${minutes(minutes)}"


    override val NOTES = mapOf(
        "cloudflare" to "Быстрый, бережёт приватность",
        "google" to "Стабильный, популярный",
        "quad9" to "Блокирует вредоносные домены",
        "adguard" to "Блокирует рекламу и трекеры",
        "controld" to "Без фильтров, быстрый",
        "opendns" to "Cisco, защита от фишинга",
        "mullvad" to "Без логов, только шифрование",
        "dnssb" to "Бережёт приватность, быстрый",
        "dns4eu" to "DNS Евросоюза, от вредоносов",
        "uncensored" to "Без фильтров и перенаправлений",
        "quad9-open" to "Ничего не блокирует",
        "adguard-open" to "Без блокировок, бережёт приватность",
        "dns4eu-open" to "DNS Евросоюза, без фильтра",
        "controld-ads" to "Реклама, трекеры, вредоносы",
        "mullvad-ads" to "Реклама и трекеры, только шифрование",
        "dns4eu-ads" to "DNS Евросоюза, реклама и вредоносы",
        "cloudflare-security" to "Блокирует вредоносные сайты",
        "controld-malware" to "Блокирует вредоносные сайты",
        "cleanbrowsing-security" to "Фишинг и вредоносные сайты",
        "cloudflare-family" to "Фильтр вредоносов и 18+",
        "opendns-family" to "Фильтр контента 18+",
        "adguard-family" to "Фильтр рекламы и 18+",
        "cleanbrowsing-family" to "Контент 18+, безопасный поиск",
        "dns4eu-child" to "DNS Евросоюза, защита детей",
        "mullvad-family" to "Семейный фильтр, только шифрование",
        "controld-family" to "Фильтр контента 18+",
    )
}
