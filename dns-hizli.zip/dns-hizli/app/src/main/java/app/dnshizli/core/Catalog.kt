package app.dnshizli.core

enum class Tag(val id: String, val label: String) {
    FAST("fast", "Hızlı"),
    PRIVACY("privacy", "Gizlilik"),
    ADS("ads", "Reklam"),
    FAMILY("family", "Aile"),
    SECURITY("security", "Güvenlik");

    companion object {
        fun byId(id: String?): Tag? = values().firstOrNull { it.id == id }
    }
}

class DnsServer(
    val id: String,
    val name: String,
    val note: String,
    val primary: String,
    val secondary: String?,
    val tags: Set<Tag>,
) {
    val addresses: List<String> get() = listOfNotNull(primary, secondary)
}

/**
 * Uygulamanın bilinen, herkese açık DNS sunucuları. Her sunucu tek satırdır:
 * `tools/catalog_check.py` bu satırları okuyup gerçek sunuculara sorgu atarak adresleri doğrular.
 */
object Catalog {
    const val DEFAULT_ID = "cloudflare"

    private fun s(id: String, name: String, note: String, primary: String, secondary: String?, vararg tags: Tag) =
        DnsServer(id, name, note, primary, secondary, tags.toSet())

    val all: List<DnsServer> = listOf(
        s("cloudflare", "Cloudflare", "Hızlı, gizlilik odaklı", "1.1.1.1", "1.0.0.1", Tag.FAST, Tag.PRIVACY),
        s("google", "Google", "Kararlı, yaygın", "8.8.8.8", "8.8.4.4", Tag.FAST),
        s("quad9", "Quad9", "Zararlı alan adlarını engeller", "9.9.9.9", "149.112.112.112", Tag.SECURITY, Tag.PRIVACY),
        s("adguard", "AdGuard", "Reklam ve takipçi engeller", "94.140.14.14", "94.140.15.15", Tag.ADS, Tag.PRIVACY),
        s("controld", "Control D", "Filtresiz, hızlı", "76.76.2.0", "76.76.10.0", Tag.FAST, Tag.PRIVACY),
        s("opendns", "OpenDNS", "Cisco, kararlı", "208.67.222.222", "208.67.220.220", Tag.SECURITY),
        s("mullvad", "Mullvad", "Kayıt tutmaz, gizlilik odaklı", "194.242.2.2", null, Tag.PRIVACY),
        s("dnssb", "DNS.SB", "Gizlilik odaklı, hızlı", "185.222.222.222", "45.11.45.11", Tag.PRIVACY, Tag.FAST),
        s("verisign", "Verisign", "Veri satmaz, yönlendirme yapmaz", "64.6.64.6", "64.6.65.6", Tag.PRIVACY),
        s("uncensored", "UncensoredDNS", "Filtre ve yönlendirme yok", "91.239.100.100", "89.233.43.71", Tag.PRIVACY),
        s("quad9-open", "Quad9 Filtresiz", "Engelleme yapmaz", "9.9.9.10", "149.112.112.10", Tag.PRIVACY),
        s("adguard-open", "AdGuard Filtresiz", "Engelleme yok, gizlilik odaklı", "94.140.14.140", "94.140.14.141", Tag.PRIVACY),
        s("controld-ads", "Control D Reklam", "Reklam, takipçi, zararlı site", "76.76.2.2", "76.76.10.2", Tag.ADS, Tag.SECURITY),
        s("mullvad-ads", "Mullvad Reklam", "Reklam ve takipçi engeller", "194.242.2.3", null, Tag.ADS, Tag.PRIVACY),
        s("alternate", "Alternate DNS", "Reklam engeller", "76.76.19.19", "76.223.122.150", Tag.ADS),
        s("cloudflare-security", "Cloudflare Güvenlik", "Zararlı siteleri engeller", "1.1.1.2", "1.0.0.2", Tag.SECURITY),
        s("cloudflare-family", "Cloudflare Aile", "Zararlı ve yetişkin içerik filtresi", "1.1.1.3", "1.0.0.3", Tag.FAMILY, Tag.SECURITY),
        s("opendns-family", "OpenDNS Aile", "Yetişkin içerik filtresi", "208.67.222.123", "208.67.220.123", Tag.FAMILY),
        s("adguard-family", "AdGuard Aile", "Reklam ve yetişkin içerik filtresi", "94.140.14.15", "94.140.15.16", Tag.FAMILY, Tag.ADS),
        s("cleanbrowsing-security", "CleanBrowsing Güvenlik", "Oltalama ve zararlı siteler", "185.228.168.9", "185.228.169.9", Tag.SECURITY),
        s("cleanbrowsing-family", "CleanBrowsing Aile", "Yetişkin içerik, güvenli arama", "185.228.168.168", "185.228.169.168", Tag.FAMILY),
    )

    val default: DnsServer get() = byId(DEFAULT_ID)!!

    fun byId(id: String?): DnsServer? = if (id == null) null else all.firstOrNull { it.id == id }

    /** "a.b.c.d" biçiminde, her parçası 0..255 olan geçerli bir IPv4 adresi mi? */
    fun isIpv4(s: String): Boolean {
        val parts = s.split('.')
        if (parts.size != 4) return false
        return parts.all { p -> p.isNotEmpty() && p.length <= 3 && p.all { it in '0'..'9' } && p.toInt() in 0..255 }
    }
}
