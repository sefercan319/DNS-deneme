package app.dnshizli.core

/** Deutsch. */
object TxDe : Tx() {
    override val lang = Lang.DE

    override val decimalSep = ','
    override val thousand = " Tsd."
    override val million = " Mio."
    override fun percent(n: Int) = "$n %"
    override val dayU = "T."
    override val hourU = "Std."
    override val minU = "Min."
    override val secU = "s"
    override val justNow = "gerade eben"
    override fun ago(span: String) = "vor $span"

    override val OFF = "Nicht verbunden"
    override val CONNECTING = "Verbinde…"
    override val ON = "Verbunden"
    override val ERROR = "Keine Verbindung"
    override val PAUSED = "Pausiert"
    override val HINT_OFF = "Zum Verbinden auf die Kugel tippen"
    override val HINT_CONNECTING = "Das kann einige Sekunden dauern"
    override val HINT_ERROR = "Zum erneuten Versuch tippen"
    override val HINT_PAUSED = "Tippen, um sofort fortzusetzen"
    override val ERR_DEFAULT = "Verbindung fehlgeschlagen"
    override fun selected(name: String) = "$name ausgewählt"
    override fun pausedUntil(time: String) = "Weiter um $time"
    override fun blockedShort(n: String) = "$n blockiert"
    override fun queriesShort(n: String) = "$n Anfragen"
    override fun cacheShort(pct: String) = "$pct Cache"

    override val SERVERS = "Server"
    override val FILTER_ALL = "Alle"
    override val FILTER_FAV = "Favoriten"
    override val FILTER_RECENT = "Zuletzt"
    override val EMPTY_FAV = "Noch keine Favoriten. Tippe auf den Stern eines Servers."
    override val EMPTY_RECENT = "Du hast dich noch mit keinem Server verbunden."
    override val EMPTY_FILTER = "In dieser Kategorie gibt es keine Server."
    override val MEASURE = "Geschwindigkeit messen"
    override val MEASURING = "Messe…"
    override val SORT = "Nach Tempo sortieren"
    override val PULL_TO_MEASURE = "Zum Messen ziehen"
    override val RELEASE_TO_MEASURE = "Loslassen zum Messen"
    override fun serversCount(n: Int) = "$n Server"
    override val TAG_FAST = "Schnell"
    override val TAG_PRIVACY = "Privatsphäre"
    override val TAG_ADS = "Werbung"
    override val TAG_FAMILY = "Familie"
    override val TAG_SECURITY = "Sicherheit"
    override val VAR_OPEN = "Ungefiltert"
    override val VAR_ADS = "Werbefilter"
    override val VAR_SECURITY = "Sicherheit"
    override val VAR_FAMILY = "Familie"
    override val A11Y_CONNECTED = "verbunden"
    override val A11Y_ENCRYPTED = "verschlüsselt"
    override fun favA11y(name: String) = "$name Favorit"

    override val COPIED = "In die Zwischenablage kopiert"
    override val DISCONNECTED = "Verbindung getrennt"
    override val BACKUP = "Auf Ersatzserver gewechselt"
    override val NO_REPLY = "Kein Server hat geantwortet"
    override val MEASURE_FIRST = "Zuerst Geschwindigkeit messen"
    override val CONNECT = "Verbinden"
    override val UNDO = "Rückgängig"
    override fun fastest(name: String, ms: Int) = "Am schnellsten: $name · $ms ms"
    override fun switched(name: String) = "Wechsle zu $name"
    override fun hiddenToast(name: String) = "$name ausgeblendet"

    override val PRIMARY = "Primär"
    override val SECONDARY = "Sekundär"
    override val COPY = "Kopieren"
    override fun addressA11y(label: String, ip: String) = "$label Adresse: $ip"
    override val CONNECT_TO_THIS = "Mit diesem Server verbinden"
    override val SWITCH_TO_THIS = "Zu diesem Server wechseln"
    override val CONNECTED_NOW = "Jetzt verbunden"
    override val ADD_FAV = "Zu Favoriten"
    override val REMOVE_FAV = "Favorit entfernen"
    override val MEASURE_THIS = "Tempo messen"
    override val HIDE = "In Liste ausblenden"
    override val UNHIDE = "In Liste zeigen"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Letzte Messung: keine Antwort · $ago" else "Letzte Messung: $ms ms · $ago"
    override val NEVER_MEASURED = "Noch nicht gemessen"
    override val ENC_SUPPORT = "Verschlüsseltes DNS"
    override val ENC_NONE = "Nicht unterstützt"
    override val ENC_ONLY = "Nimmt nur verschlüsselte Verbindungen an"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Bestwert $best ms · Median $median ms · Verlust $lossPct %"
    override val HISTORY = "Messverlauf"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n Messungen, keine Antwort" else "$HISTORY: $n Messungen, Median $median ms"

    override val QUICK_TITLE = "Schnellwahl"
    override val QUICK_FAVORITES = "Favoriten"
    override val QUICK_RECENT = "Zuletzt verwendet"
    override val PAUSE_FOR = "Pausieren"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} Std." else "$n Min."
    override val RESUME = "Fortsetzen"

    override val SETTINGS = "Einstellungen"
    override val SEC_LOOK = "Darstellung"
    override val SEC_CONNECTION = "Verbindung"
    override val SEC_PRIVACY = "Datenschutz & Sicherheit"
    override val SEC_LIST = "Serverliste"
    override val SEC_INFO = "Statistik"
    override val SEC_DATA = "Daten"
    override val SEC_ABOUT = "Über"
    override val LANGUAGE = "Sprache"
    override val LANG_AUTO = "Automatisch (Systemsprache)"
    override val THEME = "Design"
    override val THEME_AUTO = "Automatisch"
    override val THEME_AUTO_NOTE = "Automatisch · folgt hell/dunkel des Systems"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Wiese"
        "ocean" -> "Ozean"
        "sunset" -> "Abendrot"
        "lavender" -> "Lavendel"
        "coral" -> "Koralle"
        "mint" -> "Minze"
        "night" -> "Nacht"
        "amoled" -> "Schwarz (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Design: $name"
    override val THEME_SCHEDULE = "Nachtdesign nach Uhrzeit"
    override val THEME_SCHEDULE_NOTE = "Bei Automatisch Nacht von 22:00 bis 07:00"
    override val GLASS = "Glasdeckkraft"
    override val BUBBLES = "Blasen"
    override val MOTION = "Animationen"
    override val TEXT_SIZE = "Schriftgröße"
    override val HIGH_CONTRAST = "Hoher Kontrast"
    override val HIGH_CONTRAST_NOTE = "Deckenderes Glas und dunklere Schrift"
    override val MINIMAL = "Schlichte Ansicht"
    override val MINIMAL_NOTE = "Blendet Filter und Statistikzeile aus"
    override val LOW_POWER = "Energiesparmodus"
    override val LOW_POWER_NOTE = "Schaltet alle Bewegungen ab, schont den Akku"
    override val HAPTICS = "Vibration"
    override val HAPTICS_NOTE = "Leichtes Feedback beim Tippen"
    override val ENCRYPTION = "Verschlüsseltes DNS"
    override val ENCRYPTION_NOTE = "Auto: erst DoT, dann DoH, zuletzt einfaches DNS"
    override val AUTO_CONNECT = "Beim App-Start verbinden"
    override val AUTO_CONNECT_NOTE = "Verbindet beim Öffnen mit dem letzten Server"
    override val CONNECT_ON_BOOT = "Beim Gerätestart verbinden"
    override val CONNECT_ON_BOOT_NOTE = "Verbindet nach einem Neustart automatisch"
    override val AUTO_FASTEST = "Mit dem schnellsten verbinden"
    override val AUTO_FASTEST_NOTE = "Die Kugel wählt den schnellsten Server der letzten Messung"
    override val REFRESH_ON_NET = "Bei Netzwechsel erneuern"
    override val REFRESH_ON_NET_NOTE = "DNS wird beim Wechsel zwischen WLAN und Mobilfunk erneuert"
    override val NOTIFY_DROP = "Bei Abbruch benachrichtigen"
    override val NOTIFY_DROP_NOTE = "Hinweis mit Taste zum Neuverbinden bei unerwartetem Abbruch"
    override val CACHE = "DNS-Cache"
    override val CLEAR_CACHE = "Cache leeren"
    override val CACHE_CLEARED = "Cache geleert"
    override val ONLY_CONNECTED = "Nur bei aktiver Verbindung"
    override val RULE_WIFI = "WLAN-Server"
    override val RULE_MOBILE = "Mobilfunk-Server"
    override val RULE_AUTO = "Automatisch"
    override val RULE_AUTO_NOTE = "Zuletzt verwendeter Server"
    override val COMPACT = "Kompakte Liste"
    override val COMPACT_NOTE = "Kürzere Zeilen ohne Beschreibung"
    override val HIDDEN = "Ausgeblendete Server"
    override val HIDDEN_NONE = "Keine"
    override val STAT_QUERIES = "Anfragen gesamt"
    override val STAT_HITS = "Aus dem Cache"
    override val STAT_BLOCKED = "Blockiert (geschätzt)"
    override val STAT_TIME = "Verbunden insgesamt"
    override val WEEK = "Letzte 7 Tage"
    override fun weekA11y(total: String) = "$total Anfragen in den letzten 7 Tagen"
    override val WEEKDAYS = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
    override val EXPORT = "Einstellungen exportieren"
    override val IMPORT = "Einstellungen importieren"
    override val EXPORTED = "Einstellungscode kopiert"
    override val IMPORTED = "Einstellungen geladen"
    override val IMPORT_BAD = "Kein gültiger Einstellungscode in der Zwischenablage"
    override val RESET_SETTINGS = "Einstellungen zurücksetzen"
    override val RESET_STATS = "Statistik zurücksetzen"
    override val CONFIRM = "Bist du sicher?"
    override val RESET = "Zurücksetzen"
    override val RESET_DONE = "Zurückgesetzt"
    override val LOG = "Diagnoseprotokoll"
    override val HELP = "Wie funktioniert es?"
    override val VPN_SETTINGS = "System-VPN-Einstellungen"
    override val SHARE_APP = "App teilen"
    override val RATE_APP = "App bewerten"
    override val FEEDBACK = "Feedback senden"
    override fun shareAppText(url: String) = "$APP verbindet dich mit einem Tipp mit bekannten DNS-Servern: $url"
    override val VERSION = "Version"
    override val OPT_BUBBLES = listOf("Aus", "Wenige", "Viele")
    override val OPT_MOTION = listOf("Voll", "Wenig", "Aus")
    override val OPT_CACHE = listOf("Aus", "Klein", "Normal", "Groß")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Aus")
    override val PLAIN_DNS = "Einfaches DNS"

    override val LOG_NOTE = "Nur Verbindungsereignisse werden gespeichert. Anfragenamen und persönliche Daten nie."
    override val LOG_EMPTY = "Noch keine Einträge."
    override val SHARE = "Teilen"
    override val CLEAR = "Leeren"
    override val CLEARED = "Geleert"
    override val HELP_SECTIONS = listOf(
        "Was ist DNS?" to
            "DNS ist der Dienst, der Internetadressen (zum Beispiel example.com) in Zahlen übersetzt, die Geräte verstehen. " +
            "Der verwendete DNS kann Tempo, Privatsphäre und blockierte Inhalte beeinflussen.",
        "Was macht die App?" to
            "Sie nutzt den gewählten DNS-Server in allen Apps. Dafür öffnet sie auf dem Telefon eine lokale VPN-Schnittstelle, " +
            "dein Datenverkehr geht aber an keinen VPN-Server. Nur DNS-Anfragen werden an den gewählten Server geleitet, " +
            "alles andere nimmt seinen normalen Weg.",
        "Verschlüsseltes DNS (DoT / DoH)" to
            "Bei Servern, die es unterstützen, werden Anfragen verschlüsselt: Niemand im Netz (WLAN-Betreiber, Mobilfunkanbieter) sieht, " +
            "welche Seiten du aufrufst, oder kann die Antworten verändern. Bei Automatisch wird erst DoT, dann DoH versucht; " +
            "klappt beides nicht, wird einfaches DNS genutzt. Du wirst dann gewarnt, und die App versucht bei jedem Netzwechsel " +
            "und alle 10 Minuten, zur Verschlüsselung zurückzukehren. Mit \"Strikte Verschlüsselung\" wird nie einfaches DNS genutzt. " +
            "Der Startbildschirm zeigt das verwendete Verfahren.",
        "Verbindungstest" to
            "Einstellungen > Datenschutz & Sicherheit > Verbindungstest schickt echte DNS-Anfragen durch den Tunnel. Er zeigt, dass " +
            "DNS wirklich vom gewählten Server antwortet, wie schnell, ob der Server DNSSEC-Signaturen prüft " +
            "und ob er eine bekannte Werbedomain blockiert.",
        "Privatsphäre" to
            "Kein Konto, keine Datensammlung, keine Werbung. Die App speichert keine Anfragenamen und sendet von sich aus nichts. " +
            "Deine Anfragen gehen nur an den gewählten DNS-Anbieter; es gilt dessen Datenschutzerklärung. " +
            "Das Diagnoseprotokoll enthält nur Verbindungsereignisse.",
        "Akku und Ressourcen" to
            "Im Hintergrund braucht sie sehr wenig. Bei ausgeschaltetem Bildschirm läuft keine Schleife; " +
            "sie arbeitet nur, wenn eine DNS-Anfrage kommt. Verschlüsselte Verbindungen schließen sich im Leerlauf selbst.",
        "Gut zu wissen" to
            "Android erlaubt nur ein VPN gleichzeitig; ist eine andere VPN-App aktiv, kann diese App nicht verbinden. " +
            "Die Browser-Einstellung \"Sicheres DNS\" und Androids \"Privates DNS\" mit festem Hostnamen nutzen eigene Server " +
            "und umgehen diese Umleitung womöglich; \"Automatisch\" oder \"Aus\" genügt. " +
            "Lange auf die Kugel drücken: schnell zu deinen Servern wechseln oder die Verbindung kurz pausieren.",
    )

    override val NOTIF_CHANNEL = "Verbindungsstatus"
    override val NOTIF_CHANNEL_NOTE = "Wird angezeigt, solange die DNS-Verbindung aktiv ist"
    override val NOTIF_ALERT_CHANNEL = "Verbindungswarnungen"
    override val NOTIF_CONNECTING = "Verbinde…"
    override val NOTIF_STOP = "Trennen"
    override val NOTIF_NEXT = "Nächster"
    override val NOTIF_DROP_TITLE = "DNS-Verbindung unterbrochen"
    override val NOTIF_RECONNECT = "Neu verbinden"
    override fun notifOn(name: String, proto: String) = "Verbunden mit $name · $proto"
    override fun notifPaused(time: String) = "Pausiert · weiter um $time"
    override val TILE_ON = "Verbunden"
    override val TILE_OFF = "Aus"
    override val WIDGET_TAP = "Tippen: verbinden / trennen"
    override val ERR_PERMISSION = "VPN-Berechtigung nicht erteilt"
    override val ERR_ESTABLISH = "VPN-Schnittstelle ließ sich nicht öffnen. Evtl. ist ein anderes VPN aktiv."
    override fun errNoReply(name: String) = "$name hat nicht geantwortet"
    override fun errNoProto(name: String, proto: String) = "$name unterstützt $proto nicht"
    override val ERR_SOCKET = "Netzwerk nicht erreichbar"
    override fun errPrivateDns(host: String) = "Androids privates DNS ist auf $host festgelegt und umgeht die App. Stelle Einstellungen > Netzwerk > Privates DNS auf Automatisch oder Aus."
    override val ERR_REVOKED = "Die Verbindung wurde vom System beendet"
    override val ERR_TUNNEL = "Der Tunnel wurde unerwartet geschlossen"
    override val ERR_UNKNOWN = "Ein unerwarteter Fehler ist aufgetreten"

    override val CONSENT_TITLE = "Bevor du dich verbindest"
    override val CONSENT_BODY = listOf(
        "$APP nutzt die VPN-Schnittstelle von Android, um deine DNS-Anfragen (die Namen der besuchten Seiten) an den gewählten DNS-Server zu leiten.",
        "Dein Datenverkehr geht an keinen VPN-Server; nur DNS-Anfragen gehen an den gewählten Anbieter. Bei unterstützten Servern " +
            "werden sie verschlüsselt (DoT/DoH), sonst unverschlüsselt gesendet. Es gilt die Datenschutzerklärung des Anbieters.",
        "Die App sammelt keine persönlichen Daten, speichert keine Anfragenamen und teilt nichts.",
        "Wenn du fortfährst, zeigt Android eine VPN-Verbindungsanfrage; tippe dort auf \"OK\".",
    )
    override val CONSENT_OK = "Verstanden, weiter"
    override val CLOSE = "Schließen"
    override val BACK = "Zurück"

    // ---- 3. sürüm ----
    override val RESUMING = "Wird fortgesetzt…"
    override val DOWNGRADED = "Keine Verschlüsselung möglich, einfaches DNS"
    override val UPGRADED = "Wieder verschlüsseltes DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS ist nicht verschlüsselt"
    override fun notifDowngrade(name: String) = "Keine verschlüsselte Verbindung zu $name möglich. Einfaches DNS ist aktiv; die App versucht, zur Verschlüsselung zurückzukehren."
    override fun backupUsed(failed: String, used: String) = "$failed antwortet nicht, verbunden mit $used"
    override val NOTIF_RETRYING = "Verbindung verloren, neuer Versuch…"
    override fun errNoEncrypted(name: String) = "Keine verschlüsselte Verbindung zu $name möglich"
    override val APPLYING = "Neue Einstellung wird übernommen"
    override val CONFIRM_DISCONNECT = "Verbindung trennen?"
    override val DISCONNECT = "Trennen"

    override val SEC_NOTIF = "Benachrichtigungen"
    override val STRICT_ENC = "Strikte Verschlüsselung"
    override val STRICT_ENC_NOTE = "Nie auf einfaches DNS zurückfallen"
    override val AUTO_RECONNECT = "Automatisch neu verbinden"
    override val AUTO_RECONNECT_NOTE = "Bei Abbruch neuer Versuch nach 5 s, 30 s und 2 Min."
    override val BACKUP_SERVER = "Ersatzserver"
    override val BACKUP_OFF = "Aus"
    override val BACKUP_OFF_NOTE = "Nicht verbinden, wenn der gewählte Server nicht antwortet"
    override val BACKUP_FASTEST = "Schnellster"
    override val BACKUP_FASTEST_NOTE = "Der schnellste andere Server der letzten Messung"
    override val CONFIRM_OFF = "Vor dem Trennen fragen"
    override val CONFIRM_OFF_NOTE = "Ein versehentlicher Tipp auf die Kugel trennt nicht"
    override val LOCK_HIDE = "Im Sperrbildschirm verbergen"
    override val LOCK_HIDE_NOTE = "Kein Servername in der Benachrichtigung auf dem Sperrbildschirm"
    override val QUIET_NOTIF = "Dezente Benachrichtigung"
    override val QUIET_NOTIF_NOTE = "Ohne Symbol in der Statusleiste, lautlos"
    override val REMEMBER_FILTER = "Letzten Filter merken"
    override val REMEMBER_FILTER_NOTE = "Beim Öffnen der App gilt wieder der zuletzt gewählte Filter"
    override val AUTO_MEASURE = "Beim Start messen"
    override val AUTO_MEASURE_NOTE = "Misst automatisch, wenn die letzte Messung über einen Tag alt ist"
    override val MEASURE_ENC = "Verschlüsselt messen"
    override val MEASURE_ENC_NOTE = "Misst über DoT, näher an echter verschlüsselter Nutzung"
    override val OPT_SORT = listOf("Standard", "Tempo", "Name")
    override fun sortA11y(mode: String) = "Sortierung: $mode"
    override val AUTO_LIGHT = "Automatisch: helles Design"
    override val AUTO_DARK = "Automatisch: dunkles Design"
    override val NIGHT_HOURS = "Nachtstunden"
    override val FILTER_ENCRYPTED = "Verschlüsselt"
    override val FILTER_UNFILTERED = "Ungefiltert"

    override val TEST = "Verbindung testen"
    override val TEST_NOTE = "DNS, DNSSEC und Werbefilter"
    override val TESTING = "Teste…"
    override val TEST_TITLE = "Verbindungstest"
    override val TEST_OK = "DNS funktioniert"
    override val TEST_FAIL = "Keine Antwort"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Verfahren"
    override val TEST_LATENCY = "Antwortzeit"
    override val TEST_DNSSEC = "DNSSEC-Prüfung"
    override val TEST_ADS = "Werbefilter"
    override val DNSSEC_YES = "Aktiv"
    override val DNSSEC_NO = "Nicht aktiv"
    override val ADS_YES = "Aktiv"
    override val ADS_NO = "Nicht aktiv"
    override val UNKNOWN = "Unbekannt"
    override val TEST_EXPLAIN = "Die Anfragen liefen wie bei einer App durch den Tunnel; die Antworten kamen von deinem gewählten Server."
    override val TEST_AGAIN = "Erneut testen"

    override val RECOMMEND = "Passenden Server finden"
    override val RECOMMEND_NOTE = "Wähle dein Ziel, wir verbinden mit dem schnellsten passenden Server"
    override val GOAL_SPEED = "Tempo"
    override val GOAL_SPEED_NOTE = "Der schnellste Server laut deinen Messungen"
    override val GOAL_PRIVACY_NOTE = "Keine Logs, datenschutzfreundlich"
    override val GOAL_ADS_NOTE = "Blockiert Werbung und Tracker"
    override val GOAL_FAMILY_NOTE = "Blockiert Inhalte ab 18"
    override val GOAL_SECURITY_NOTE = "Blockiert schädliche und Phishing-Seiten"
    override fun recommended(name: String) = "Empfohlen: $name"

    override val PRIVATE_DNS = "Name für privates DNS"
    override val PRIVATE_DNS_NOTE = "Du kannst ihn in Androids Einstellung \"Privates DNS\" einfügen. Dann nutzt das System diesen Server direkt und diese App wird umgangen."
    override val CLEAR_HISTORY = "Messverlauf löschen"
    override val HISTORY_CLEARED = "Messungen gelöscht"

    override val GUARD = "Dauerhafter Schutz"
    override val GUARD_NOTE = "Durchgehend aktives VPN"
    override val GUARD_BODY = listOf(
        "Solange die App nicht verbunden ist (ausgeschaltet, pausiert oder nach einem Abbruch), gehen deine DNS-Anfragen an den Server deines Internetanbieters.",
        "Um das zu verhindern, aktiviere für diese App in Androids VPN-Einstellungen \"Durchgehend aktives VPN\". Ist auch \"Verbindungen ohne VPN blockieren\" an, funktioniert das Internet gar nicht, solange die App nicht verbunden ist: Nichts gelangt nach außen, aber Pausieren heißt dann auch kein Internet.",
        "Mit durchgehend aktivem VPN startet das System die App automatisch beim Hochfahren des Telefons und nachdem sie beendet wurde.",
    )
    override val GUARD_BUTTON = "System-VPN-Einstellungen öffnen"
    override val BATTERY = "Akku-Einstellungen"
    override val BATTERY_OK = "Nicht eingeschränkt"
    override val BATTERY_LIMITED = "Evtl. eingeschränkt"
    override val BATTERY_BODY = listOf(
        "Android schützt VPN-Apps normalerweise. Manche Hersteller (Xiaomi, Huawei, Oppo, Vivo, einige Samsung-Versionen) beenden aber Hintergrund-Apps, um Akku zu sparen.",
        "Bricht die Verbindung immer wieder von selbst ab, stelle die Akkunutzung dieser App auf \"Nicht eingeschränkt\" oder \"Nicht optimiert\"; erlaube auf manchen Telefonen auch \"Autostart\".",
    )
    override val BATTERY_BUTTON = "Akku-Einstellungen öffnen"

    override val STAT_AVG = "Mittlere Antwortzeit"
    override val STAT_SAVED = "Zeitersparnis durch Cache"
    override val STAT_TRAFFIC = "DNS-Datenverkehr"
    override val SESSIONS = "Verbindungsverlauf"
    override val SESSIONS_NOTE = "Letzte 30 Verbindungen; Anfragenamen werden nie gespeichert"
    override val SESSIONS_EMPTY = "Noch keine Verbindungen aufgezeichnet."
    override val MOST_USED = "Am häufigsten genutzt"
    override val TODAY = "Heute"
    override val YESTERDAY = "Gestern"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Von dir getrennt"
        EndReason.PAUSE -> "Pausiert"
        EndReason.SWITCH -> "Server gewechselt"
        EndReason.DROP -> "Abgebrochen"
        EndReason.REVOKED -> "Vom System beendet"
        EndReason.FAILED -> "Keine Antwort"
        EndReason.NETWORK -> "Netz gewechselt"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries Anfragen"

    override val WHATS_NEW = "Was ist neu?"
    override val WHATS_NEW_TOAST = "Die App wurde aktualisiert"
    override val SHOW = "Anzeigen"
    override val WHATS_NEW_ITEMS = listOf(
        "Sicherere Verbindung: zusätzliche Prüfungen gegen gefälschte DNS-Antworten, eine Warnung beim Rückfall auf einfaches DNS, strikte Verschlüsselung als Option und automatische Rückkehr zur Verschlüsselung.",
        "Verbindungstest: Prüfe mit einem Tipp, ob DNS wirklich von deinem gewählten Server antwortet, dazu DNSSEC-Prüfung und Werbefilter.",
        "Ersatzserver und automatisches Neuverbinden: Die App fängt sich selbst, wenn der gewählte Server nicht antwortet oder die Verbindung abbricht.",
        "Verbindungsverlauf, meistgenutzte Server, mittlere Antwortzeit und DNS-Datenverkehr.",
        "Neue Filter (Verschlüsselt, Ungefiltert), Sortieren nach Name, \"Passenden Server finden\" und Messen beim Start.",
        "Live-Zähler in der Benachrichtigung, eine Pausetaste für 15 Minuten, Verbergen im Sperrbildschirm und eine dezente Benachrichtigung.",
        "Drei neue Designs (Sakura, Honig, Polarlicht), ein Design aus deinem Hintergrundbild und Hell/Dunkel-Wahl für das automatische Design.",
        "Vier neue Sprachen: Indonesisch, Vietnamesisch, Polnisch und Ukrainisch.",
    )
    override fun importedWith(changes: String) = "Einstellungen geladen · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "Verschlüsselung abgeschwächt"
        SensitiveChange.AUTO_START -> "automatisches Verbinden aktiviert"
        SensitiveChange.RULES -> "Serverregeln geändert"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries Anfragen · $blocked blockiert"
    override val NOTIF_LOCKED = "DNS-Schutz ist aktiv"
    override val NOTIF_QUIET_CHANNEL = "Verbindungsstatus (dezent)"
    override fun widgetToday(queries: String) = "Heute $queries Anfragen"
    override fun pauseAction(minutes: Int) = "${minutes(minutes)} pausieren"


    override val NOTES = mapOf(
        "cloudflare" to "Schnell, datenschutzfreundlich",
        "google" to "Stabil, weit verbreitet",
        "quad9" to "Blockiert schädliche Domains",
        "adguard" to "Blockiert Werbung und Tracker",
        "controld" to "Ungefiltert, schnell",
        "opendns" to "Cisco, Phishing-Schutz",
        "mullvad" to "Keine Logs, nur verschlüsselt",
        "dnssb" to "Datenschutzfreundlich, schnell",
        "dns4eu" to "DNS der EU, Malware-Schutz",
        "uncensored" to "Keine Filter, keine Umleitung",
        "quad9-open" to "Blockiert nichts",
        "adguard-open" to "Keine Sperren, datenschutzfreundlich",
        "dns4eu-open" to "DNS der EU, ungefiltert",
        "controld-ads" to "Werbung, Tracker, Malware",
        "mullvad-ads" to "Werbung und Tracker, nur verschlüsselt",
        "dns4eu-ads" to "DNS der EU, Werbung und Malware",
        "cloudflare-security" to "Blockiert schädliche Seiten",
        "controld-malware" to "Blockiert schädliche Seiten",
        "cleanbrowsing-security" to "Phishing und schädliche Seiten",
        "cloudflare-family" to "Filter für Malware und Erotik",
        "opendns-family" to "Filter für Inhalte ab 18",
        "adguard-family" to "Filter für Werbung und Inhalte ab 18",
        "cleanbrowsing-family" to "Inhalte ab 18, sichere Suche",
        "dns4eu-child" to "DNS der EU, Jugendschutz",
        "mullvad-family" to "Familienfilter, nur verschlüsselt",
        "controld-family" to "Filter für Inhalte ab 18",
    )
}
