package app.dnshizli.platform

import android.content.Context
import android.content.SharedPreferences
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Latency
import app.dnshizli.core.LatencyCodec
import app.dnshizli.core.SettingsCodec

/**
 * Kalıcı depo: ayarlar ve gecikme ölçümleri SharedPreferences'ta düz metin olarak durur.
 * Etkinlik ve servis aynı süreçte çalıştığı için aynı örneği paylaşırlar; bu yüzden yazma sahipliği ayrılmıştır:
 *  - Arayüz yalnızca kullanıcı ayarlarını yazar ([saveSettings] servis alanlarını atlar).
 *  - Servis durum ve toplamları yazar ([setWasActive], [addTotals]).
 */
class PrefsStore(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun loadSettings(): AppSettings {
        val m = HashMap<String, String?>()
        for (k in KEYS) m[k] = sp.getString(k, null)
        return SettingsCodec.decode(m)
    }

    /** Kullanıcı ayarlarını yazar. Servisin sahip olduğu alanlar (durum, toplamlar) elle değiştirilmez. */
    fun saveSettings(s: AppSettings) {
        val e = sp.edit()
        for ((k, v) in SettingsCodec.encode(s)) if (k !in SERVICE_KEYS) e.putString(k, v)
        e.apply()
    }

    fun loadLatencies(): Map<String, Latency> = LatencyCodec.decode(sp.getString(LATENCIES, null))

    fun saveLatencies(m: Map<String, Latency>) {
        sp.edit().putString(LATENCIES, LatencyCodec.encode(m)).apply()
    }

    /** Servis: tünel açık mıydı? Süreç öldürülüp servis yeniden başlatılırsa bağlanmak için kullanılır. */
    fun setWasActive(v: Boolean) {
        sp.edit().putString("wasActive", v.toString()).apply()
    }

    /** Bildirim izni (Android 13+) bir kez istendi mi? İzin reddedilirse bir daha sorulmaz; uygulama izinsiz de çalışır. */
    fun askedNotifications(): Boolean = sp.getBoolean(ASKED_NOTIF, false)

    fun setAskedNotifications() {
        sp.edit().putBoolean(ASKED_NOTIF, true).apply()
    }

    /** Servis: oturumun yeni sorgu, önbellek isabeti ve saniye sayılarını toplamlara ekler. */
    @Synchronized
    fun addTotals(queries: Long, hits: Long, seconds: Long) {
        if (queries <= 0 && hits <= 0 && seconds <= 0) return
        val cur = loadSettings()
        sp.edit()
            .putString("totalQueries", (cur.totalQueries + maxOf(0, queries)).toString())
            .putString("totalHits", (cur.totalHits + maxOf(0, hits)).toString())
            .putString("totalSeconds", (cur.totalSeconds + maxOf(0, seconds)).toString())
            .apply()
    }

    companion object {
        private const val FILE = "dnshizli"
        private const val LATENCIES = "latencies"
        private const val ASKED_NOTIF = "askedNotif"
        private val KEYS: Set<String> = SettingsCodec.encode(AppSettings()).keys
        private val SERVICE_KEYS = setOf("wasActive", "totalQueries", "totalHits", "totalSeconds")
    }
}
