package app.dnshizli.platform

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeProvider
import app.dnshizli.ui.A11yItem
import app.dnshizli.ui.AppModel
import app.dnshizli.ui.Role
import app.dnshizli.ui.Scene
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Sahneyi ekrana getiren tek görünüm. Tüm arayüz [Scene] içinde (saf Kotlin) çizilir; bu sınıf yalnızca
 * Android'e özgü işleri yapar: kare döngüsü, dokunma, boyut/yoğunluk, erişilebilirlik (TalkBack).
 *
 * Kare döngüsü pil dostudur: sahne "kare gerekmiyor" derse (ekran durağan) hiçbir şey planlanmaz, yeni bir
 * olay ([requestFrame]) gelene kadar CPU/GPU tamamen boşta kalır. Süs animasyonları ~30 kare/sn'de çalışır.
 */
@SuppressLint("ViewConstructor")
class SceneView(
    context: Context,
    private val scene: Scene,
    private val model: AppModel,
    private val gfx: AndroidGfx,
    private val listener: Listener,
) : View(context) {

    interface Listener {
        /** Geri tuşunun bir şey yapıp yapmayacağı değişti (alt panel / alt sayfa açıldı ya da kapandı). */
        fun onBackAvailable(can: Boolean)

        /** Tema açıklık/koyuluk değiştirdi: sistem çubuğu simgeleri buna göre ayarlanır. */
        fun onThemeDark(dark: Boolean)
    }

    private val choreographer: Choreographer = Choreographer.getInstance()
    private var density = resources.displayMetrics.density
    private var insetTopPx = 0
    private var insetBottomPx = 0

    private var running = false
    private var scheduled = false
    private var scheduledDelayed = false

    private var lastCanBack = false
    private var lastDark: Boolean? = null

    private val frameCallback = Choreographer.FrameCallback { nanos ->
        scheduled = false
        scheduledDelayed = false
        onFrame(nanos / 1_000_000L)
    }

    // ------------------------------------------------------------------ yaşam döngüsü ve kareler

    fun resume() {
        running = true
        lastCanBack = !scene.canGoBack      // ilk karede dinleyiciye durumu bildirmek için
        lastDark = null
        a11yLayer = -1
        requestFrame()
    }

    fun pause() {
        running = false
        scheduled = false
        scheduledDelayed = false
        choreographer.removeFrameCallback(frameCallback)
        removeCallbacks(a11yCheck)
    }

    override fun onDetachedFromWindow() {
        pause()
        super.onDetachedFromWindow()
    }

    /** Sahnenin yeniden çizilmesi gerekiyor: en kısa sürede bir kare ister. Ana iş parçacığından çağrılır. */
    fun requestFrame() {
        if (!running) return
        if (scheduled) {
            if (!scheduledDelayed) return
            choreographer.removeFrameCallback(frameCallback)   // bekleyen gecikmeli kareyi öne çek
        }
        scheduled = true
        scheduledDelayed = false
        choreographer.postFrameCallback(frameCallback)
    }

    private fun onFrame(nowMs: Long) {
        if (!running) return
        val next = scene.tick(nowMs)
        syncSystemUi()
        syncAccessibility()
        invalidate()
        when {
            next < 0 -> {}                                    // durağan: yeni olay gelene dek kare yok
            next <= 16 -> {
                scheduled = true
                choreographer.postFrameCallback(frameCallback)
            }
            else -> {
                scheduled = true
                scheduledDelayed = true
                // Gecikme bir sonraki ekran yenilemesine yuvarlanır; hedefin biraz altı verilir.
                choreographer.postFrameCallbackDelayed(frameCallback, maxOf(1L, next - 12L))
            }
        }
    }

    private fun syncSystemUi() {
        val can = scene.canGoBack
        if (can != lastCanBack) { lastCanBack = can; listener.onBackAvailable(can) }
        val dark = scene.env.theme.dark
        if (dark != lastDark) { lastDark = dark; listener.onThemeDark(dark) }
    }

    // ------------------------------------------------------------------ boyut ve çizim

    /** Sistem çubuklarının işgal ettiği üst ve alt pay (piksel). */
    fun setInsets(topPx: Int, bottomPx: Int) {
        if (topPx == insetTopPx && bottomPx == insetBottomPx) return
        insetTopPx = topPx
        insetBottomPx = bottomPx
        applySize()
    }

    /** Yoğunluk veya yazı boyutu değişti. */
    fun onDisplayChanged() {
        density = resources.displayMetrics.density
        applySize()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applySize()
    }

    private fun applySize() {
        if (width <= 0 || height <= 0) return
        scene.resize(width / density, height / density, insetTopPx / density, insetBottomPx / density)
        requestFrame()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        gfx.begin(canvas, density)
        try {
            scene.draw(gfx)
        } finally {
            gfx.end()
        }
    }

    // ------------------------------------------------------------------ dokunma

    private var pointerId = -1
    private var touching = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerId = e.getPointerId(0)
                touching = true
                send(Scene.DOWN, e, 0)
            }
            MotionEvent.ACTION_MOVE -> if (touching) {
                val i = e.findPointerIndex(pointerId)
                if (i >= 0) send(Scene.MOVE, e, i)
            }
            MotionEvent.ACTION_UP -> if (touching) {
                touching = false
                val i = e.findPointerIndex(pointerId)
                send(Scene.UP, e, if (i >= 0) i else 0)
            }
            MotionEvent.ACTION_CANCEL -> if (touching) {
                touching = false
                scene.touch(Scene.CANCEL, 0f, 0f, e.eventTime)
            }
            // İlk parmağın dışındakiler yok sayılır; ilk parmak kalkarsa dokunma iptal edilir (yanlış dokunuş olmasın).
            MotionEvent.ACTION_POINTER_UP -> if (touching && e.getPointerId(e.actionIndex) == pointerId) {
                touching = false
                scene.touch(Scene.CANCEL, 0f, 0f, e.eventTime)
            }
        }
        return true
    }

    private fun send(action: Int, e: MotionEvent, index: Int) {
        scene.touch(action, e.getX(index) / density, e.getY(index) / density, e.eventTime)
    }

    // ------------------------------------------------------------------ erişilebilirlik (TalkBack)

    private val a11yManager: AccessibilityManager? = context.getSystemService(AccessibilityManager::class.java)
    private var items: List<A11yItem> = emptyList()
    private var ids = IntArray(0)
    private val itemById = HashMap<Int, A11yItem>()
    private var focusedId = NO_ID_
    private var hoveredId = NO_ID_

    private var a11yLayer = -1
    private var a11ySig = 0
    private var seenToast = 0
    private var seenState: Any? = null
    private val a11yCheck = Runnable { a11yCheckNow() }

    private fun a11yOn(): Boolean = a11yManager?.isEnabled == true

    /** Her karede çağrılır; erişilebilirlik kapalıyken neredeyse hiçbir şey yapmaz. */
    @Suppress("DEPRECATION")
    private fun syncAccessibility() {
        if (!a11yOn()) return
        // Geçici mesajlar ve bağlantı durumu sesli duyurulur.
        if (model.toastSeq != seenToast) {
            seenToast = model.toastSeq
            model.toast?.let { announceForAccessibility(it.text) }
        }
        val st = model.vpn.state
        if (seenState == null) seenState = st
        else if (seenState != st) {
            seenState = st
            announceForAccessibility(model.statusTitle() + ", " + model.statusSub())
        }
        // Yapı değişikliği, son kareden 250 ms sonra tek olay olarak bildirilir (kaydırma sürerken beklenir).
        removeCallbacks(a11yCheck)
        postDelayed(a11yCheck, 250)
    }

    private fun a11yCheckNow() {
        if (!running || !a11yOn()) return
        refreshItems()
        val layer = scene.pageCount * 2 + if (scene.hasSheet) 1 else 0
        val sig = signature()
        if (a11yLayer < 0) {
            a11yLayer = layer; a11ySig = sig
        } else if (layer != a11yLayer) {
            // Yeni ekran/panel: odağı başa al.
            a11yLayer = layer; a11ySig = sig
            sendHostEvent(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, 0, items.firstOrNull { it.info.role == Role.HEADING }?.info?.label)
        } else if (sig != a11ySig) {
            a11ySig = sig
            sendHostEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED, AccessibilityEvent.CONTENT_CHANGE_TYPE_SUBTREE, null)
        }
    }

    /** Ekran yapısının özeti: öğe kimlikleri ve (kayan metinler hariç) etiket, durum, değer. */
    private fun signature(): Int {
        var h = items.size
        for (it in items) {
            h = h * 31 + idOf(it)
            val a = it.info
            if (a.role != Role.TEXT) {
                h = h * 31 + a.label.hashCode()
                h = h * 31 + (a.checked?.hashCode() ?: 0)
                h = h * 31 + (a.value?.hashCode() ?: 0)
            }
        }
        return h
    }

    private fun idOf(item: A11yItem): Int = (System.identityHashCode(item.node) and 0x3FFFFFFF) + 1

    private fun refreshItems() {
        items = scene.a11yItems()
        itemById.clear()
        if (ids.size < items.size) ids = IntArray(items.size)
        for (i in items.indices) {
            var id = idOf(items[i])
            while (itemById.containsKey(id)) id++        // kimlik çakışması (çok nadir): bir sonrakini kullan
            itemById[id] = items[i]
            ids[i] = id
        }
    }

    private fun itemAt(x: Float, y: Float): Int {
        refreshItems()
        var best = NO_ID_
        var bestArea = Float.MAX_VALUE
        val px = x / density
        val py = y / density
        for (i in items.indices) {
            val it = items[i]
            if (px < it.l || px > it.r || py < it.t || py > it.b) continue
            val area = (it.r - it.l) * (it.b - it.t)
            if (area < bestArea) { bestArea = area; best = ids[i] }
        }
        return best
    }

    private fun describe(item: A11yItem): String {
        val a = item.info
        return if (a.value != null && a.role != Role.SLIDER) a.label + ", " + a.value else a.label
    }

    private fun className(role: Role): String = when (role) {
        Role.BUTTON -> "android.widget.Button"
        Role.SWITCH -> "android.widget.Switch"
        Role.SLIDER -> "android.widget.SeekBar"
        Role.TEXT, Role.HEADING -> "android.widget.TextView"
    }

    override fun getAccessibilityNodeProvider(): AccessibilityNodeProvider = provider

    // lazy: görünüm kurucusu sırasında çağrılırsa bile boş değer dönmez.
    private val provider: AccessibilityNodeProvider by lazy(LazyThreadSafetyMode.NONE) { createProvider() }

    private fun createProvider() = object : AccessibilityNodeProvider() {
        override fun createAccessibilityNodeInfo(virtualViewId: Int): AccessibilityNodeInfo? =
            if (virtualViewId == HOST_VIEW_ID) createHostInfo() else createItemInfo(virtualViewId)

        override fun performAction(virtualViewId: Int, action: Int, arguments: Bundle?): Boolean =
            if (virtualViewId == HOST_VIEW_ID) performHostAction(action, arguments) else performItemAction(virtualViewId, action)
    }

    @Suppress("DEPRECATION")
    private fun createHostInfo(): AccessibilityNodeInfo {
        val info = AccessibilityNodeInfo.obtain(this)
        onInitializeAccessibilityNodeInfo(info)
        refreshItems()
        for (i in items.indices) info.addChild(this, ids[i])
        val fwd = scene.a11yCanScroll(true)
        val back = scene.a11yCanScroll(false)
        info.isScrollable = fwd || back
        if (fwd) info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD)
        if (back) info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD)
        return info
    }

    @Suppress("DEPRECATION")
    private fun createItemInfo(id: Int): AccessibilityNodeInfo? {
        var item = itemById[id]
        if (item == null) {
            refreshItems()
            item = itemById[id] ?: return null
        }
        val a = item.info
        val info = AccessibilityNodeInfo.obtain(this, id)
        info.packageName = context.packageName
        info.className = className(a.role)
        info.setParent(this)
        info.isEnabled = true
        info.isVisibleToUser = true
        info.isFocusable = true
        info.isAccessibilityFocused = id == focusedId
        info.contentDescription = describe(item)

        val r = Rect(floor(item.l * density).toInt(), floor(item.t * density).toInt(), ceil(item.r * density).toInt(), ceil(item.b * density).toInt())
        info.setBoundsInParent(r)
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        r.offset(loc[0], loc[1])
        info.setBoundsInScreen(r)

        when (a.role) {
            Role.BUTTON -> {
                info.isClickable = true
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)
                if (a.longClick) {
                    info.isLongClickable = true
                    info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_LONG_CLICK)
                }
            }
            Role.SWITCH -> {
                info.isClickable = true
                info.isCheckable = true
                info.isChecked = a.checked == true
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)
            }
            Role.SLIDER -> {
                val pct = a.value?.filter { it.isDigit() }?.toFloatOrNull()
                if (pct != null) info.rangeInfo = AccessibilityNodeInfo.RangeInfo.obtain(AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_PERCENT, 0f, 100f, pct.coerceIn(0f, 100f))
                if (Build.VERSION.SDK_INT >= 30 && a.value != null) info.stateDescription = a.value
                info.contentDescription = a.label
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD)
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD)
            }
            Role.HEADING -> {
                if (Build.VERSION.SDK_INT >= 28) info.isHeading = true
            }
            Role.TEXT -> {}
        }
        info.addAction(
            if (id == focusedId) AccessibilityNodeInfo.AccessibilityAction.ACTION_CLEAR_ACCESSIBILITY_FOCUS
            else AccessibilityNodeInfo.AccessibilityAction.ACTION_ACCESSIBILITY_FOCUS
        )
        return info
    }

    private fun performHostAction(action: Int, arguments: Bundle?): Boolean = when (action) {
        AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> scene.a11yScroll(true)
        AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> scene.a11yScroll(false)
        else -> performAccessibilityAction(action, arguments)
    }

    private fun performItemAction(id: Int, action: Int): Boolean {
        var item = itemById[id]
        if (item == null) {
            refreshItems()
            item = itemById[id] ?: return false
        }
        return when (action) {
            AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS -> {
                if (focusedId != id) {
                    focusedId = id
                    sendItemEvent(id, AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED)
                }
                true
            }
            AccessibilityNodeInfo.ACTION_CLEAR_ACCESSIBILITY_FOCUS -> {
                if (focusedId == id) {
                    focusedId = NO_ID_
                    sendItemEvent(id, AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED)
                }
                true
            }
            AccessibilityNodeInfo.ACTION_CLICK -> {
                if (item.info.role == Role.BUTTON || item.info.role == Role.SWITCH) {
                    scene.a11yClick(item)
                    sendItemEvent(id, AccessibilityEvent.TYPE_VIEW_CLICKED)
                    true
                } else false
            }
            AccessibilityNodeInfo.ACTION_LONG_CLICK -> item.info.longClick && scene.a11yLongClick(item)
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> if (item.info.role == Role.SLIDER) { scene.a11yAdjust(item, 1); true } else false
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> if (item.info.role == Role.SLIDER) { scene.a11yAdjust(item, -1); true } else false
            else -> false
        }
    }

    @Suppress("DEPRECATION")
    private fun sendItemEvent(id: Int, type: Int) {
        if (!a11yOn()) return
        val item = itemById[id] ?: return
        val p = parent ?: return
        val ev = AccessibilityEvent.obtain(type)
        ev.packageName = context.packageName
        ev.className = className(item.info.role)
        ev.contentDescription = describe(item)
        ev.text.add(describe(item))
        ev.isEnabled = true
        ev.setSource(this, id)
        p.requestSendAccessibilityEvent(this, ev)
    }

    @Suppress("DEPRECATION")
    private fun sendHostEvent(type: Int, contentChange: Int, text: String?) {
        val p = parent ?: return
        val ev = AccessibilityEvent.obtain(type)
        onInitializeAccessibilityEvent(ev)
        if (contentChange != 0) ev.contentChangeTypes = contentChange
        if (text != null) ev.text.add(text)
        ev.setSource(this)
        p.requestSendAccessibilityEvent(this, ev)
    }

    /** Dokunarak keşif: parmağın altındaki öğeyi TalkBack'e bildirir (ExploreByTouchHelper'daki kural). */
    override fun dispatchHoverEvent(event: MotionEvent): Boolean {
        val mgr = a11yManager
        if (mgr != null && mgr.isEnabled && mgr.isTouchExplorationEnabled) {
            when (event.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_HOVER_MOVE -> {
                    val id = itemAt(event.x, event.y)
                    updateHover(id)
                    if (id != NO_ID_) return true
                }
                MotionEvent.ACTION_HOVER_EXIT -> if (hoveredId != NO_ID_) {
                    updateHover(NO_ID_)
                    return true
                }
            }
        }
        return super.dispatchHoverEvent(event)
    }

    private fun updateHover(id: Int) {
        if (hoveredId == id) return
        val prev = hoveredId
        hoveredId = id
        // Çerçevenin kendi davranışıyla uyumlu olarak önce GİRİŞ, sonra ÇIKIŞ olayı gönderilir.
        if (id != NO_ID_) sendItemEvent(id, AccessibilityEvent.TYPE_VIEW_HOVER_ENTER)
        if (prev != NO_ID_) sendItemEvent(prev, AccessibilityEvent.TYPE_VIEW_HOVER_EXIT)
    }

    private companion object {
        const val NO_ID_ = Int.MIN_VALUE
        const val HOST_VIEW_ID = AccessibilityNodeProvider.HOST_VIEW_ID
    }
}
