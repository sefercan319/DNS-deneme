package app.dnshizli.core

/**
 * Küçük bir LRU DNS önbelleği. En fazla [maxEntries] kayıt tutar (kayıt başına yüzlerce bayt),
 * yani en büyük ayarda bile birkaç yüz KB'ı geçmez. Tekrarlayan sorgular ağa hiç çıkmaz:
 * hem hız hem pil kazancı. [maxEntries] sıfır veya negatifse önbellek tamamen kapalıdır.
 *
 * Anahtar: sorgu mesajının ilk 2 bayt (id) hariç tamamı. Böylece bayrak ve EDNS farkları
 * yanlışlıkla aynı kayda düşmez.
 */
internal class DnsCache(
    private val maxEntries: Int,
    private val nowMs: () -> Long,
) {
    private class Cached(val data: ByteArray, val expiresAt: Long)

    private val map = object : LinkedHashMap<String, Cached>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Cached>): Boolean =
            size > maxEntries
    }

    @Synchronized
    fun put(key: String, resp: ByteArray, len: Int, ttlSec: Int) {
        if (maxEntries <= 0 || ttlSec < 1) return
        val life = minOf(ttlSec, MAX_TTL_S) * 1000L
        map[key] = Cached(resp.copyOf(len), nowMs() + life)
    }

    /**
     * Kayıt varsa cevabı [out] içine [off] konumundan başlayarak kopyalar, DNS id'sini istemcinin
     * id'siyle değiştirir ve uzunluğu döner. Yoksa ya da süresi dolduysa -1.
     */
    @Synchronized
    fun get(key: String, clientId: Int, out: ByteArray, off: Int): Int {
        if (maxEntries <= 0) return -1
        val e = map[key] ?: return -1
        if (nowMs() >= e.expiresAt) {
            map.remove(key)
            return -1
        }
        System.arraycopy(e.data, 0, out, off, e.data.size)
        Packets.put16(out, off, clientId)
        return e.data.size
    }

    @Synchronized
    fun size(): Int = map.size

    @Synchronized
    fun clear() = map.clear()

    companion object {
        /** Sunucu çok uzun TTL verse bile en fazla 5 dakika tutulur. */
        const val MAX_TTL_S = 300
    }
}
