package app.dnshizli.platform

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsProbe
import app.dnshizli.core.Journal
import app.dnshizli.core.Latency
import app.dnshizli.core.OrbState
import app.dnshizli.ui.AppModel
import app.dnshizli.ui.Host
import app.dnshizli.ui.Scene
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tek ekranlı uygulamanın etkinliği: sahneyi kurar, Android'e özgü yetenekleri ([Host]) sağlar, VPN iznini ister,
 * kısayol/kutucuk niyetlerini işler. Ağır iş yoktur; VPN'in kendisi [DnsVpnService]'te çalışır.
 */
class MainActivity : Activity(), SceneView.Listener {

    private lateinit var prefs: PrefsStore
    private lateinit var model: AppModel
    private lateinit var scene: Scene
    private var view: SceneView? = null
    private val host = AndroidHost()
    private val main = Handler(Looper.getMainLooper())

    private var pendingServer: String? = null
    private var connectRequestedAt = 0L
    private var visible = false
    private var destroyedFlag = false
    private var pool: ExecutorService? = null
    private var backCallback: Any? = null
    private var backRegistered = false

    private val vpnListener: (VpnUi) -> Unit = { applyVpn(it) }
    private val pull = object : Runnable {
        override fun run() {
            pullStatus()
            if (visible && model.vpn.active) main.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsStore(this)
        model = AppModel(host, prefs.loadSettings(), prefs.loadLatencies())
        val metrics = PaintMetrics()
        scene = Scene(model, metrics)
        val v = SceneView(this, scene, model, AndroidGfx(metrics), this)
        view = v
        setContentView(v)
        setupEdgeToEdge(v)
        applyConfig()
        applyVpn(VpnStatus.snapshot())
        handleIntent(intent, savedInstanceState == null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, false)
    }

    override fun onResume() {
        super.onResume()
        visible = true
        applyConfig()
        VpnStatus.addListener(vpnListener)
        pullStatus()
        view?.resume()
        if (model.vpn.active) main.postDelayed(pull, 1000)
    }

    override fun onPause() {
        visible = false
        main.removeCallbacks(pull)
        VpnStatus.removeListener(vpnListener)
        view?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        destroyedFlag = true
        main.removeCallbacksAndMessages(null)
        pool?.shutdownNow()
        unregisterBack()
        super.onDestroy()
    }

    /** Yazı boyutu, koyu/açık mod, yoğunluk, yön değişimleri etkinliği yeniden başlatmadan işlenir. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyConfig()
        view?.onDisplayChanged()
    }

    private fun applyConfig() {
        val cfg = resources.configuration
        scene.setFontScale(cfg.fontScale)
        scene.setSystemDark((cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        // Sistem animasyon ölçeği 0 (erişilebilirlik ya da pil tasarrufu) ise animasyonlar kapanır.
        scene.setSystemMotion(ValueAnimator.areAnimatorsEnabled())
        view?.requestFrame()
    }

    // ------------------------------------------------------------------ kenardan kenara, sistem çubukları

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge(v: SceneView) {
        val w = window
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false)
        } else {
            w.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode =
                if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        v.setOnApplyWindowInsetsListener { _, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                top = i.top
                bottom = i.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            v.setInsets(top, bottom)
            insets
        }
    }

    /** Tema açıksa (açık zemin) koyu simgeler, koyuysa açık simgeler. */
    @Suppress("DEPRECATION")
    override fun onThemeDark(dark: Boolean) {
        val light = !dark
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController ?: return
            val mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            c.setSystemBarsAppearance(if (light) mask else 0, mask)
        } else {
            val d = window.decorView
            var f = d.systemUiVisibility
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            d.systemUiVisibility = f
        }
    }

    // ------------------------------------------------------------------ geri

    /** Geri tuşu yalnızca alt panel/alt sayfa açıkken bizdedir; ana ekranda sistemin kendi davranışı (ve geri animasyonu) çalışır. */
    override fun onBackAvailable(can: Boolean) {
        if (Build.VERSION.SDK_INT >= 33) {
            if (can) registerBack() else unregisterBack()
        }
    }

    @SuppressLint("NewApi")
    private fun registerBack() {
        if (backRegistered || Build.VERSION.SDK_INT < 33) return
        val cb = (backCallback as? OnBackInvokedCallback) ?: OnBackInvokedCallback { scene.goBack() }.also { backCallback = it }
        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
        backRegistered = true
    }

    @SuppressLint("NewApi")
    private fun unregisterBack() {
        if (!backRegistered || Build.VERSION.SDK_INT < 33) return
        (backCallback as? OnBackInvokedCallback)?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        backRegistered = false
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (!scene.goBack()) super.onBackPressed()
    }

    // ------------------------------------------------------------------ VPN durumu

    /**
     * Servisten gelen durumu modele aktarır. Bağlanma isteği yeni verilmişken gelen eski "kapalı" bilgisi
     * (servis henüz başlamamıştır) yok sayılır; yoksa küre bağlanırken bir an kapalıya döner.
     */
    private fun applyVpn(ui: VpnUi) {
        if (ui.state == OrbState.OFF && model.vpn.state == OrbState.CONNECTING &&
            SystemClock.elapsedRealtime() - connectRequestedAt < CONNECT_GRACE_MS
        ) return
        val was = model.vpn.state
        model.onVpn(ui)
        if (ui.state == OrbState.ON && was != OrbState.ON) {
            if (visible) { main.removeCallbacks(pull); main.postDelayed(pull, 1000) }
            maybeAskNotifications()
        }
    }

    /** Arayüz görünürken saniyede bir: canlı sayaçlar ve servisin yazdığı toplamlar. Servis kendi başına uyanmaz. */
    private fun pullStatus() {
        val fresh = prefs.loadSettings()
        val cur = model.settings
        if (fresh.totalQueries != cur.totalQueries || fresh.totalHits != cur.totalHits ||
            fresh.totalSeconds != cur.totalSeconds || fresh.wasActive != cur.wasActive
        ) {
            model.replaceSettings(
                cur.copy(
                    wasActive = fresh.wasActive,
                    totalQueries = fresh.totalQueries,
                    totalHits = fresh.totalHits,
                    totalSeconds = fresh.totalSeconds,
                )
            )
        }
        applyVpn(VpnStatus.snapshot())
    }

    private fun maybeAskNotifications() {
        if (Build.VERSION.SDK_INT < 33 || prefs.askedNotifications()) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        prefs.setAskedNotifications()
        try { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ bağlan / kes

    private fun connect(serverId: String) {
        connectRequestedAt = SystemClock.elapsedRealtime()
        val consent = try { VpnService.prepare(this) } catch (_: Exception) { null }
        if (consent != null) {
            pendingServer = serverId
            try {
                startActivityForResult(consent, REQ_VPN)
            } catch (_: Exception) {
                pendingServer = null
                model.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, Strings.ERR_PERMISSION))
            }
        } else {
            startVpn(serverId)
        }
    }

    /** [serverId] boşsa servis, ağ kuralına ya da son kullanılan sunucuya bakar. */
    private fun startVpn(serverId: String?) {
        try {
            startForegroundService(DnsVpnService.connectIntent(this, serverId))
        } catch (e: Exception) {
            Journal.add("servis başlatılamadı: ${e.javaClass.simpleName}")
            model.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, Strings.ERR_UNKNOWN))
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_VPN) return
        val id = pendingServer          // etkinlik izin penceresi açıkken yeniden yaratıldıysa boştur
        pendingServer = null
        if (resultCode == RESULT_OK) {
            startVpn(id)
        } else {
            // İzin verilmedi: küre bağlanıyor durumunda kalmasın.
            connectRequestedAt = 0
            model.onVpn(VpnUi())
            model.toast(Strings.ERR_PERMISSION)
        }
    }

    /** Kısayol ve kutucuktan gelen niyetler, ve "uygulama açılınca bağlan" ayarı. */
    private fun handleIntent(intent: Intent?, fresh: Boolean) {
        when (intent?.action) {
            DnsVpnService.ACTION_CONNECT -> if (!model.vpn.active) model.tapOrb()
            DnsVpnService.ACTION_DISCONNECT -> if (model.vpn.active) model.tapOrb()
            else -> {
                val s = model.settings
                if (fresh && s.autoConnect && s.onboarded && !model.vpn.active) model.tapOrb()
            }
        }
        // Aynı niyet yeniden işlenmesin (ör. yön değişiminde).
        intent?.action = null
    }

    // ------------------------------------------------------------------ Host

    private inner class AndroidHost : Host {
        override fun connect(serverId: String) = this@MainActivity.connect(serverId)

        override fun disconnect() {
            connectRequestedAt = 0
            try {
                startForegroundService(DnsVpnService.disconnectIntent(this@MainActivity))
            } catch (e: Exception) {
                Journal.add("kesme komutu gönderilemedi: ${e.javaClass.simpleName}")
                model.onVpn(VpnUi())
            }
        }

        override fun measure(serverIds: List<String>) {
            val ex = pool ?: newProbePool().also { pool = it }
            val left = AtomicInteger(serverIds.size)
            for (id in serverIds) {
                val server = Catalog.byId(id)
                try {
                    ex.execute {
                        val ms = if (server == null) null else try { DnsProbe.measure(server.primary) } catch (_: Exception) { null }
                        main.post {
                            if (destroyedFlag) return@post
                            model.onLatency(id, ms)
                            if (left.decrementAndGet() == 0) model.onMeasureDone()
                        }
                    }
                } catch (_: Exception) {
                    // havuz kapanmış (etkinlik yok ediliyor)
                }
            }
        }

        /** En çok 4 iş parçacığı; boşta kalanlar 5 sn sonra kendiliğinden kapanır (ölçüm bitince bellekte iş parçacığı kalmaz). */
        private fun newProbePool(): ExecutorService =
            ThreadPoolExecutor(4, 4, 5L, TimeUnit.SECONDS, LinkedBlockingQueue()) { r ->
                Thread(r, "dns-probe").also { it.isDaemon = true }
            }.also { it.allowCoreThreadTimeOut(true) }

        override fun saveSettings(s: AppSettings) = prefs.saveSettings(s)
        override fun saveLatencies(m: Map<String, Latency>) = prefs.saveLatencies(m)

        override fun copyText(text: String) {
            val cm = getSystemService(ClipboardManager::class.java) ?: return
            cm.setPrimaryClip(ClipData.newPlainText(Strings.APP, text))
        }

        override fun shareText(text: String) {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            try { startActivity(Intent.createChooser(send, null)) } catch (_: Exception) {}
        }

        override fun haptic(strong: Boolean) {
            val v = view ?: return
            val kind = when {
                !strong -> HapticFeedbackConstants.VIRTUAL_KEY
                Build.VERSION.SDK_INT >= 30 -> HapticFeedbackConstants.CONFIRM
                else -> HapticFeedbackConstants.LONG_PRESS
            }
            v.performHapticFeedback(kind)
        }

        override fun openVpnSettings() {
            try { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) {}
        }

        override fun diagnostics(): String =
            "${Strings.APP} ${versionName()} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" + Journal.log.dump()

        override fun clearDiagnostics() = Journal.log.clear()

        override fun versionName(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (_: Exception) { "1.0" }

        override fun now(): Long = System.currentTimeMillis()

        override fun requestFrame() { view?.requestFrame() }
    }

    private companion object {
        const val REQ_VPN = 1
        const val REQ_NOTIF = 2
        const val CONNECT_GRACE_MS = 4000L
    }
}
