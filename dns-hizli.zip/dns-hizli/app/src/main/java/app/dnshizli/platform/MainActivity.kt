package app.dnshizli.platform

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.content.res.Configuration
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import android.net.Uri
import app.dnshizli.R
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsProbe
import app.dnshizli.core.Journal
import app.dnshizli.core.L
import app.dnshizli.core.Latency
import app.dnshizli.core.OrbState
import app.dnshizli.core.Proto
import app.dnshizli.core.SelfTestResult
import app.dnshizli.ui.AppModel
import app.dnshizli.ui.Host
import app.dnshizli.ui.Scene
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tek ekranlı uygulamanın etkinliği: sahneyi kurar, Android'e özgü yetenekleri ([Host]) sağlar, VPN iznini ister,
 * kısayol/kutucuk niyetlerini işler. Ağır iş yoktur; VPN'in kendisi [DnsVpnService]'te çalışır.
 */
class MainActivity : Activity(), SceneView.Listener {

    private lateinit var prefs: PrefsStore
    private lateinit var model: AppModel
    private lateinit var scene: Scene
    private var view: SceneView? = null
    private val host = AndroidHost()
    private val main = Handler(Looper.getMainLooper())

    private var pendingServer: String? = null
    private var connectRequestedAt = 0L
    private var visible = false
    private var destroyedFlag = false
    private var pool: ExecutorService? = null
    private var backCallback: Any? = null
    private var backRegistered = false

    private val vpnListener: (VpnUi) -> Unit = { applyVpn(it) }
    private val testListener: (SelfTestResult) -> Unit = { if (!destroyedFlag) model.onTestResult(it) }
    private val pull = object : Runnable {
        override fun run() {
            pullStatus()
            main.removeCallbacks(this)          // pullStatus içinden de kurulmuş olabilir: tek zamanlayıcı kalsın
            if (visible && model.vpn.active) main.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsStore(this)
        val settings = prefs.loadSettings()
        App.applyLanguage(this, settings.lang)
        model = AppModel(host, settings, prefs.loadLatencies(), prefs.loadHistory())
        val metrics = PaintMetrics()
        scene = Scene(model, metrics)
        val v = SceneView(this, scene, model, AndroidGfx(metrics), this)
        view = v
        setContentView(v)
        setupEdgeToEdge(v)
        applyConfig()
        applyVpn(withPause(VpnStatus.snapshot()))
        // Kısayol/kutucuk eylemi yalnızca gerçekten yeni bir açılışta işlenir: süreç öldükten sonra yeniden kurulan ya da
        // "son kullanılanlar"dan açılan etkinlik eski niyeti taşır ve onu yeniden uygulamamalıdır.
        val launchedFromHistory = ((intent?.flags ?: 0) and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0
        handleIntent(intent, savedInstanceState == null && !launchedFromHistory)
        host.updateShortcuts(Catalog.all.filter { it.id in model.settings.favorites }.map { it.id })
    }

    /** Süreç duraklatma sırasında yeniden başladıysa (servis çalışmıyor) bitiş zamanını depodan ekler. */
    private fun withPause(ui: VpnUi): VpnUi {
        if (ui.active || ui.pausedUntil != 0L) return ui
        val t = prefs.pausedUntil()
        return if (t > System.currentTimeMillis()) ui.copy(pausedUntil = t) else ui
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Açıkken gelen yeni niyet (kısayol, bildirim): eylemi işlenir, ama "açılınca bağlan" yeniden tetiklenmez.
        val action = intent.action
        if (action == DnsVpnService.ACTION_CONNECT || action == DnsVpnService.ACTION_DISCONNECT || action == DnsVpnService.ACTION_PAUSE) {
            handleIntent(intent, true)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        applyConfig()
        VpnStatus.addListener(vpnListener)
        VpnStatus.addTestListener(testListener)
        pullStatus()
        view?.resume()
        if (model.vpn.active) main.postDelayed(pull, 1000)
        model.onStart()
    }

    override fun onPause() {
        visible = false
        main.removeCallbacks(pull)
        VpnStatus.removeListener(vpnListener)
        VpnStatus.removeTestListener(testListener)
        view?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        destroyedFlag = true
        main.removeCallbacksAndMessages(null)
        pool?.shutdownNow()
        unregisterBack()
        super.onDestroy()
    }

    /** Yazı boyutu, koyu/açık mod, yoğunluk, yön değişimleri etkinliği yeniden başlatmadan işlenir. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyConfig()
        view?.onDisplayChanged()
    }

    private fun applyConfig() {
        val cfg = resources.configuration
        // Android 13+: kullanıcı uygulama dilini sistem ayarlarından değiştirdiyse onu benimse.
        // (Sistemde açık bir seçim yoksa uygulama içi seçim geçerlidir ve sisteme yazılır.)
        // Android 13+: sistemin "uygulama dili" ayarı esastır (uygulama içi seçim de oraya yazılır).
        App.systemAppLocale(this)?.let { raw ->
            val sys = L.normalize(raw)
            val stored = model.settings.lang
            if (sys == L.AUTO && stored != L.AUTO && !prefs.localeSynced()) {
                // Android 13'e yükseltmeden önce seçilen dil sisteme hiç yazılmamış: sistemi ona göre ayarla, seçimi silme.
                App.syncSystemLocale(this, stored)
                prefs.setLocaleSynced()
            } else if (sys != stored) {
                model.update { it.copy(lang = sys) }
            }
        }
        model.setAccentSeed(host.systemAccent())
        val before = L.tx
        App.applyLanguage(this, model.settings.lang)
        if (L.tx !== before) { model.onLanguageChanged(); Notifier.ensureChannel(this) }
        scene.setFontScale(cfg.fontScale)
        scene.setSystemDark((cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        // Sistem animasyon ölçeği 0 (erişilebilirlik ya da pil tasarrufu) ise animasyonlar kapanır.
        scene.setSystemMotion(ValueAnimator.areAnimatorsEnabled())
        view?.requestFrame()
    }

    // ------------------------------------------------------------------ kenardan kenara, sistem çubukları

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge(v: SceneView) {
        val w = window
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false)
        } else {
            w.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode =
                if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        v.setOnApplyWindowInsetsListener { _, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                top = i.top
                bottom = i.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            v.setInsets(top, bottom)
            insets
        }
    }

    /** Tema açıksa (açık zemin) koyu simgeler, koyuysa açık simgeler. */
    @Suppress("DEPRECATION")
    override fun onThemeDark(dark: Boolean) {
        val light = !dark
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController ?: return
            val mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            c.setSystemBarsAppearance(if (light) mask else 0, mask)
        } else {
            val d = window.decorView
            var f = d.systemUiVisibility
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            d.systemUiVisibility = f
        }
    }

    // ------------------------------------------------------------------ geri

    /** Geri tuşu yalnızca alt panel/alt sayfa açıkken bizdedir; ana ekranda sistemin kendi davranışı (ve geri animasyonu) çalışır. */
    override fun onBackAvailable(can: Boolean) {
        if (Build.VERSION.SDK_INT >= 33) {
            if (can) registerBack() else unregisterBack()
        }
    }

    @SuppressLint("NewApi")
    private fun registerBack() {
        if (backRegistered || Build.VERSION.SDK_INT < 33) return
        val cb = (backCallback as? OnBackInvokedCallback) ?: OnBackInvokedCallback { scene.goBack() }.also { backCallback = it }
        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
        backRegistered = true
    }

    @SuppressLint("NewApi")
    private fun unregisterBack() {
        if (!backRegistered || Build.VERSION.SDK_INT < 33) return
        (backCallback as? OnBackInvokedCallback)?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        backRegistered = false
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (!scene.goBack()) super.onBackPressed()
    }

    // ------------------------------------------------------------------ VPN durumu

    /**
     * Servisten gelen durumu modele aktarır. Bağlanma isteği yeni verilmişken gelen eski "kapalı" bilgisi
     * (servis henüz başlamamıştır) yok sayılır; yoksa küre bağlanırken bir an kapalıya döner.
     */
    private fun applyVpn(ui: VpnUi) {
        if (ui.state == OrbState.OFF && model.vpn.state == OrbState.CONNECTING &&
            SystemClock.elapsedRealtime() - connectRequestedAt < CONNECT_GRACE_MS
        ) return
        val was = model.vpn.state
        model.onVpn(ui)
        if (ui.state == OrbState.ON && was != OrbState.ON) {
            if (visible) { main.removeCallbacks(pull); main.postDelayed(pull, 1000) }
            maybeAskNotifications()
        }
    }

    /**
     * Arayüz görünürken saniyede bir: canlı sayaçlar ve servisin yazdığı toplamlar. Servis kendi başına uyanmaz.
     * Servisin kendisinin değiştirdiği seçim (bildirimdeki "Sonraki", yedek sunucu) de alınır; böylece arayüz bir sonraki
     * kaydında onu eskisiyle ezmez.
     */
    private fun pullStatus() {
        val fresh = prefs.loadSettings()
        val cur = model.settings
        val next = cur.copy(
            wasActive = fresh.wasActive,
            totalQueries = fresh.totalQueries, totalHits = fresh.totalHits, totalBlocked = fresh.totalBlocked,
            totalSeconds = fresh.totalSeconds, daily = fresh.daily, totalAnswered = fresh.totalAnswered,
            totalLatencyMs = fresh.totalLatencyMs, bytesUp = fresh.bytesUp, bytesDown = fresh.bytesDown,
            usage = fresh.usage, sessions = fresh.sessions,
            lastServer = fresh.lastServer ?: cur.lastServer, recent = fresh.recent,
        )
        if (next != cur) model.replaceSettings(next)
        applyVpn(withPause(VpnStatus.snapshot()))
    }

    private fun maybeAskNotifications() {
        if (Build.VERSION.SDK_INT < 33 || prefs.askedNotifications()) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        prefs.setAskedNotifications()
        try { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ bağlan / kes

    private fun connect(serverId: String) {
        connectRequestedAt = SystemClock.elapsedRealtime()
        val consent = try { VpnService.prepare(this) } catch (_: Exception) { null }
        if (consent != null) {
            pendingServer = serverId
            try {
                startActivityForResult(consent, REQ_VPN)
            } catch (_: Exception) {
                pendingServer = null
                model.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, Strings.ERR_PERMISSION))
            }
        } else {
            startVpn(serverId)
        }
    }

    /** [serverId] boşsa servis, ağ kuralına ya da son kullanılan sunucuya bakar. */
    private fun startVpn(serverId: String?) {
        try {
            startForegroundService(DnsVpnService.connectIntent(this, serverId))
        } catch (e: Exception) {
            Journal.add("servis başlatılamadı: ${e.javaClass.simpleName}")
            model.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, Strings.ERR_UNKNOWN))
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_VPN) return
        val id = pendingServer          // etkinlik izin penceresi açıkken yeniden yaratıldıysa boştur
        pendingServer = null
        if (resultCode == RESULT_OK) {
            startVpn(id)
        } else {
            // İzin verilmedi: küre bağlanıyor durumunda kalmasın.
            connectRequestedAt = 0
            model.onVpn(VpnUi())
            model.toast(Strings.ERR_PERMISSION)
        }
    }

    /**
     * Kısayol, kutucuk, widget ve bildirimden gelen niyetler, ve "uygulama açılınca bağlan" ayarı.
     *
     * Güven: uygulamanın kendi kısayolları ve PendingIntent'leri dışa kapalı [INTERNAL_ALIAS] takma adını kullanır;
     * başka bir uygulama yalnızca (dışa açık) ana etkinliği hedefleyebilir. Dışarıdan gelen "kes" isteği hemen uygulanmaz,
     * kullanıcıya sorulur; "bağlan" isteği zararsızdır (bağlantı yine kullanıcının gözü önünde, onayıyla kurulur).
     */
    private fun handleIntent(intent: Intent?, fresh: Boolean) {
        if (!fresh) { intent?.action = null; return }
        val trusted = intent?.component?.className == INTERNAL_ALIAS
        when (intent?.action) {
            DnsVpnService.ACTION_CONNECT -> {
                val id = if (trusted) intent.getStringExtra(DnsVpnService.EXTRA_SERVER)?.takeIf { Catalog.byId(it) != null } else null
                when {
                    id != null && model.connectedId() != id -> model.tapServer(id)
                    id == null && !model.vpn.active -> model.tapOrb()
                }
            }
            DnsVpnService.ACTION_DISCONNECT -> if (model.vpn.active) {
                if (trusted) model.disconnectNow()
                else model.toast(Strings.CONFIRM_DISCONNECT, Strings.DISCONNECT) { model.disconnectNow() }
            }
            DnsVpnService.ACTION_PAUSE -> if (trusted) {
                val m = intent.getIntExtra(DnsVpnService.EXTRA_MINUTES, Notifier.PAUSE_MIN).coerceIn(1, 24 * 60)
                if (model.vpn.active) model.pause(m) else model.toast(Strings.ONLY_CONNECTED)
            }
            else -> {
                val s = model.settings
                if (s.autoConnect && s.onboarded && !model.vpn.active) model.tapOrb()
            }
        }
        // Aynı niyet yeniden işlenmesin (ör. yön değişiminde).
        intent?.action = null
    }

    // ------------------------------------------------------------------ Host

    private inner class AndroidHost : Host {
        override fun connect(serverId: String) = this@MainActivity.connect(serverId)

        override fun disconnect() {
            connectRequestedAt = 0
            sendToService(DnsVpnService.disconnectIntent(this@MainActivity)) { model.onVpn(VpnUi()) }
        }

        override fun pause(minutes: Int) {
            connectRequestedAt = 0
            sendToService(DnsVpnService.pauseIntent(this@MainActivity, minutes)) { model.onVpn(VpnUi()) }
        }

        override fun resume() {
            connectRequestedAt = SystemClock.elapsedRealtime()
            val consent = try { VpnService.prepare(this@MainActivity) } catch (_: Exception) { null }
            if (consent != null) { connect(model.selectedId()); return }
            sendToService(DnsVpnService.resumeIntent(this@MainActivity)) { model.onVpn(VpnUi()) }
        }

        override fun clearCache() {
            sendToService(DnsVpnService.clearCacheIntent(this@MainActivity)) {}
        }

        override fun runTest() {
            sendToService(DnsVpnService.testIntent(this@MainActivity)) {
                model.onTestResult(SelfTestResult(false, null, null, model.connectedId(), app.dnshizli.core.DnssecResult.UNKNOWN, app.dnshizli.core.AdBlockResult.UNKNOWN))
            }
        }

        override fun reapply() {
            if (model.vpn.active) sendToService(DnsVpnService.reapplyIntent(this@MainActivity)) {}
        }

        /** Favorilerden en çok iki tanesi uygulama simgesinin kısayollarına eklenir (üç sabit kısayolun yanına). */
        override fun updateShortcuts(serverIds: List<String>) {
            try {
                val sm = getSystemService(ShortcutManager::class.java) ?: return
                val list = serverIds.mapNotNull { Catalog.byId(it) }.take(MAX_DYNAMIC_SHORTCUTS).map { s ->
                    ShortcutInfo.Builder(this@MainActivity, "fav-" + s.id)
                        .setShortLabel(s.name.take(25))
                        .setLongLabel((Strings.CONNECT + ": " + s.name).take(40))
                        .setIcon(Icon.createWithResource(this@MainActivity, R.drawable.ic_shortcut))
                        .setIntent(Intent(DnsVpnService.ACTION_CONNECT).setClassName(this@MainActivity, INTERNAL_ALIAS)
                            .putExtra(DnsVpnService.EXTRA_SERVER, s.id))
                        .build()
                }
                sm.dynamicShortcuts = list
            } catch (_: Exception) {
                // kısayol kotası, eski başlatıcı: kısayolsuz devam
            }
        }

        override fun systemAccent(): Int? = if (Build.VERSION.SDK_INT >= 31) {
            try { resources.getColor(android.R.color.system_accent1_500, theme) } catch (_: Exception) { null }
        } else null

        override fun openBatterySettings() {
            val tries = listOf(
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
            )
            for (i in tries) { try { startActivity(i); return } catch (_: Exception) {} }
        }

        /** Android 9+: kullanıcı ya da sistem uygulamayı "arka planda kısıtlanmış" yaptıysa true. */
        override fun batteryRestricted(): Boolean? {
            if (Build.VERSION.SDK_INT < 28) return null
            return try {
                val am = getSystemService(ActivityManager::class.java) ?: return null
                am.isBackgroundRestricted
            } catch (_: Exception) { null }
        }

        private fun sendToService(i: Intent, onFail: () -> Unit) {
            // VPN izni yoksa servis önplana geçemez (Android 14+ systemExempted türü bunu ister) ve sistem uygulamayı
            // kapatır; izin yoksa zaten çalışan bir tünel de yoktur.
            val consent = try { VpnService.prepare(this@MainActivity) } catch (_: Exception) { null }
            if (consent != null) { onFail(); return }
            try {
                startForegroundService(i)
            } catch (e: Exception) {
                Journal.add("servis komutu gönderilemedi: ${e.javaClass.simpleName}")
                onFail()
            }
        }

        override fun measure(serverIds: List<String>) {
            val ex = pool ?: newProbePool().also { pool = it }
            val left = AtomicInteger(serverIds.size)
            for (id in serverIds) {
                val server = Catalog.byId(id)
                try {
                    val encrypted = model.settings.measureEncrypted
                    ex.execute {
                        // Yalnızca şifreli çalışan sunucular (Mullvad) ve "şifreli ölçüm" açıkken DoT destekleyenler DoT ile
                        // ölçülür (el sıkışma süresi sayılmaz); diğerleri düz DNS ile.
                        val r = try {
                            val dot = server?.tlsHost(Proto.DOT, 0)
                            when {
                                server == null -> null
                                dot != null && (encrypted || !server.plain) -> DnsProbe.probeTls(server.primary, dot)
                                server.plain -> DnsProbe.probe(server.primary)
                                else -> null
                            }
                        } catch (_: Exception) { null }
                        main.post {
                            if (destroyedFlag) return@post
                            model.onLatency(id, r?.best, r?.lossPct ?: 100)
                            if (left.decrementAndGet() == 0) model.onMeasureDone()
                        }
                    }
                } catch (_: Exception) {
                    // havuz kapanmış (etkinlik yok ediliyor)
                }
            }
        }

        /** En çok 4 iş parçacığı; boşta kalanlar 5 sn sonra kendiliğinden kapanır (ölçüm bitince bellekte iş parçacığı kalmaz). */
        private fun newProbePool(): ExecutorService =
            ThreadPoolExecutor(4, 4, 5L, TimeUnit.SECONDS, LinkedBlockingQueue()) { r ->
                Thread(r, "dns-probe").also { it.isDaemon = true }
            }.also { it.allowCoreThreadTimeOut(true) }

        override fun saveSettings(s: AppSettings) = prefs.saveSettings(s)
        override fun saveLatencies(m: Map<String, Latency>) = prefs.saveLatencies(m)
        override fun saveHistory(h: Map<String, List<Int?>>) = prefs.saveHistory(h)
        override fun resetTotals() = prefs.resetTotals()

        override fun readClipboard(): String? = try {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString()
        } catch (_: Exception) { null }

        private fun storeUrl(): String = "https://play.google.com/store/apps/details?id=$packageName"

        override fun shareApp() = shareText(Strings.shareAppText(storeUrl()))

        override fun rateApp() {
            val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
            try { startActivity(market) } catch (_: Exception) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl()))) } catch (_: Exception) {}
            }
        }

        override fun applyLanguage(setting: String) {
            App.applyLanguage(this@MainActivity, setting)
            App.syncSystemLocale(this@MainActivity, setting)
            prefs.setLocaleSynced()
            Notifier.ensureChannel(this@MainActivity)
            try { DnsWidget.updateAll(this@MainActivity, VpnStatus.snapshot()) } catch (_: Exception) {}
            updateShortcuts(Catalog.all.filter { it.id in model.settings.favorites }.map { it.id })
        }

        override fun copyText(text: String) {
            val cm = getSystemService(ClipboardManager::class.java) ?: return
            cm.setPrimaryClip(ClipData.newPlainText(Strings.APP, text))
        }

        override fun shareText(text: String) {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            try { startActivity(Intent.createChooser(send, null)) } catch (_: Exception) {}
        }

        override fun haptic(strong: Boolean) {
            val v = view ?: return
            val kind = when {
                !strong -> HapticFeedbackConstants.VIRTUAL_KEY
                Build.VERSION.SDK_INT >= 30 -> HapticFeedbackConstants.CONFIRM
                else -> HapticFeedbackConstants.LONG_PRESS
            }
            v.performHapticFeedback(kind)
        }

        override fun openVpnSettings() {
            try { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) {}
        }

        /** Tanılama raporu: sürüm, cihaz, önemli ayarlar (kişisel veri yok), son çökme özeti ve olay günlüğü. */
        override fun diagnostics(): String {
            val s = model.settings
            val head = "${Strings.APP} ${versionName()} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER}\n" +
                "enc=${s.encryption.id} strict=${s.strictEncryption} cache=${s.cache.id} reconnect=${s.autoReconnect} backup=${s.backupServer ?: "-"} " +
                "lang=${s.lang} theme=${s.theme}\n"
            val crash = prefs.lastCrash()?.let { "son çökme: $it\n" } ?: ""
            return head + crash + Journal.log.dump()
        }

        override fun clearDiagnostics() = Journal.log.clear()

        override fun versionName(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (_: Exception) { "1.0" }

        override fun now(): Long = System.currentTimeMillis()

        override fun requestFrame() { view?.requestFrame() }
    }

    companion object {
        private const val REQ_VPN = 1
        private const val REQ_NOTIF = 2
        private const val CONNECT_GRACE_MS = 4000L
        private const val MAX_DYNAMIC_SHORTCUTS = 2

        /**
         * Dışa kapalı takma ad (activity-alias): uygulamanın kendi kısayolları, bildirimleri, widget'ı ve kutucuğu bunu
         * hedefler. Bu adla gelen niyetlere güvenilir; başka uygulamalar bu adı başlatamaz.
         */
        const val INTERNAL_ALIAS = "app.dnshizli.platform.InternalLaunch"
    }
}
