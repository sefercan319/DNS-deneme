package app.dnshizli.platform

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.widget.RemoteViews
import app.dnshizli.R
import app.dnshizli.core.Catalog
import app.dnshizli.core.DailyStats
import app.dnshizli.core.Format
import app.dnshizli.core.OrbState
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi

/**
 * Ana ekran widget'ı (1×1 / 2×1): cam küre simgesi, durum ve sunucu adı. Dokununca bağlanır ya da keser.
 * Hiç zamanlayıcısı yoktur: yalnızca servis durum yayınladığında güncellenir (updatePeriodMillis = 0).
 */
class DnsWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, manager: AppWidgetManager, ids: IntArray) {
        App.applyLanguage(ctx, PrefsStore(ctx).loadSettings().lang)
        val ui = VpnStatus.snapshot()
        for (id in ids) manager.updateAppWidget(id, views(ctx, ui))
    }

    companion object {
        const val ACTION_TOGGLE = "app.dnshizli.WIDGET_TOGGLE"

        fun views(ctx: Context, ui: VpnUi): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_dns)
            val on = ui.state == OrbState.ON
            val status = when (ui.state) {
                OrbState.ON -> Strings.ON
                OrbState.CONNECTING -> Strings.CONNECTING
                OrbState.ERROR -> Strings.ERROR
                OrbState.OFF -> if (ui.pausedUntil > System.currentTimeMillis()) Strings.PAUSED else Strings.OFF
            }
            val settings = PrefsStore(ctx).loadSettings()
            val name = Catalog.byId(ui.serverId ?: settings.lastServer)?.name ?: Catalog.default.name
            v.setTextViewText(R.id.widget_status, status)
            v.setTextViewText(R.id.widget_server, if (on && ui.proto != null) name + " · " + Strings.protoName(ui.proto) else name)
            // Bugünün sorgu sayısı (servis dakikada bir aktarır) — widget'ın kendi zamanlayıcısı yoktur.
            val today = DailyStats.decode(settings.daily)[DailyStats.today(System.currentTimeMillis())] ?: 0L
            v.setTextViewText(R.id.widget_today, Strings.widgetToday(Format.count(today)))
            v.setImageViewResource(R.id.widget_orb, if (on) R.drawable.widget_orb_on else R.drawable.widget_orb_off)
            v.setContentDescription(R.id.widget_root, Strings.APP + ": " + status + ". " + Strings.WIDGET_TAP)
            // Bağlanmaya hazırsa (bilgilendirme kabul edilmiş, VPN izni var) dokunuş doğrudan servisi açıp kapatır;
            // değilse uygulamayı açar (izin penceresi ancak orada gösterilebilir).
            val ready = ui.active || (settings.onboarded &&
                try { VpnService.prepare(ctx) == null } catch (_: Exception) { false })
            val tap = if (ready) PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, WidgetToggleReceiver::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ) else PendingIntent.getActivity(
                ctx, 7, Notifier.appIntent(ctx, DnsVpnService.ACTION_CONNECT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            v.setOnClickPendingIntent(R.id.widget_root, tap)
            return v
        }

        /** Servis durum yayınladığında çağrılır. Ekranda widget yoksa hiçbir şey yapmaz. */
        fun updateAll(ctx: Context, ui: VpnUi) {
            val m = AppWidgetManager.getInstance(ctx) ?: return
            val ids = m.getAppWidgetIds(ComponentName(ctx, DnsWidget::class.java))
            if (ids.isEmpty()) return
            val v = views(ctx, ui)
            for (id in ids) m.updateAppWidget(id, v)
        }
    }
}

/**
 * Widget dokunuşu: yalnızca kendi widget'ımızın PendingIntent'iyle tetiklenir (dışa kapalı alıcı; başka uygulamalar
 * VPN'i açıp kapatamaz).
 */
class WidgetToggleReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != DnsWidget.ACTION_TOGGLE) return
        val ui = VpnStatus.snapshot()
        try {
            if (VpnService.prepare(ctx) != null) {
                // VPN izni yok: arka plandan etkinlik başlatmak çoğu sürümde engellenir; uygulamayı açtıran bildirim gösterilir.
                App.applyLanguage(ctx, PrefsStore(ctx).loadSettings().lang)
                Notifier.needApp(ctx)
                return
            }
            ctx.startForegroundService(if (ui.active) DnsVpnService.disconnectIntent(ctx) else DnsVpnService.connectIntent(ctx, null))
        } catch (_: Exception) {
            // başlatılamadı: kullanıcı uygulamayı açıp elle bağlanır
        }
    }
}
