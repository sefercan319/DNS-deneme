package app.dnshizli.ui

import app.dnshizli.core.AeroArt
import app.dnshizli.core.AeroTheme
import app.dnshizli.core.BubbleField
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.Gfx
import app.dnshizli.core.Rgb
import app.dnshizli.core.TextMetrics
import app.dnshizli.core.Themes
import kotlin.math.abs
import kotlin.math.sin

/** Gökyüzü zemini ve yükselen kabarcıklar. */
class SkyNode : Node() {
    private val field = BubbleField(11L)
    private var count = -1

    fun setCount(n: Int) { if (n != count) { count = n; field.setCount(n) } }
    fun update(dt: Float) { field.update(dt, 1f) }

    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        art.sky(g, env.width, env.height)
        val items = field.items
        for (i in 0 until items.size) { val b = items[i]; art.bubble(g, b.x * env.width + sin(b.phase) * b.sway, b.y * env.height, b.r, b.alpha * 0.9f) }
    }
}

/**
 * Tüm arayüzün kökü: sayfa yığını, alt panel, bildirim, gökyüzü, tema geçişi, dokunma ve kaydırma yönlendirmesi.
 * Android'e bağlı değildir. Ev sahibi (SceneView) yalnızca şunları yapar: [resize], [tick] + [draw], [touch], [back]
 * ve erişilebilirlik için [a11yItems]. Böylece aynı kod JVM testlerinde ve önizleme görsellerinde çalışır.
 */
class Scene(val model: AppModel, metrics: TextMetrics) : Nav {
    val env = Env(model, metrics)

    private val sky = SkyNode()
    private val pages = ArrayList<Node>()
    private var sheet: Sheet? = null
    private var sheetIsConsent = false
    private val toast = ToastNode()
    private var seenToast = 0

    // sayfa geçişi
    private val trans = Anim(1f)
    private var leaving: Node? = null
    private var entering: Node? = null
    private var popping = false

    // tema geçişi
    private var themeFrom: AeroTheme = Themes.aqua
    private var themeTo: AeroTheme = Themes.aqua
    private val morph = Anim(1f)
    private var systemDark = false
    private var systemMotion = true

    private var lastNow = -1L
    private var started = false

    var width = 0f
        private set
    var height = 0f
        private set

    init {
        pages.add(HomePage(model, this))
        syncSettings(true)
        env.theme = themeTo
        env.art = AeroArt(env.theme, model.settings.glass)
    }

    // ------------------------------------------------------------------ yapılandırma

    fun setSystemDark(v: Boolean) { systemDark = v; syncSettings(false) }

    /** Sistem animasyon ölçeği 0 ise (erişilebilirlik) false verin. */
    fun setSystemMotion(v: Boolean) { systemMotion = v; syncSettings(false) }

    fun setFontScale(f: Float) {
        val v = f.coerceIn(1f, 1.3f)
        if (v == env.fs) return
        env.fs = v
        if (width > 0f) layoutAll()
    }

    fun resize(w: Float, h: Float, insetTop: Float, insetBottom: Float) {
        width = w; height = h
        env.width = w; env.height = h
        env.insetTop = insetTop; env.insetBottom = insetBottom
        layoutAll()
    }

    private fun layoutAll() {
        for (p in pages) { p.x = 0f; p.y = 0f; p.layout(env, width); p.h = height }
        sheet?.layoutSheet(env)
        toast.screenW = width; toast.screenH = height
        toast.relayout(env)
    }

    private fun syncSettings(initial: Boolean) {
        val s = model.settings
        val sysOk = systemMotion
        val eff = s.effectiveMotion
        env.motion = if (sysOk) eff.scale else 0f
        env.ambient = sysOk && eff.scale > 0f
        sky.setCount(s.effectiveBubbles.count)
        val target = Themes.resolve(s.theme, systemDark)
        if (target.id != themeTo.id) {
            themeFrom = if (initial) target else env.theme
            themeTo = target
            if (initial || env.motion <= 0f) { morph.set(1f); env.theme = target }
            else { morph.set(0f); morph.go(1f, env.dur(0.6f), Ease.IN_OUT) }
        }
        if (env.art.glass != s.glass || env.art.theme !== env.theme) env.art = AeroArt(env.theme, s.glass)
    }

    // ------------------------------------------------------------------ zaman

    /**
     * Bir kare ilerlet. @return bir sonraki kareye kadar önerilen gecikme (ms): 16 = etkileşimli animasyon,
     * 33 = yalnızca süs animasyonu, -1 = hiç kare gerekmiyor (ekran durağan).
     */
    fun tick(nowMs: Long): Long {
        val dt = if (lastNow < 0) 0.016f else ((nowMs - lastNow) / 1000f).coerceIn(0.001f, 0.05f)
        lastNow = nowMs
        started = true
        env.time += dt

        syncSettings(false)
        model.watchdog()

        // tema geçişi
        var active = morph.step(dt)
        if (themeFrom.id != themeTo.id || morph.active) {
            env.theme = if (morph.value >= 1f) themeTo else AeroTheme.lerp(themeFrom, themeTo, morph.value)
        }
        if (env.art.glass != model.settings.glass || env.art.theme !== env.theme) env.art = AeroArt(env.theme, model.settings.glass)

        // modelden gelen olaylar
        if (model.toastSeq != seenToast) { seenToast = model.toastSeq; model.toast?.let { toast.show(env, it) } }
        if (model.consentOpen && sheet == null) openConsent()
        if (!model.consentOpen && sheetIsConsent) sheet?.close(env)

        // sayfa geçişi
        if (trans.step(dt)) active = true
        else if (popping && leaving != null) { pages.remove(leaving); leaving = null; entering = null; popping = false }
        else if (!trans.active) { leaving = null; entering = null }

        // sayfalar
        val top = pages.last()
        if (top.tick(dt, env)) active = true
        val other = if (leaving != null && leaving !== top) leaving else if (entering != null && entering !== top) entering else null
        if (other != null && other.tick(dt, env)) active = true

        // alt panel
        val sh = sheet
        if (sh != null) {
            if (sh.tick(dt, env)) active = true
            if (sh.finished) { sheet = null; sheetIsConsent = false }
        }
        if (toast.tick(dt, env)) active = true
        if (scrollingNow()) active = true

        // gökyüzü
        if (env.ambient) sky.update(dt)

        checkLongPress(nowMs)

        if (active || pressed != null) return 16
        if (toast.active) return 33   // bildirimin kapanma geri sayımı (hareket kapalıyken de sürer)
        if (env.ambient && (ambientActive() || bubblesVisible())) return 33
        return -1
    }

    /** Bir bildirim görünüyor (ya da kapanıyor) mu? */
    val toastActive: Boolean get() = toast.active

    private fun bubblesVisible(): Boolean = model.settings.effectiveBubbles.count > 0

    private fun ambientActive(): Boolean {
        if (pages.last().ambient(env)) return true
        val o = if (leaving != null) leaving else entering
        return o != null && o.ambient(env)
    }

    private fun scrollingNow(): Boolean = scrolling != null

    // ------------------------------------------------------------------ çizim

    fun draw(g: Gfx) {
        sky.draw(g, env)
        val top = pages.last()
        if (!trans.active || (leaving == null && entering == null)) {
            top.draw(g, env)
        } else {
            val p = trans.value
            val shift = width * 0.20f
            if (!popping) {
                // yeni sayfa sağdan kayarak girer, eskisi hafifçe sola çekilip solar
                val old = leaving ?: pages[pages.size - 2]
                drawPage(g, old, 1f - 0.5f * p, -28f * p)
                drawPage(g, top, p, (1f - p) * shift)
            } else {
                val below = entering ?: pages[pages.size - 2]
                drawPage(g, below, 0.5f + 0.5f * p, -28f * (1f - p))
                drawPage(g, leaving ?: top, 1f - p, p * shift)
            }
        }
        sheet?.draw(g, env)
        if (toast.active) { g.save(); g.translate(toast.x, toast.y); toast.draw(g, env); g.restore() }
    }

    private fun drawPage(g: Gfx, n: Node, alpha: Float, dx: Float) {
        g.save()
        g.alpha(Easing.clamp01(alpha))
        g.translate(dx, 0f)
        n.draw(g, env)
        g.restore()
    }

    // ------------------------------------------------------------------ gezinti

    private fun top(): Node = pages.last()

    private fun push(p: Node) {
        p.x = 0f; p.y = 0f
        p.layout(env, width); p.h = height
        val from = pages.last()
        pages.add(p)
        if (env.motion <= 0f) return
        leaving = from
        entering = p
        popping = false
        trans.set(0f)
        trans.go(1f, env.dur(0.34f), Ease.OUT)
    }

    override fun openSettings() { if (!transitioning()) push(SettingsPage(model, this)) }
    override fun openLog() { if (!transitioning()) push(LogPage(model, this)) }
    override fun openHelp() { if (!transitioning()) push(HelpPage(this)) }

    override fun back() { goBack() }

    /** Geri: önce alt panel, sonra sayfa. @return olay tüketildiyse true; false ise etkinlik kapanmalı. */
    fun goBack(): Boolean {
        val sh = sheet
        if (sh != null) {
            if (!sh.closing) { if (sheetIsConsent) model.dismissConsent(); sh.close(env) }
            return true
        }
        if (transitioning()) return true
        if (pages.size > 1) {
            if (env.motion <= 0f) { pages.removeAt(pages.size - 1); return true }
            leaving = pages.last()
            entering = pages[pages.size - 2]
            popping = true
            trans.set(0f)
            trans.go(1f, env.dur(0.30f), Ease.OUT)
            return true
        }
        return false
    }

    fun transitioning(): Boolean = trans.active

    /**
     * Geri tuşu bir şey tüketecek mi (alt panel açık, alt sayfadayız ya da geçiş sürüyor)? [goBack] ile aynı kural.
     * false ise etkinlik sistemin kendi geri davranışına (uygulamadan çıkış) bırakılır.
     */
    val canGoBack: Boolean get() = sheet != null || pages.size > 1 || trans.active

    val pageCount: Int get() = pages.size

    /** En üstteki sayfa (test ve a11y için). */
    val currentPage: Node get() = pages.last()

    val hasSheet: Boolean get() = sheet != null

    private fun showSheet(content: Column, consent: Boolean) {
        sheet?.let { if (!it.closing) it.close(env) }
        val s = Sheet(content) { if (consent) model.dismissConsent(); closeSheet() }
        sheet = s
        sheetIsConsent = consent
        s.layoutSheet(env)
        s.show(env)
        // Sheet kapanış animasyonu sürerken yenisi açılırsa eskisi yok edilir.
    }

    fun closeSheet() { sheet?.close(env) }

    override fun openDetails(server: DnsServer) {
        showSheet(DetailsContent(server, model) { closeSheet() }, false)
    }

    override fun openChoice(title: String, current: String?, onPick: (String?) -> Unit) {
        showSheet(ChoiceContent(title, current, onPick) { closeSheet() }, false)
    }

    private fun openConsent() {
        showSheet(ConsentContent(model) { model.dismissConsent(); closeSheet() }, true)
    }

    // ------------------------------------------------------------------ dokunma

    private var pressed: Node? = null
    private var chain: List<Scrollable> = emptyList()
    private var scrolling: Scrollable? = null
    private var downX = 0f
    private var downY = 0f
    private var lastPos = 0f
    private var downT = 0L
    private var longFired = false
    private var moved = false
    private val vtT = FloatArray(8)
    private val vtP = FloatArray(8)
    private var vtN = 0
    private var t0 = -1L

    private fun vtAdd(tMs: Long, p: Float) {
        if (t0 < 0) t0 = tMs
        val t = (tMs - t0) / 1000f
        if (vtN == vtT.size) {
            for (i in 1 until vtN) { vtT[i - 1] = vtT[i]; vtP[i - 1] = vtP[i] }
            vtN--
        }
        vtT[vtN] = t; vtP[vtN] = p; vtN++
    }

    private fun vtVelocity(): Float {
        if (vtN < 2) return 0f
        val last = vtN - 1
        var first = last
        while (first > 0 && vtT[last] - vtT[first - 1] < 0.12f) first--
        val dt = vtT[last] - vtT[first]
        if (dt < 0.004f) return 0f
        return (vtP[last] - vtP[first]) / dt
    }

    private fun layer(): Node = sheet ?: top()

    private fun hitAt(x: Float, y: Float): Node? {
        if (toast.active) toast.hit(x - toast.x, y - toast.y)?.let { return it }
        return layer().hit(x, y)
    }

    /** Dokunma olayı. [action]: [DOWN], [MOVE], [UP], [CANCEL]. Koordinatlar dp, [tMs] olay zamanı. */
    fun touch(action: Int, x: Float, y: Float, tMs: Long) {
        when (action) {
            DOWN -> onDown(x, y, tMs)
            MOVE -> onMove(x, y, tMs)
            UP -> onUp(x, y, tMs)
            else -> onCancelTouch()
        }
    }

    private fun onDown(x: Float, y: Float, tMs: Long) {
        onCancelTouch()
        if (transitioning()) return
        val deep = layer().hitScrollable(x, y)
        val list = ArrayList<Scrollable>(2)
        var n: Node? = deep
        while (n != null) { if (n is Scrollable) list.add(n); n = n.parent }
        chain = list
        var wasMoving = false
        for (s in list) if (s.stopScroll()) wasMoving = true
        // Kayan listeye dokunmak yalnızca durdurur; parmak kalkınca bir satıra basılmış sayılmaz.
        val t = if (wasMoving) null else hitAt(x, y)
        pressed = t
        downX = x; downY = y; downT = tMs
        longFired = false; moved = false
        vtN = 0; t0 = -1L
        t?.onDown(x - t.absX(), y - t.absY(), env)
        model.host.requestFrame()
    }

    private fun onMove(x: Float, y: Float, tMs: Long) {
        val sc = scrolling
        if (sc != null) {
            sc.dragBy(y - lastPos)
            lastPos = y
            vtAdd(tMs, y)
            model.host.requestFrame()
            return
        }
        val p = pressed
        if (p != null && p.dragCapture && p.dragActive) {
            p.onDrag(x - p.absX(), y - p.absY(), env)
            model.host.requestFrame()
            return
        }
        val dx = x - downX
        val dy = y - downY
        if (abs(dx) > SLOP || abs(dy) > SLOP) {
            moved = true
            val horiz = abs(dx) > abs(dy)
            if (p != null && p.dragCapture && horiz) {
                p.onDragStart(x - p.absX(), y - p.absY(), env)
                p.onDrag(x - p.absX(), y - p.absY(), env)
                model.host.requestFrame()
                return
            }
            val s = if (horiz) null else chain.firstOrNull { it.canScroll }
            if (s != null) {
                p?.onCancel(env)
                pressed = null
                scrolling = s
                val sign = if (y >= downY) 1f else -1f
                lastPos = downY + sign * SLOP
                s.dragBy(y - lastPos)
                lastPos = y
                vtN = 0; t0 = -1L
                vtAdd(tMs, y)
            } else if (p != null && !p.contains(x - p.absX(), y - p.absY())) {
                p.onCancel(env)
                pressed = null
            }
        }
        model.host.requestFrame()
    }

    private fun onUp(x: Float, y: Float, tMs: Long) {
        val sc = scrolling
        if (sc != null) {
            vtAdd(tMs, y)   // parmak son konumunda durduysa hız sıfıra iner (durup bırakınca fırlatma olmaz)
            sc.flingBy(vtVelocity())
            scrolling = null
            model.host.requestFrame()
            return
        }
        val p = pressed
        pressed = null
        if (p != null) {
            val lx = x - p.absX()
            val ly = y - p.absY()
            val inside = p.contains(lx, ly)
            p.onUp(lx, ly, inside && !longFired, env)
        }
        model.host.requestFrame()
    }

    private fun onCancelTouch() {
        pressed?.onCancel(env)
        pressed = null
        scrolling = null
    }

    private fun checkLongPress(nowMs: Long) {
        val p = pressed ?: return
        if (longFired || moved || !p.longPressable) return
        if (nowMs - downT >= LONG_MS) {
            longFired = true
            p.onLongPress(env)
        }
    }

    // ------------------------------------------------------------------ erişilebilirlik

    /** Ekranda görünen, etiketli düğümler (yukarıdan aşağıya, soldan sağa). */
    fun a11yItems(): List<A11yItem> {
        val out = ArrayList<A11yItem>()
        if (sheet != null && !sheet!!.closing) {
            sheet!!.collectA11y(out, 0f, 0f, 0f, height)
        } else {
            top().collectA11y(out, 0f, 0f, 0f, height)
        }
        if (toast.active) toast.collectA11y(out, toast.x, toast.y, 0f, height)
        out.sortWith(compareBy<A11yItem>({ (it.t / 6f).toInt() }, { it.l }))
        return out
    }

    private fun findScroll(n: Node): ScrollView? {
        if (!n.visible) return null
        if (n is ScrollView) return n
        for (k in n.children) findScroll(k)?.let { return it }
        return null
    }

    private fun a11yScrollView(): ScrollView? {
        val sh = sheet
        return findScroll(if (sh != null && !sh.closing) sh else top())
    }

    /** TalkBack'in ileri/geri kaydır eylemi mümkün mü? */
    fun a11yCanScroll(forward: Boolean): Boolean {
        val sv = a11yScrollView() ?: return false
        return if (forward) sv.offset < sv.maxOffset - 0.5f else sv.offset > 0.5f
    }

    /** Görünür alanın yaklaşık %80'i kadar kaydırır. @return konum değiştiyse true. */
    fun a11yScroll(forward: Boolean): Boolean {
        val sv = a11yScrollView() ?: return false
        val before = sv.offset
        sv.scrollTo(before + (if (forward) 1f else -1f) * sv.h * 0.8f)
        model.host.requestFrame()
        return sv.offset != before
    }

    fun a11yClick(item: A11yItem) { item.node.a11yClick(env); model.host.requestFrame() }
    fun a11yLongClick(item: A11yItem): Boolean { val r = item.node.onLongPress(env); model.host.requestFrame(); return r }
    fun a11yAdjust(item: A11yItem, dir: Int) { item.node.a11yAdjust(dir, env); model.host.requestFrame() }

    companion object {
        const val DOWN = 0
        const val MOVE = 1
        const val UP = 2
        const val CANCEL = 3
        const val SLOP = 8f
        const val LONG_MS = 450L
    }
}
