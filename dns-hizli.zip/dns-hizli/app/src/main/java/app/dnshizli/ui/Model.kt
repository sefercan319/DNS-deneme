package app.dnshizli.ui

import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Format
import app.dnshizli.core.Latency
import app.dnshizli.core.NetKind
import app.dnshizli.core.OrbState
import app.dnshizli.core.ServerList
import app.dnshizli.core.Tag

/** Liste süzgeçleri (üstteki çipler). */
enum class Filter(val label: String, val tag: Tag?) {
    ALL(Strings.FILTER_ALL, null),
    FAVORITES(Strings.FILTER_FAV, null),
    FAST(Tag.FAST.label, Tag.FAST),
    PRIVACY(Tag.PRIVACY.label, Tag.PRIVACY),
    ADS(Tag.ADS.label, Tag.ADS),
    FAMILY(Tag.FAMILY.label, Tag.FAMILY),
    SECURITY(Tag.SECURITY.label, Tag.SECURITY),
}

/** Arayüzün gördüğü VPN durumu. Servis bunu üretir, etkinlik modele iletir. */
data class VpnUi(
    val state: OrbState = OrbState.OFF,
    val serverId: String? = null,
    val sinceMs: Long = 0L,
    val queries: Long = 0L,
    val cacheHits: Long = 0L,
    val avgMs: Int = 0,
    val error: String? = null,
    val onBackup: Boolean = false,
) {
    val active: Boolean get() = state == OrbState.ON || state == OrbState.CONNECTING
}

/** Geçici kısa mesaj (alt kısımda cam hap). [action] doluysa yanında dokunulabilir bir eylem olur. */
class ToastMsg(val text: String, val action: String? = null, val onAction: (() -> Unit)? = null)

/**
 * Platformun (Android) arayüze sunduğu yetenekler. Testlerde sahte bir uygulaması kullanılır.
 * Tüm çağrılar ve [AppModel]'in tüm metotları ana (arayüz) iş parçacığında çalışır.
 */
interface Host {
    /** [serverId] sunucusuna bağlan; zaten bağlıysa tüneli koparmadan sunucuyu değiştir. Durum [AppModel.onVpn] ile döner. */
    fun connect(serverId: String)
    fun disconnect()

    /** Listedeki sunucuların gecikmesini arka planda ölç; her sonuç [AppModel.onLatency], bitiş [AppModel.onMeasureDone] ile döner. */
    fun measure(serverIds: List<String>)

    fun saveSettings(s: AppSettings)
    fun saveLatencies(m: Map<String, Latency>)
    fun copyText(text: String)
    fun shareText(text: String)
    fun haptic(strong: Boolean)
    fun openVpnSettings()
    fun diagnostics(): String
    fun clearDiagnostics()
    fun versionName(): String
    fun now(): Long
    fun requestFrame()
}

/**
 * Uygulamanın tüm durumu ve kuralları. Arayüzden bağımsızdır: dokunma eylemleri burada anlam kazanır,
 * sahne yalnızca [version] değişince kendini günceller. Bu sayede her şey JVM'de test edilebilir.
 */
class AppModel(val host: Host, settings: AppSettings, latencies: Map<String, Latency> = emptyMap()) {
    var settings: AppSettings = settings
        private set
    var vpn: VpnUi = VpnUi()
        private set
    val latencies: MutableMap<String, Latency> = LinkedHashMap(latencies)
    var filter: Filter = Filter.ALL
        private set
    var measuring: Boolean = false
        private set
    var consentOpen: Boolean = false
        private set
    var toast: ToastMsg? = null
        private set

    /** Her görünür değişimde artar; sahne bunu izleyip yeniden kurulur. */
    var version: Int = 0
        private set

    /** Her yeni geçici mesajda artar. */
    var toastSeq: Int = 0
        private set

    private var pendingConnect: String? = null
    private var measureRemaining = 0
    private var measureStart = 0L

    /** Bağlıyken istenen ama platformun henüz bildirmediği geçiş hedefi: çift dokunmada ikinci çağrıyı eler. */
    private var switchingTo: String? = null
    private var switchAt = 0L

    private fun bump() { version++; host.requestFrame() }

    // ------------------------------------------------------------------ okuma

    fun selectedId(): String = settings.lastServer ?: Catalog.DEFAULT_ID

    fun server(id: String?): DnsServer? = id?.let { Catalog.byId(it) }

    fun nameOf(id: String?): String = server(id)?.name ?: Catalog.default.name

    /** Şu an bağlı (veya bağlanmakta) sunucunun kimliği; yoksa null. */
    fun connectedId(): String? = if (vpn.active) (vpn.serverId ?: selectedId()) else null

    fun visibleServers(): List<DnsServer> {
        val base = if (filter == Filter.FAVORITES) Catalog.all.filter { it.id in settings.favorites } else Catalog.all
        return ServerList.visible(base, filter.tag, settings.favorites, latencies, settings.sortBySpeed)
    }

    fun statusTitle(): String = when (vpn.state) {
        OrbState.OFF -> Strings.OFF
        OrbState.CONNECTING -> Strings.CONNECTING
        OrbState.ON -> Strings.ON
        OrbState.ERROR -> Strings.ERROR
    }

    fun statusSub(): String = when (vpn.state) {
        OrbState.OFF -> Strings.selected(nameOf(selectedId()))
        OrbState.CONNECTING -> nameOf(vpn.serverId ?: selectedId())
        OrbState.ON -> Strings.onLine(nameOf(vpn.serverId ?: selectedId()), vpn.avgMs.takeIf { it > 0 })
        OrbState.ERROR -> vpn.error ?: Strings.ERR_DEFAULT
    }

    fun statusHint(): String = when (vpn.state) {
        OrbState.OFF -> Strings.HINT_OFF
        OrbState.CONNECTING -> Strings.HINT_CONNECTING
        OrbState.ON -> {
            val secs = ((host.now() - vpn.sinceMs) / 1000).coerceAtLeast(0)
            val pct = if (vpn.queries > 0) (vpn.cacheHits * 100 / vpn.queries).toInt().coerceIn(0, 100) else 0
            Strings.statsLine(secs, vpn.queries, pct)
        }
        OrbState.ERROR -> Strings.HINT_ERROR
    }

    // ------------------------------------------------------------------ eylemler (kullanıcı)

    /** Küreye dokunuldu: bağlıysa kes, değilse seçili sunucuya bağlan. */
    fun tapOrb() {
        if (vpn.active) {
            switchingTo = null
            host.disconnect()
            toast(Strings.DISCONNECTED)
        } else {
            requestConnect(selectedId())
        }
    }

    /** Listedeki bir sunucuya dokunuldu: ona bağlan (bağlıysa kesintisiz geç). */
    fun tapServer(id: String) {
        if (Catalog.byId(id) == null) return
        if (vpn.active && vpn.serverId == id) return
        if (vpn.active && switchingTo == id && host.now() - switchAt < SWITCH_GRACE_MS) return
        requestConnect(id)
        if (vpn.active && vpn.serverId != id) toast(Strings.switched(nameOf(id)))
    }

    private fun requestConnect(id: String) {
        if (!settings.onboarded) {
            pendingConnect = id
            consentOpen = true
            bump()
            return
        }
        doConnect(id)
    }

    private fun doConnect(id: String) {
        settings = settings.copy(lastServer = id)
        host.saveSettings(settings)
        if (vpn.active) { switchingTo = id; switchAt = host.now() }
        else {
            switchingTo = null
            vpn = vpn.copy(state = OrbState.CONNECTING, serverId = id, error = null, sinceMs = host.now(), onBackup = false)
        }
        host.connect(id)
        bump()
    }

    fun acceptConsent() {
        consentOpen = false
        settings = settings.copy(onboarded = true)
        host.saveSettings(settings)
        val id = pendingConnect
        pendingConnect = null
        if (id != null) doConnect(id) else bump()
    }

    fun dismissConsent() {
        consentOpen = false
        pendingConnect = null
        bump()
    }

    fun setFilter(f: Filter) {
        if (filter == f) return
        filter = f
        bump()
    }

    fun toggleFavorite(id: String) {
        if (Catalog.byId(id) == null) return
        val fav = settings.favorites
        update { it.copy(favorites = if (id in fav) fav - id else fav + id) }
    }

    fun toggleSort() = update { it.copy(sortBySpeed = !it.sortBySpeed) }

    /** Tüm sunucuların hızını ölç. Zaten ölçülüyorsa yok sayılır. */
    fun measureAll() = measure(Catalog.all.map { it.id })

    fun measure(ids: List<String>) {
        if (measuring || ids.isEmpty()) return
        measuring = true
        measureStart = host.now()
        measureRemaining = ids.size
        host.measure(ids)
        bump()
    }

    /** Ölçülmüş en hızlı sunucuya bağlan. */
    fun connectFastest() {
        val best = ServerList.fastest(Catalog.all, latencies)
        if (best == null) toast(Strings.MEASURE_FIRST) else tapServer(best.first.id)
    }

    /** Ayarı değiştir ve kaydet. Tüm ayar kontrolleri bunu kullanır. */
    fun update(change: (AppSettings) -> AppSettings) {
        val next = change(settings)
        if (next == settings) return
        settings = next
        host.saveSettings(settings)
        bump()
    }

    fun copy(text: String) {
        host.copyText(text)
        toast(Strings.COPIED)
    }

    fun toast(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
        if (text.isBlank()) return
        toast = ToastMsg(text, action, onAction)
        toastSeq++
        bump()
    }

    /** Platform ölçümün bittiğini bildirmezse dönen gösterge sonsuza dek sürmesin. Sahne her karede çağırır. */
    fun watchdog() {
        if (measuring && host.now() - measureStart > MEASURE_TIMEOUT_MS) onMeasureDone()
    }

    // ------------------------------------------------------------------ platformdan gelenler

    fun onVpn(v: VpnUi) {
        val old = vpn
        vpn = v
        if (!v.active || v.serverId == switchingTo) switchingTo = null
        if (v.state != old.state && settings.haptics && (v.state == OrbState.ON || v.state == OrbState.ERROR)) host.haptic(true)
        if (v.state == OrbState.ON && v.onBackup && !old.onBackup) toast(Strings.BACKUP)
        // Bağlıyken bir işlem (ör. sunucu değiştirme) başarısız olduysa servis nedenini bir kez bildirir.
        if (v.state == OrbState.ON && v.error != null && v.error != old.error) toast(v.error)
        bump()
    }

    fun onLatency(id: String, ms: Int?) {
        if (Catalog.byId(id) == null) return
        latencies[id] = Latency(ms, host.now())
        if (measureRemaining > 0) measureRemaining--
        bump()
    }

    fun onMeasureDone() {
        if (!measuring) return
        measuring = false
        measureRemaining = 0
        host.saveLatencies(latencies)
        val best = ServerList.fastest(Catalog.all, latencies)
        if (best == null) toast(Strings.NO_REPLY)
        else toast(Strings.fastest(best.first.name, best.second), Strings.CONNECT) { tapServer(best.first.id) }
        bump()
    }

    /** Depolamadan okunan ayarları (ör. servisin yazdığı toplamlar) modele al; yeniden kaydetmez. */
    fun replaceSettings(s: AppSettings) {
        if (s == settings) return
        settings = s
        bump()
    }

    // ------------------------------------------------------------------ gösterim yardımcıları

    fun latencyText(id: String): String? {
        val l = latencies[id] ?: return null
        return l.ms?.let { Format.ms(it) } ?: "—"
    }

    fun hitPercentTotal(): Int {
        val q = settings.totalQueries
        return if (q > 0) (settings.totalHits * 100 / q).toInt().coerceIn(0, 100) else 0
    }

    companion object {
        /** Aynı sunucuya art arda dokunmanın ikinci çağrı sayılmayacağı süre. */
        const val SWITCH_GRACE_MS = 2500L

        /** Tüm sunucuların ölçümü için üst süre. */
        const val MEASURE_TIMEOUT_MS = 60_000L
    }
}
