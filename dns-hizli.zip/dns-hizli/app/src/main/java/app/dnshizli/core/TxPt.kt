package app.dnshizli.core

/** Português (forma neutra, legível no Brasil e em Portugal). */
object TxPt : Tx() {
    override val lang = Lang.PT

    override val decimalSep = ','
    override val thousand = " mil"
    override val million = " mi"
    override fun percent(n: Int) = "$n%"
    override val dayU = "d"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "agora mesmo"
    override fun ago(span: String) = "há $span"

    override val OFF = "Desconectado"
    override val CONNECTING = "Conectando…"
    override val ON = "Conectado"
    override val ERROR = "Falha ao conectar"
    override val PAUSED = "Em pausa"
    override val HINT_OFF = "Toque na esfera para conectar"
    override val HINT_CONNECTING = "Pode levar alguns segundos"
    override val HINT_ERROR = "Toque para tentar de novo"
    override val HINT_PAUSED = "Toque para retomar agora"
    override val ERR_DEFAULT = "Não foi possível conectar"
    override fun selected(name: String) = "$name selecionado"
    override fun pausedUntil(time: String) = "Retoma às $time"
    override fun blockedShort(n: String) = "$n bloqueadas"
    override fun queriesShort(n: String) = "$n consultas"
    override fun cacheShort(pct: String) = "$pct em cache"

    override val SERVERS = "Servidores"
    override val FILTER_ALL = "Todos"
    override val FILTER_FAV = "Favoritos"
    override val FILTER_RECENT = "Recentes"
    override val EMPTY_FAV = "Ainda não há favoritos. Toque na estrela de um servidor."
    override val EMPTY_RECENT = "Você ainda não se conectou a nenhum servidor."
    override val EMPTY_FILTER = "Não há servidores nesta categoria."
    override val MEASURE = "Medir velocidades"
    override val MEASURING = "Medindo…"
    override val SORT = "Ordenar por velocidade"
    override val PULL_TO_MEASURE = "Puxe para medir"
    override val RELEASE_TO_MEASURE = "Solte para medir"
    override fun serversCount(n: Int) = if (n == 1) "1 servidor" else "$n servidores"
    override val TAG_FAST = "Rápido"
    override val TAG_PRIVACY = "Privacidade"
    override val TAG_ADS = "Anúncios"
    override val TAG_FAMILY = "Família"
    override val TAG_SECURITY = "Segurança"
    override val VAR_OPEN = "Sem filtro"
    override val VAR_ADS = "Sem anúncios"
    override val VAR_SECURITY = "Segurança"
    override val VAR_FAMILY = "Família"
    override val A11Y_CONNECTED = "conectado"
    override val A11Y_ENCRYPTED = "criptografado"
    override fun favA11y(name: String) = "$name favorito"

    override val COPIED = "Copiado para a área de transferência"
    override val DISCONNECTED = "Desconectado"
    override val BACKUP = "Mudou para o servidor reserva"
    override val NO_REPLY = "Nenhum servidor respondeu"
    override val MEASURE_FIRST = "Meça as velocidades primeiro"
    override val CONNECT = "Conectar"
    override val UNDO = "Desfazer"
    override fun fastest(name: String, ms: Int) = "Mais rápido: $name · $ms ms"
    override fun switched(name: String) = "Mudando para $name"
    override fun hiddenToast(name: String) = "$name oculto"

    override val PRIMARY = "Principal"
    override val SECONDARY = "Secundário"
    override val COPY = "Copiar"
    override fun addressA11y(label: String, ip: String) = "Endereço $label: $ip"
    override val CONNECT_TO_THIS = "Conectar a este servidor"
    override val SWITCH_TO_THIS = "Mudar para este servidor"
    override val CONNECTED_NOW = "Conectado agora"
    override val ADD_FAV = "Adicionar aos favoritos"
    override val REMOVE_FAV = "Remover dos favoritos"
    override val MEASURE_THIS = "Medir velocidade"
    override val HIDE = "Ocultar da lista"
    override val UNHIDE = "Mostrar na lista"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Última medição: sem resposta · $ago" else "Última medição: $ms ms · $ago"
    override val NEVER_MEASURED = "Ainda não medido"
    override val ENC_SUPPORT = "DNS criptografado"
    override val ENC_NONE = "Não suportado"
    override val ENC_ONLY = "Aceita apenas conexões criptografadas"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Melhor $best ms · mediana $median ms · perda $lossPct%"
    override val HISTORY = "Histórico de medições"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n medições, sem resposta" else "$HISTORY: $n medições, mediana $median ms"

    override val QUICK_TITLE = "Troca rápida"
    override val QUICK_FAVORITES = "Favoritos"
    override val QUICK_RECENT = "Usados recentemente"
    override val PAUSE_FOR = "Pausar"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Retomar"

    override val SETTINGS = "Configurações"
    override val SEC_LOOK = "Aparência"
    override val SEC_CONNECTION = "Conexão"
    override val SEC_PRIVACY = "Privacidade e segurança"
    override val SEC_LIST = "Lista de servidores"
    override val SEC_INFO = "Estatísticas"
    override val SEC_DATA = "Dados"
    override val SEC_ABOUT = "Sobre"
    override val LANGUAGE = "Idioma"
    override val LANG_AUTO = "Automático (idioma do sistema)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Automático"
    override val THEME_AUTO_NOTE = "Automático · segue o modo claro/escuro"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prado"
        "ocean" -> "Oceano"
        "sunset" -> "Pôr do sol"
        "lavender" -> "Lavanda"
        "coral" -> "Coral"
        "mint" -> "Menta"
        "night" -> "Noite"
        "amoled" -> "Preto (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema noturno por horário"
    override val THEME_SCHEDULE_NOTE = "No Automático, Noite das 22:00 às 07:00"
    override val GLASS = "Opacidade do vidro"
    override val BUBBLES = "Bolhas"
    override val MOTION = "Animações"
    override val TEXT_SIZE = "Tamanho do texto"
    override val HIGH_CONTRAST = "Alto contraste"
    override val HIGH_CONTRAST_NOTE = "Vidro mais opaco e texto mais escuro"
    override val MINIMAL = "Visual simples"
    override val MINIMAL_NOTE = "Oculta os filtros e a linha de estatísticas"
    override val LOW_POWER = "Modo de economia"
    override val LOW_POWER_NOTE = "Desliga todo movimento, poupa a bateria"
    override val HAPTICS = "Vibração"
    override val HAPTICS_NOTE = "Retorno leve ao toque"
    override val ENCRYPTION = "DNS criptografado"
    override val ENCRYPTION_NOTE = "Auto: primeiro DoT, depois DoH, por último DNS simples"
    override val AUTO_CONNECT = "Conectar ao abrir o app"
    override val AUTO_CONNECT_NOTE = "Conecta ao último servidor quando você abre o app"
    override val CONNECT_ON_BOOT = "Conectar ao iniciar"
    override val CONNECT_ON_BOOT_NOTE = "Conecta sozinho depois que o telefone reinicia"
    override val AUTO_FASTEST = "Conectar ao mais rápido"
    override val AUTO_FASTEST_NOTE = "A esfera escolhe o servidor mais rápido da última medição"
    override val REFRESH_ON_NET = "Renovar ao trocar de rede"
    override val REFRESH_ON_NET_NOTE = "O DNS é renovado ao alternar entre Wi-Fi e dados móveis"
    override val NOTIFY_DROP = "Avisar se a conexão cair"
    override val NOTIFY_DROP_NOTE = "Notificação com botão para reconectar em quedas inesperadas"
    override val CACHE = "Cache de DNS"
    override val CLEAR_CACHE = "Limpar cache"
    override val CACHE_CLEARED = "Cache limpo"
    override val ONLY_CONNECTED = "Disponível quando conectado"
    override val RULE_WIFI = "Servidor do Wi-Fi"
    override val RULE_MOBILE = "Servidor dos dados móveis"
    override val RULE_AUTO = "Automático"
    override val RULE_AUTO_NOTE = "O último servidor que você usou"
    override val COMPACT = "Lista compacta"
    override val COMPACT_NOTE = "Linhas mais curtas, sem descrição"
    override val HIDDEN = "Servidores ocultos"
    override val HIDDEN_NONE = "Nenhum"
    override val STAT_QUERIES = "Consultas no total"
    override val STAT_HITS = "Respondidas do cache"
    override val STAT_BLOCKED = "Bloqueadas (estimativa)"
    override val STAT_TIME = "Tempo total conectado"
    override val WEEK = "Últimos 7 dias"
    override fun weekA11y(total: String) = "$total consultas nos últimos 7 dias"
    override val WEEKDAYS = listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")
    override val EXPORT = "Exportar configurações"
    override val IMPORT = "Importar configurações"
    override val EXPORTED = "Código das configurações copiado"
    override val IMPORTED = "Configurações carregadas"
    override val IMPORT_BAD = "Não há um código de configurações válido na área de transferência"
    override val RESET_SETTINGS = "Redefinir configurações"
    override val RESET_STATS = "Redefinir estatísticas"
    override val CONFIRM = "Tem certeza?"
    override val RESET = "Redefinir"
    override val RESET_DONE = "Redefinido"
    override val LOG = "Registro de diagnóstico"
    override val HELP = "Como funciona?"
    override val VPN_SETTINGS = "Configurações de VPN do sistema"
    override val SHARE_APP = "Compartilhar o app"
    override val RATE_APP = "Avaliar o app"
    override val FEEDBACK = "Enviar comentários"
    override fun shareAppText(url: String) = "$APP conecta você aos DNS populares com um toque: $url"
    override val VERSION = "Versão"
    override val OPT_BUBBLES = listOf("Não", "Poucas", "Muitas")
    override val OPT_MOTION = listOf("Todas", "Poucas", "Não")
    override val OPT_CACHE = listOf("Não", "Pequeno", "Normal", "Grande")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Não")
    override val PLAIN_DNS = "DNS simples"

    override val LOG_NOTE = "Só eventos de conexão são guardados. Nunca nomes de consultas nem dados pessoais."
    override val LOG_EMPTY = "Ainda não há registros."
    override val SHARE = "Compartilhar"
    override val CLEAR = "Limpar"
    override val CLEARED = "Limpo"
    override val HELP_SECTIONS = listOf(
        "O que é DNS?" to
            "DNS é o serviço que transforma endereços da internet (como example.com) em números que os aparelhos entendem. " +
            "O DNS usado pode afetar a velocidade, a privacidade e o que é bloqueado.",
        "O que o app faz?" to
            "Ele usa o servidor DNS escolhido em todos os apps. Para isso abre uma interface VPN local no telefone, " +
            "mas o seu tráfego não vai para nenhum servidor VPN. Só as consultas DNS são enviadas ao servidor escolhido; " +
            "todo o resto segue o caminho normal.",
        "DNS criptografado (DoT / DoH)" to
            "Nos servidores compatíveis, as consultas são criptografadas: ninguém na rede (dono do Wi-Fi, operadora) vê " +
            "quais sites você visita nem altera as respostas. No Automático, DoT é tentado primeiro e depois DoH; se nenhum funcionar, " +
            "usa-se DNS simples. Você é avisado quando isso acontece, e o app tenta voltar à criptografia a cada troca de rede e a cada 10 minutos. " +
            "Com \"Criptografia estrita\" ativada, o DNS simples nunca é usado. A tela inicial mostra o método em uso.",
        "Teste de conexão" to
            "Configurações > Privacidade e segurança > Teste de conexão envia consultas DNS reais pelo túnel. Ele mostra que " +
            "o DNS realmente responde pelo servidor escolhido, com que velocidade, se o servidor valida assinaturas DNSSEC " +
            "e se bloqueia um domínio de anúncios conhecido.",
        "Privacidade" to
            "Sem conta, sem coleta de dados, sem anúncios. O app não guarda nomes de consultas e não envia nada por conta própria. " +
            "Suas consultas vão apenas ao provedor DNS escolhido, sob a política de privacidade dele. " +
            "O registro de diagnóstico contém só eventos de conexão.",
        "Bateria e recursos" to
            "Em segundo plano consome muito pouco. Com a tela desligada não há nada em loop; " +
            "ele só trabalha quando chega uma consulta DNS. Conexões criptografadas se fecham sozinhas quando ociosas.",
        "Bom saber" to
            "O Android permite apenas uma VPN por vez; com outro app de VPN ativo, este não conecta. " +
            "O \"DNS seguro\" de alguns navegadores e o \"DNS privado\" do Android com um nome fixo usam o próprio servidor " +
            "e podem ignorar este redirecionamento; basta deixá-los em \"Automático\" ou \"Desativado\". " +
            "Toque e segure a esfera para trocar rápido de servidor ou pausar a conexão por um tempo.",
    )

    override val NOTIF_CHANNEL = "Status da conexão"
    override val NOTIF_CHANNEL_NOTE = "Exibida enquanto a conexão DNS está ativa"
    override val NOTIF_ALERT_CHANNEL = "Alertas de conexão"
    override val NOTIF_CONNECTING = "Conectando…"
    override val NOTIF_STOP = "Desconectar"
    override val NOTIF_NEXT = "Próximo"
    override val NOTIF_DROP_TITLE = "A conexão DNS caiu"
    override val NOTIF_RECONNECT = "Reconectar"
    override fun notifOn(name: String, proto: String) = "Conectado a $name · $proto"
    override fun notifPaused(time: String) = "Em pausa · retoma às $time"
    override val TILE_ON = "Conectado"
    override val TILE_OFF = "Desligado"
    override val WIDGET_TAP = "Toque: conectar / desconectar"
    override val ERR_PERMISSION = "A permissão de VPN não foi concedida"
    override val ERR_ESTABLISH = "Não foi possível abrir a interface VPN. Outra VPN pode estar ativa."
    override fun errNoReply(name: String) = "$name não respondeu"
    override fun errNoProto(name: String, proto: String) = "$name não suporta $proto"
    override val ERR_SOCKET = "Não foi possível acessar a rede"
    override fun errPrivateDns(host: String) = "O DNS privado do Android está fixado em $host e ignora este app. Defina Configurações > Rede > DNS privado como Automático ou Desativado."
    override val ERR_REVOKED = "O sistema encerrou a conexão"
    override val ERR_TUNNEL = "O túnel foi fechado inesperadamente"
    override val ERR_UNKNOWN = "Ocorreu um erro inesperado"

    override val CONSENT_TITLE = "Antes de conectar"
    override val CONSENT_BODY = listOf(
        "$APP usa a interface VPN do Android para encaminhar suas consultas DNS (os nomes dos sites que você visita) ao servidor DNS escolhido.",
        "Seu tráfego não é enviado a nenhum servidor VPN; só as consultas DNS vão ao provedor escolhido. Nos servidores compatíveis " +
            "elas são criptografadas (DoT/DoH); nos demais seguem sem criptografia. Vale a política de privacidade do provedor.",
        "O app não coleta dados pessoais, não guarda nomes de consultas e não compartilha nada.",
        "Se continuar, o Android mostrará um pedido de conexão VPN; toque em \"OK\".",
    )
    override val CONSENT_OK = "Entendi, continuar"
    override val CLOSE = "Fechar"
    override val BACK = "Voltar"

    // ---- 3. sürüm ----
    override val RESUMING = "Retomando…"
    override val DOWNGRADED = "Falha na criptografia, usando DNS simples"
    override val UPGRADED = "De volta ao DNS criptografado"
    override val NOTIF_DOWNGRADE_TITLE = "O DNS não está criptografado"
    override fun notifDowngrade(name: String) = "Não foi possível criar uma conexão criptografada com $name. O DNS simples está em uso; o app tentará voltar à criptografia."
    override fun backupUsed(failed: String, used: String) = "$failed não respondeu, conectado a $used"
    override val NOTIF_RETRYING = "Conexão perdida, tentando de novo…"
    override fun errNoEncrypted(name: String) = "Não foi possível criptografar a conexão com $name"
    override val APPLYING = "Aplicando a nova configuração à conexão"
    override val CONFIRM_DISCONNECT = "Desconectar?"
    override val DISCONNECT = "Desconectar"

    override val SEC_NOTIF = "Notificações"
    override val STRICT_ENC = "Criptografia estrita"
    override val STRICT_ENC_NOTE = "Nunca recorrer ao DNS simples"
    override val AUTO_RECONNECT = "Reconectar automaticamente"
    override val AUTO_RECONNECT_NOTE = "Se a conexão cair, tenta de novo após 5 s, 30 s e 2 min"
    override val BACKUP_SERVER = "Servidor reserva"
    override val BACKUP_OFF = "Desligado"
    override val BACKUP_OFF_NOTE = "Não conecta se o servidor escolhido não responder"
    override val BACKUP_FASTEST = "Mais rápido"
    override val BACKUP_FASTEST_NOTE = "O outro servidor mais rápido da última medição"
    override val CONFIRM_OFF = "Confirmar ao desconectar"
    override val CONFIRM_OFF_NOTE = "Um toque acidental na esfera não desconecta"
    override val LOCK_HIDE = "Ocultar na tela de bloqueio"
    override val LOCK_HIDE_NOTE = "O nome do servidor não aparece na notificação da tela de bloqueio"
    override val QUIET_NOTIF = "Notificação discreta"
    override val QUIET_NOTIF_NOTE = "Sem ícone na barra de status, silenciosa"
    override val REMEMBER_FILTER = "Lembrar o último filtro"
    override val REMEMBER_FILTER_NOTE = "O último filtro escolhido volta quando você abre o app"
    override val AUTO_MEASURE = "Medir ao abrir"
    override val AUTO_MEASURE_NOTE = "Mede sozinho se a última medição tiver mais de um dia"
    override val MEASURE_ENC = "Medição criptografada"
    override val MEASURE_ENC_NOTE = "Mede a velocidade via DoT, mais perto do uso criptografado real"
    override val OPT_SORT = listOf("Padrão", "Velocidade", "Nome")
    override fun sortA11y(mode: String) = "Ordem: $mode"
    override val AUTO_LIGHT = "Automático: tema claro"
    override val AUTO_DARK = "Automático: tema escuro"
    override val NIGHT_HOURS = "Horário noturno"
    override val FILTER_ENCRYPTED = "Cifrados"
    override val FILTER_UNFILTERED = "Sem filtro"

    override val TEST = "Testar a conexão"
    override val TEST_NOTE = "DNS, DNSSEC e bloqueio de anúncios"
    override val TESTING = "Testando…"
    override val TEST_TITLE = "Teste de conexão"
    override val TEST_OK = "O DNS está funcionando"
    override val TEST_FAIL = "Sem resposta"
    override val TEST_SERVER = "Servidor"
    override val TEST_METHOD = "Método"
    override val TEST_LATENCY = "Tempo de resposta"
    override val TEST_DNSSEC = "Validação DNSSEC"
    override val TEST_ADS = "Bloqueio de anúncios"
    override val DNSSEC_YES = "Valida"
    override val DNSSEC_NO = "Não valida"
    override val ADS_YES = "Ativo"
    override val ADS_NO = "Inativo"
    override val UNKNOWN = "Desconhecido"
    override val TEST_EXPLAIN = "As perguntas foram enviadas pelo túnel, como um app faria; as respostas vieram do servidor escolhido."
    override val TEST_AGAIN = "Testar de novo"

    override val RECOMMEND = "Servidor ideal para mim"
    override val RECOMMEND_NOTE = "Escolha seu objetivo e conectamos ao mais rápido que atenda"
    override val GOAL_SPEED = "Velocidade"
    override val GOAL_SPEED_NOTE = "O servidor mais rápido nas suas medições"
    override val GOAL_PRIVACY_NOTE = "Sem registros, focado em privacidade"
    override val GOAL_ADS_NOTE = "Bloqueia anúncios e rastreadores"
    override val GOAL_FAMILY_NOTE = "Bloqueia conteúdo adulto"
    override val GOAL_SECURITY_NOTE = "Bloqueia sites maliciosos e de phishing"
    override fun recommended(name: String) = "Recomendado: $name"

    override val PRIVATE_DNS = "Nome do DNS privado"
    override val PRIVATE_DNS_NOTE = "Você pode colá-lo na opção DNS privado do Android. Aí o sistema usa este servidor diretamente e este app é ignorado."
    override val CLEAR_HISTORY = "Limpar histórico de medições"
    override val HISTORY_CLEARED = "Medições apagadas"

    override val GUARD = "Proteção contínua"
    override val GUARD_NOTE = "VPN sempre ativa"
    override val GUARD_BODY = listOf(
        "Enquanto o app não está conectado (desligado, em pausa ou após uma queda), suas consultas DNS vão para o servidor do seu provedor de internet.",
        "Para evitar isso, ative \"VPN sempre ativa\" para este app nas configurações de VPN do Android. Se \"Bloquear conexões sem VPN\" também estiver ativado, a internet não funcionará enquanto o app não estiver conectado: nada vaza, mas pausar também significa ficar sem internet.",
        "Com a VPN sempre ativa, o sistema inicia o app sozinho quando o telefone liga e depois que ele é encerrado.",
    )
    override val GUARD_BUTTON = "Abrir configurações de VPN"
    override val BATTERY = "Configurações de bateria"
    override val BATTERY_OK = "Sem restrição"
    override val BATTERY_LIMITED = "Pode estar restrito"
    override val BATTERY_BODY = listOf(
        "O Android costuma proteger apps de VPN. Mesmo assim, alguns fabricantes (Xiaomi, Huawei, Oppo, Vivo, algumas versões da Samsung) podem fechar apps em segundo plano para poupar bateria.",
        "Se a conexão cair sozinha com frequência, defina o uso de bateria deste app como \"Sem restrições\" ou \"Não otimizado\"; em alguns telefones, permita também a \"Inicialização automática\".",
    )
    override val BATTERY_BUTTON = "Abrir configurações de bateria"

    override val STAT_AVG = "Tempo médio de resposta"
    override val STAT_SAVED = "Tempo poupado pelo cache"
    override val STAT_TRAFFIC = "Tráfego DNS"
    override val SESSIONS = "Histórico de conexões"
    override val SESSIONS_NOTE = "Últimas 30 conexões; nomes de consultas nunca são guardados"
    override val SESSIONS_EMPTY = "Nenhuma conexão registrada ainda."
    override val MOST_USED = "Mais usados"
    override val TODAY = "Hoje"
    override val YESTERDAY = "Ontem"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Você desconectou"
        EndReason.PAUSE -> "Em pausa"
        EndReason.SWITCH -> "Troca de servidor"
        EndReason.DROP -> "Conexão caiu"
        EndReason.REVOKED -> "Encerrada pelo sistema"
        EndReason.FAILED -> "Não respondeu"
        EndReason.NETWORK -> "Troca de rede"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries consultas"

    override val WHATS_NEW = "Novidades"
    override val WHATS_NEW_TOAST = "O app foi atualizado"
    override val SHOW = "Mostrar"
    override val WHATS_NEW_ITEMS = listOf(
        "Conexão mais segura: verificações extras contra respostas DNS falsas, aviso ao cair para DNS simples, opção de criptografia estrita e volta automática à criptografia.",
        "Teste de conexão: confira com um toque se o DNS responde do servidor escolhido, além da validação DNSSEC e do bloqueio de anúncios.",
        "Servidor reserva e reconexão automática: o app se recupera sozinho se o servidor escolhido não responder ou a conexão cair.",
        "Histórico de conexões, servidores mais usados, tempo médio de resposta e tráfego DNS.",
        "Novos filtros (Cifrados, Sem filtro), ordenação por nome, \"Servidor ideal para mim\" e medição ao abrir.",
        "Contadores ao vivo na notificação, botão de pausa de 15 minutos, ocultação na tela de bloqueio e opção de notificação discreta.",
        "Três novos temas (Sakura, Mel, Aurora), um tema a partir do seu papel de parede e escolha de claro/escuro para o tema automático.",
        "Quatro novos idiomas: indonésio, vietnamita, polonês e ucraniano.",
    )
    override fun importedWith(changes: String) = "Configurações carregadas · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "criptografia enfraquecida"
        SensitiveChange.AUTO_START -> "conexão automática ativada"
        SensitiveChange.RULES -> "regras de servidor alteradas"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries consultas · $blocked bloqueadas"
    override val NOTIF_LOCKED = "Proteção DNS ativa"
    override val NOTIF_QUIET_CHANNEL = "Status da conexão (discreta)"
    override fun widgetToday(queries: String) = "Hoje: $queries consultas"
    override fun pauseAction(minutes: Int) = "Pausar ${minutes(minutes)}"


    override val NOTES = mapOf(
        "cloudflare" to "Rápido, focado em privacidade",
        "google" to "Estável, muito usado",
        "quad9" to "Bloqueia domínios maliciosos",
        "adguard" to "Bloqueia anúncios e rastreadores",
        "controld" to "Sem filtro, rápido",
        "opendns" to "Cisco, proteção contra phishing",
        "mullvad" to "Sem registros, só criptografado",
        "dnssb" to "Focado em privacidade, rápido",
        "dns4eu" to "DNS da UE, contra malware",
        "uncensored" to "Sem filtros nem redirecionamento",
        "quad9-open" to "Não bloqueia nada",
        "adguard-open" to "Sem bloqueio, focado em privacidade",
        "dns4eu-open" to "DNS da UE, sem filtro",
        "controld-ads" to "Anúncios, rastreadores, malware",
        "mullvad-ads" to "Anúncios e rastreadores, só criptografado",
        "dns4eu-ads" to "DNS da UE, anúncios e malware",
        "cloudflare-security" to "Bloqueia sites maliciosos",
        "controld-malware" to "Bloqueia sites maliciosos",
        "cleanbrowsing-security" to "Phishing e sites maliciosos",
        "cloudflare-family" to "Filtro de malware e conteúdo adulto",
        "opendns-family" to "Filtro de conteúdo adulto",
        "adguard-family" to "Filtro de anúncios e adulto",
        "cleanbrowsing-family" to "Conteúdo adulto, busca segura",
        "dns4eu-child" to "DNS da UE, proteção infantil",
        "mullvad-family" to "Filtro familiar, só criptografado",
        "controld-family" to "Filtro de conteúdo adulto",
    )
}
