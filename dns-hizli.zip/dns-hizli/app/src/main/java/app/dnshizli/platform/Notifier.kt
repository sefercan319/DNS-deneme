package app.dnshizli.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import app.dnshizli.R
import app.dnshizli.ui.Strings

/** Bağlantı açıkken gösterilen kalıcı bildirim (Android bunu önplan servisi için zorunlu tutar). */
object Notifier {
    private const val CHANNEL_ID = "status"
    const val NOTIF_ID = 1

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val ch = NotificationChannel(CHANNEL_ID, Strings.NOTIF_CHANNEL, NotificationManager.IMPORTANCE_LOW)
        ch.description = Strings.NOTIF_CHANNEL_NOTE
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    /** [text] ikinci satırdır (ör. "Cloudflare sunucusuna bağlı"). [stoppable] doluysa "Kes" eylemi eklenir. */
    fun build(ctx: Context, text: String, stoppable: Boolean): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
        if (stoppable) {
            val stop = PendingIntent.getForegroundService(
                ctx, 1, DnsVpnService.disconnectIntent(ctx),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            b.addAction(Notification.Action.Builder(Icon.createWithResource(ctx, R.drawable.ic_stat_dns), Strings.NOTIF_STOP, stop).build())
        }
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    fun update(ctx: Context, n: Notification) {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, n)
        } catch (_: Exception) {
            // bildirim izni yoksa sessizce geçilir; servis yine çalışır
        }
    }

    fun cancel(ctx: Context) {
        try { ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID) } catch (_: Exception) {}
    }
}
