package app.dnshizli.ui

import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.Gfx
import app.dnshizli.core.GPath
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.OrbMath
import app.dnshizli.core.OrbState
import app.dnshizli.core.Rgb
import app.dnshizli.core.ServerList
import app.dnshizli.core.TextFit
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

/** Tek satırlık yazıyı dikey ortalamak için taban çizgisi (büyük harf yüksekliğine göre, yazı tipinden bağımsız). */
internal fun centerBaseline(cy: Float, size: Float): Float = cy + size * 0.355f

/** Yalnızca erişilebilirlik için: hiçbir şey çizmez, verilen alanı okunur bir öğe olarak bildirir. */
class A11yOnly(var label: String, private val role: Role) : Node() {
    override fun draw(g: Gfx, env: Env) {}
    override fun a11y(): A11y? = if (label.isEmpty()) null else A11y(label, role)
}

/** Yatay yığın. Çocuklar kendi genişliğini yerleşimde belirler. */
class Row(var gap: Float = 0f, var padL: Float = 0f, var padR: Float = 0f, var padT: Float = 0f, var padB: Float = 0f) : Node() {
    override fun layout(env: Env, maxW: Float) {
        var cx = padL
        var mh = 0f
        for (k in kids) {
            if (!k.visible) continue
            k.layout(env, maxW)
            k.x = cx
            cx += k.w + gap
            if (k.h > mh) mh = k.h
        }
        w = cx - gap + padR
        h = mh + padT + padB
        for (k in kids) k.y = padT + (mh - k.h) / 2f
    }
}

/** Yuvarlak cam simge düğmesi. [active] ise parlak vurgu rengiyle dolar (ör. "hıza göre sırala" açık). */
class IconButton(
    private val icon: Icon,
    private val label: String,
    private val size: Float = M.MIN_TAP,
    private val onTap: () -> Unit,
) : PressNode() {
    var alpha = 1f
    var spin = 0f
    private val act = Anim(0f)
    var active: Boolean = false
        set(v) { if (v != field) { field = v; actTarget = if (v) 1f else 0f; dirty = true } }
    private var actTarget = 0f
    private var dirty = false
    override val tappable: Boolean get() = alpha > 0.5f
    override val hitSlop: Float get() = if (size < M.MIN_TAP) (M.MIN_TAP - size) / 2f else 0f

    override fun layout(env: Env, maxW: Float) { w = size; h = size; act.set(actTarget) }

    override fun tick(dt: Float, env: Env): Boolean {
        if (dirty) { dirty = false; act.go(actTarget, env.dur(0.22f)) }
        return act.step(dt) or super.tick(dt, env)
    }

    override fun draw(g: Gfx, env: Env) {
        if (alpha <= 0.01f) return
        g.save()
        if (alpha < 1f) g.alpha(alpha)
        pressScale(g, w / 2f, h / 2f, 0.09f)
        env.art.card(g, 0f, 0f, w, h, w / 2f, press = press.value * 0.5f, shadow = 0.7f)
        val a = act.value
        if (a > 0.01f) { g.save(); g.alpha(a); env.art.pill(g, 0f, 0f, w, h, 0f, 0.6f); g.restore() }
        g.save()
        g.translate(w / 2f, h / 2f)
        if (spin != 0f) g.rotate(spin)
        Icons.draw(g, icon, 0f, 0f, w * 0.5f, Rgb.lerp(env.art.ink, Rgb.WHITE, a), 2f)
        g.restore()
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onTap() }
    }

    override fun a11y(): A11y? = if (alpha > 0.5f) A11y(label, if (actTarget > 0f) Role.SWITCH else Role.BUTTON, checked = if (actTarget > 0f) true else null) else null
}

/** Süzgeç çipi: cam, seçilince parlak vurgu. */
class Chip(private val text: String, private val onTap: () -> Unit) : PressNode() {
    private val sel = Anim(0f)
    var selected: Boolean = false
        private set
    override val hitSlop: Float get() = 4f

    fun setSelected(v: Boolean, env: Env? = null, animate: Boolean = true) {
        if (v == selected && sel.target == (if (v) 1f else 0f)) return
        selected = v
        val d = if (animate && env != null) env.dur(0.22f) else 0f
        sel.go(if (v) 1f else 0f, d)
    }

    override fun layout(env: Env, maxW: Float) {
        w = env.metrics.textWidth(text, env.sz(14f), true) + 26f
        h = M.CHIP_H
    }

    override fun tick(dt: Float, env: Env): Boolean = sel.step(dt) or super.tick(dt, env)

    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.05f)
        art.card(g, 0f, 0f, w, h, h / 2f, press = press.value * 0.6f, shadow = 0.55f)
        val s = sel.value
        if (s > 0.01f) { g.save(); g.alpha(s); art.pill(g, 0f, 0f, w, h, 0f, 0.8f); g.restore() }
        val fs = env.sz(14f)
        g.paint(Rgb.lerp(env.theme.text, Rgb.WHITE, s))
        g.text(text, w / 2f, centerBaseline(h / 2f, fs), fs, s > 0.5f, ALIGN_CENTER)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onTap() }
    }

    override fun a11y(): A11y = A11y(text, Role.BUTTON, checked = selected)
}

/** Tam genişlikli eylem düğmesi: birincil (parlak) veya ikincil (cam). */
class ActionButton(
    var text: String,
    private val primary: Boolean = true,
    private val icon: Icon? = null,
    private val onTap: () -> Unit,
) : PressNode() {
    var enabled = true
    override val tappable: Boolean get() = enabled

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 50f }

    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        g.save()
        if (!enabled) g.alpha(0.55f)
        pressScale(g, w / 2f, h / 2f, 0.025f)
        if (primary) art.pill(g, 0f, 0f, w, h, press.value, 1f)
        else art.card(g, 0f, 0f, w, h, h / 2f, press = press.value * 0.6f, shadow = 0.7f)
        val fs = env.sz(16f)
        val col = if (primary) Rgb.WHITE else env.theme.text
        val tw = env.metrics.textWidth(text, fs, true)
        val iconW = if (icon != null) 26f else 0f
        val startX = (w - tw - iconW) / 2f
        if (icon != null) Icons.draw(g, icon, startX + 10f, h / 2f, 20f, col, 2.1f)
        g.paint(col)
        g.text(text, startX + iconW, centerBaseline(h / 2f, fs), fs, true, ALIGN_LEFT)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap && enabled) { env.tap(); onTap() }
    }

    override fun a11y(): A11y = A11y(text, Role.BUTTON)
}

/** Üst çubuk: başlık, soldaki/sağdaki düğmeler ve içerik altından geçerken beliren cam zemin. */
class Header(private val title: String, private val back: Boolean, private val onBack: () -> Unit) : Node() {
    var barAlpha = 0f
    var left = 0f
    var content = 0f

    /** Başlık yazısı; erişilebilirlikte yalnızca kendi alanı "başlık" olarak okunur. */
    private class TitleNode(private val text: String) : Node() {
        val label = Label(text, 20f, bold = true)
        override fun layout(env: Env, maxW: Float) { label.layout(env, maxW); w = label.w; h = label.h }
        override fun draw(g: Gfx, env: Env) { label.draw(g, env) }
        override fun a11y(): A11y = A11y(text, Role.HEADING)
    }

    private val titleLabel = TitleNode(title)
    private val backBtn = IconButton(Icon.BACK, Strings.BACK, 44f, onBack)
    val buttons = ArrayList<Node>(2)

    init { add(titleLabel); if (back) add(backBtn) }

    fun addRight(n: Node) { buttons.add(n); add(n) }

    /** Başlığın solunda küçük, isteğe bağlı bir düğüm (ör. mini küre). */
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = M.HEADER_H + env.insetTop
        val cw = minOf(maxW, M.MAX_W)
        val l = (maxW - cw) / 2f
        left = l
        content = cw
        val cy = env.insetTop + M.HEADER_H / 2f
        var rx = l + cw - M.PAD
        for (b in buttons) {
            b.layout(env, cw)
            rx -= b.w
            b.x = rx
            b.y = cy - b.h / 2f
            rx -= 10f
        }
        var tx = l + M.PAD
        if (back) { backBtn.layout(env, cw); backBtn.x = l + 12f; backBtn.y = cy - backBtn.h / 2f; tx = backBtn.x + backBtn.w + 8f }
        titleLabel.layout(env, maxOf(40f, rx - tx))
        titleLabel.x = tx
        titleLabel.y = cy - titleLabel.h / 2f
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.bar(g, w, h, barAlpha, env.height)
        drawKids(g, env)
    }
}

/** Ana ekranın kahramanı: cam küre, durum yazıları ve canlı istatistikler. */
class OrbBlock(private val onTap: () -> Unit) : PressNode() {
    private val title = Label("", 28f, bold = true, align = ALIGN_CENTER)
    private val sub = Label("", 15f, ink = Ink.TEXT, align = ALIGN_CENTER)
    private val hint = Label("", 13f, ink = Ink.SOFT, align = ALIGN_CENTER)
    private val swap = Anim(1f)
    private val glowA = Anim(0f)
    private val errA = Anim(0f)
    private val ring = GPath()
    private var level = 0f
    private var phase = 0f
    private var state = OrbState.OFF
    private var seenVersion = -1
    private var seenSec = -1L
    private var a11yText = ""

    val r: Float get() = M.ORB_R
    val cx: Float get() = w / 2f
    val cy: Float get() = 14f + r

    /** Küre ekranın dışına kayınca üst çubukta mini düğme göstermek için küre altının y konumu. */
    val orbBottom: Float get() = y + cy + r

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        title.layout(env, maxW); sub.layout(env, maxW); hint.layout(env, maxW)
        title.x = 0f; title.y = 2f * r + 14f + 22f
        sub.x = 0f; sub.y = title.y + title.h + 2f
        hint.x = 0f; hint.y = sub.y + sub.h + 3f
        h = hint.y + hint.h + 20f
    }

    override fun contains(lx: Float, ly: Float): Boolean {
        val dx = lx - cx
        val dy = ly - cy
        return sqrt(dx * dx + dy * dy) <= r + 10f
    }

    private fun refresh(env: Env, force: Boolean) {
        val m = env.model
        val sec = m.host.now() / 1000
        if (!force && m.version == seenVersion && (m.vpn.state != OrbState.ON || sec == seenSec)) return
        seenVersion = m.version
        seenSec = sec
        val t = m.statusTitle()
        if (t != title.text) {
            title.text = t
            swap.set(0f)
            swap.go(1f, env.dur(0.30f))
        }
        sub.text = m.statusSub()
        hint.text = m.statusHint()
        a11yText = Strings.APP + ". " + t + ". " + sub.text
        if (m.vpn.state != state) {
            state = m.vpn.state
            glowA.go(when (state) { OrbState.ON -> 1f; OrbState.CONNECTING -> 0.6f; else -> 0f }, env.dur(0.6f))
            errA.go(if (state == OrbState.ERROR) 1f else 0f, env.dur(0.5f))
        }
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env, false)
        var active = press.step(dt)
        if (swap.step(dt)) active = true
        if (glowA.step(dt)) active = true
        if (errA.step(dt)) active = true
        val target = OrbMath.targetLevel(state)
        if (env.motion <= 0f) level = target
        else if (!OrbMath.settled(level, target)) { level = OrbMath.approach(level, target, dt, 3.2f); active = true }
        else level = target
        if (env.ambient && (state == OrbState.ON || state == OrbState.CONNECTING)) {
            phase += dt * (if (state == OrbState.CONNECTING) 3.4f else 1.5f)
        }
        return active
    }

    override fun ambient(env: Env): Boolean = env.ambient && (state == OrbState.ON || state == OrbState.CONNECTING)

    override fun draw(g: Gfx, env: Env) {
        if (seenVersion < 0) refresh(env, true)
        val art = env.art
        g.save()
        pressScale(g, cx, cy, 0.05f)
        val pulse = if (state == OrbState.ON && env.ambient) 0.84f + 0.16f * sin(env.time * 1.8f) else 1f
        art.orb(g, cx, cy, r, level, phase, glowA.value * pulse, errA.value, press.value * 0.6f)
        if (state == OrbState.CONNECTING && env.ambient) {
            val a = env.time * 230f
            ring.reset().arc(cx, cy, r + 9f, r + 9f, a, 95f, false)
            g.strokeWidth(3f)
            g.paint(Rgb.alpha(env.theme.accent, 0.85f))
            g.strokePath(ring)
        }
        g.restore()

        val s = swap.value
        drawLine(g, env, title, s)
        drawLine(g, env, sub, s)
        drawLine(g, env, hint, s)
    }

    private fun drawLine(g: Gfx, env: Env, l: Label, s: Float) {
        l.alpha = Easing.clamp01(s)
        l.dy = (1f - s) * 8f
        g.save(); g.translate(l.x, l.y); l.draw(g, env); g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(true); onTap() }
    }

    override fun a11y(): A11y = A11y(a11yText.ifEmpty { Strings.APP }, Role.BUTTON)
}

/** Sunucu listesinin yıldız düğmesi. */
class StarButton(private val serverId: String, private val name: String) : PressNode() {
    var fav = false
    override fun layout(env: Env, maxW: Float) { w = 44f; h = 44f }

    override fun draw(g: Gfx, env: Env) {
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.12f)
        val col = if (fav) 0xB07400 or (0xFF shl 24) else env.theme.textSoft
        val fill = if (fav) 0xFFC21F or (0xFF shl 24) else 0
        Icons.draw(g, Icon.STAR, w / 2f, h / 2f, 22f, col, 1.8f, fill)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); env.model.toggleFavorite(serverId) }
    }

    override fun a11y(): A11y = A11y("$name favori", Role.SWITCH, checked = fav)
}

/** Listedeki bir DNS sunucusu satırı. Dokun: bağlan. Yıldız: favori. Uzun bas: ayrıntı. */
class ServerRow(val server: DnsServer, private val onLong: (DnsServer) -> Unit) : PressNode() {
    private val star = StarButton(server.id, server.name)
    private val selAnim = Anim(0f)
    private var seenVersion = -1
    private var fs = 0f
    private var laidW = -1f
    private var nameShown = server.name
    private var noteShown = server.note
    private var latMs: Int? = null
    private var latKnown = false
    private var bars = 0
    private var latText = ""
    private var connected = false
    private val icon = Icons.forTags(server.tags)

    init { add(star) }

    override val longPressable: Boolean get() = true

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = M.ROW_H
        star.layout(env, maxW)
        star.x = w - 46f
        star.y = (h - star.h) / 2f
        laidW = -1f
        refresh(env, true)
    }

    private fun clusterLeft(): Float = w - 26f - 22f - 36f

    private fun relayText(env: Env) {
        val tx = 58f
        val availName = (if (latKnown) clusterLeft() - 10f else w - 50f - 8f) - tx
        val availNote = availName
        nameShown = TextFit.ellipsize(env.metrics, server.name, availName, env.sz(16f), true)
        noteShown = TextFit.ellipsize(env.metrics, server.note, availNote, env.sz(13f), false)
        laidW = w
        fs = env.fs
    }

    private fun refresh(env: Env, force: Boolean) {
        val m = env.model
        if (!force && seenVersion == m.version) return
        seenVersion = m.version
        val id = server.id
        val connId = m.connectedId()
        connected = connId == id
        val selected = connected || (connId == null && m.selectedId() == id)
        selAnim.go(if (selected) 1f else 0f, env.dur(0.25f))
        if (!selAnim.active) selAnim.set(if (selected) 1f else 0f)
        star.fav = id in m.settings.favorites
        val l = m.latencies[id]
        val known = l != null
        latMs = l?.ms
        bars = ServerList.bars(latMs)
        latText = if (!known) "" else (latMs?.let { "$it ms" } ?: "—")
        if (known != latKnown || laidW != w || fs != env.fs) { latKnown = known; relayText(env) }
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env, false)
        val a = selAnim.step(dt)
        return super.tick(dt, env) or a
    }

    override fun draw(g: Gfx, env: Env) {
        if (fs != env.fs || laidW != w) refresh(env, true)
        val art = env.art
        val th = env.theme
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.018f)
        art.card(g, 0f, 0f, w, h, M.CARD_R, selected = selAnim.value, press = press.value * 0.8f)
        art.iconDisc(g, 30f, h / 2f, 18f)
        Icons.draw(g, icon, 30f, h / 2f, 20f, art.ink, 2f)
        if (connected) art.badge(g, 44f, h / 2f + 13f, 7f)
        val n = env.sz(16f)
        val s = env.sz(13f)
        g.paint(th.text)
        g.text(nameShown, 58f, h / 2f - 4f, n, true, ALIGN_LEFT)
        g.paint(th.textSoft)
        g.text(noteShown, 58f, h / 2f + 15f, s, false, ALIGN_LEFT)
        if (latKnown) {
            val cl = clusterLeft()
            art.bars(g, cl + 8f, h / 2f + 2f, bars, connected)
            g.paint(th.textSoft)
            g.text(latText, cl + 17f, h / 2f + 19f, env.sz(11.5f), false, ALIGN_CENTER)
        }
        g.restore()
        // yıldız çocuk olarak ayrıca çizilir (basınca satırla birlikte küçülmesin)
        drawKids(g, env)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); env.model.tapServer(server.id) }
    }

    override fun onLongPress(env: Env): Boolean { env.tap(true); onLong(server); return true }

    override fun a11y(): A11y {
        val m = latText.takeIf { it.isNotEmpty() }
        val parts = listOfNotNull(server.name, server.note, m, if (connected) "bağlı" else null)
        return A11y(parts.joinToString(", "), Role.BUTTON, longClick = true)
    }
}

/** Geçici kısa mesaj: altta cam hap, isteğe bağlı eylemle. */
class ToastNode : Node() {
    private val a = Anim(0f)
    private var msg: ToastMsg? = null
    private var life = 0f
    private var shownText = ""
    private var textW = 0f
    private var actionW = 0f
    private var pressed = false
    var screenW = 0f
    var screenH = 0f

    val active: Boolean get() = msg != null
    override val tappable: Boolean get() = msg?.action != null && a.value > 0.6f

    fun show(env: Env, m: ToastMsg) {
        msg = m
        life = if (m.action != null) 5.5f else 2.8f
        a.set(0f)
        a.go(1f, env.dur(0.28f))
        relayout(env)
    }

    fun dismiss(env: Env) { if (msg != null) { life = 0f } }

    fun relayout(env: Env) {
        val m = msg ?: return
        val fs = env.sz(14f)
        val maxW = minOf(screenW, M.MAX_W) - 40f
        val act = m.action
        actionW = if (act != null) env.metrics.textWidth(act, fs, true) + 12f else 0f
        val availText = maxW - 36f - actionW
        shownText = TextFit.ellipsize(env.metrics, m.text, availText, fs, false)
        textW = env.metrics.textWidth(shownText, fs, false)
        w = textW + actionW + 36f
        h = 44f
        x = (screenW - w) / 2f
        y = screenH - env.insetBottom - 28f - h
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val m = msg ?: return false
        val moving = a.step(dt)
        life -= dt
        if (life <= 0f && a.target != 0f) a.go(0f, env.dur(0.25f))
        if (life <= 0f && !a.active) { msg = null; return false }
        return moving   // bekleme süresince tam hız gerekmez: sahne geri sayımı 33 ms'lik karelerle sürdürür
    }

    override fun contains(lx: Float, ly: Float): Boolean = lx >= w - actionW - 20f && lx <= w + 8f && ly >= -6f && ly <= h + 6f

    override fun onDown(lx: Float, ly: Float, env: Env) { pressed = true }
    override fun onCancel(env: Env) { pressed = false }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        pressed = false
        val m = msg ?: return
        if (tap && m.action != null) { env.tap(); m.onAction?.invoke(); life = 0f }
    }

    override fun draw(g: Gfx, env: Env) {
        val m = msg ?: return
        val v = a.value
        if (v <= 0.01f) return
        g.save()
        g.alpha(Easing.clamp01(v))
        g.translate(0f, (1f - v) * 16f)
        env.art.card(g, 0f, 0f, w, h, h / 2f, strong = 0.9f, shadow = 1f, press = if (pressed) 0.4f else 0f)
        val fs = env.sz(14f)
        g.paint(env.theme.text)
        g.text(shownText, 18f, centerBaseline(h / 2f, fs), fs, false, ALIGN_LEFT)
        val act = m.action
        if (act != null) {
            g.paint(env.theme.link)
            g.text(act, 18f + textW + 12f, centerBaseline(h / 2f, fs), fs, true, ALIGN_LEFT)
        }
        g.restore()
    }

    override fun a11y(): A11y? = msg?.let { A11y(it.text + (it.action?.let { a -> ", $a" } ?: ""), if (it.action != null) Role.BUTTON else Role.TEXT) }
}
