# Bu uygulama yansıma (reflection) kullanmaz ve harici kütüphane içermez.
# Manifestte tanımlı etkinlik, servis ve alıcılar AAPT2 tarafından otomatik korunur.
# Hata ayıklamayı kolaylaştırmak için yayın derlemesinde satır numaraları saklanır:
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
