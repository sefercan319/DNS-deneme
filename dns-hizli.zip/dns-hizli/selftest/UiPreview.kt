package app.dnshizli.selftest

import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.Themes
import app.dnshizli.ui.Strings
import java.awt.image.BufferedImage

/**
 * Önizleme görselleri: gerçek sahne kodunu AWT üzerinde çizer ([Rig] ile aynı düzenek).
 * Cihaz ekran görüntüsü değildir: yazı tipi Inter'dir (Android'de Roboto kullanılır).
 */
object UiPreview {
    private val awt = AwtGfx(BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB).createGraphics())

    private fun rig(s: AppSettings, w: Int = 360, h: Int = 780) = Rig(s, w, h, metrics = awt)

    private fun Rig.render(file: String, scale: Float = 2f) {
        val cv = AwtCanvas(w, h, scale)
        scene.draw(cv.gfx)
        cv.savePng(file)
        cv.dispose()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val out = args.getOrNull(0) ?: "."
        val which = args.getOrNull(1)
        fun want(n: String) = which == null || which == n

        if (want("home")) {
            for (th in Themes.all) {
                val r = rig(Rig.base(th.id)); r.connectOk()
                r.render("$out/ana-${th.id}.png")
            }
        }
        if (want("off")) { rig(Rig.base()).render("$out/ana-kapali.png") }
        if (want("scroll")) {
            val r = rig(Rig.base()); r.connectOk()
            r.drag(180f, 600f, 250f, 14); r.drag(180f, 600f, 250f, 14)
            r.render("$out/ana-kaydirilmis.png")
        }
        if (want("settings")) {
            val r = rig(Rig.base()); r.scene.openSettings(); r.settle(900)
            r.render("$out/ayarlar-1.png")
            r.drag(180f, 600f, 150f, 14); r.drag(180f, 600f, 150f, 14)
            r.render("$out/ayarlar-2.png")
            val n = rig(Rig.base("night")); n.scene.openSettings(); n.settle(900)
            n.render("$out/ayarlar-gece.png")
        }
        if (want("sheet")) {
            val r = rig(Rig.base()); r.connectOk()
            r.scene.openDetails(Catalog.byId("quad9")!!); r.settle(700)
            r.render("$out/detay.png")
            val c = rig(Rig.base("sunset")); c.scene.openSettings(); c.settle(800)
            c.scene.openChoice(Strings.RULE_WIFI_TITLE, null) {}; c.settle(700)
            c.render("$out/secici.png")
        }
        if (want("consent")) {
            val r = rig(Rig.base("ocean").copy(onboarded = false))
            r.model.tapOrb(); r.settle(900)
            r.render("$out/bilgilendirme.png")
        }
        if (want("pages")) {
            val r = rig(Rig.base("lavender")); r.scene.openSettings(); r.settle(700); r.scene.openLog(); r.settle(700)
            r.render("$out/gunluk.png")
            val h = rig(Rig.base("meadow")); h.scene.openSettings(); h.settle(700); h.scene.openHelp(); h.settle(700)
            h.render("$out/yardim.png")
        }
        if (want("toast")) {
            val r = rig(Rig.base()); r.connectOk()
            r.model.toast("En hızlı: Cloudflare · 18 ms", "Bağlan") {}; r.settle(500)
            r.render("$out/bildirim.png")
        }
        if (want("tablet")) {
            val r = rig(Rig.base("ocean"), 800, 1100); r.connectOk()
            r.render("$out/tablet.png", 1f)
        }
        if (want("large")) {
            val r = Rig(Rig.base("meadow"), 360, 780, metrics = awt, fontScale = 1.3f); r.connectOk()
            r.render("$out/buyuk-yazi.png")
        }
        println("önizlemeler: $out")
    }
}
