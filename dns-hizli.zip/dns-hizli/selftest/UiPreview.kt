package app.dnshizli.selftest

import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.Encryption
import app.dnshizli.core.L
import app.dnshizli.core.Lang
import app.dnshizli.core.Themes
import app.dnshizli.core.Proto
import app.dnshizli.core.Session
import app.dnshizli.core.SessionLog
import app.dnshizli.core.EndReason
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.DnssecResult
import app.dnshizli.core.AdBlockResult
import app.dnshizli.ui.Strings
import java.awt.image.BufferedImage

/**
 * Önizleme görselleri: gerçek sahne kodunu AWT üzerinde çizer ([Rig] ile aynı düzenek).
 * Cihaz ekran görüntüsü değildir: yazı tipi Inter'dir (Android'de Roboto kullanılır).
 */
object UiPreview {
    private val awt = AwtGfx(BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB).createGraphics())

    private fun rig(s: AppSettings, w: Int = 360, h: Int = 780) = Rig(s, w, h, metrics = awt)

    private fun Rig.render(file: String, scale: Float = 2f) {
        val cv = AwtCanvas(w, h, scale)
        scene.draw(cv.gfx)
        cv.savePng(file)
        cv.dispose()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val out = args.getOrNull(0) ?: "."
        val which = args.getOrNull(1)
        fun want(n: String) = which == null || which == n

        if (want("home")) {
            for (th in Themes.all) {
                val r = rig(Rig.base(th.id)); r.connectOk()
                r.render("$out/ana-${th.id}.png")
            }
        }
        if (want("off")) { rig(Rig.base()).render("$out/ana-kapali.png") }
        if (want("scroll")) {
            val r = rig(Rig.base()); r.connectOk()
            r.drag(180f, 600f, 250f, 14); r.drag(180f, 600f, 250f, 14)
            r.render("$out/ana-kaydirilmis.png")
        }
        if (want("settings")) {
            val r = rig(Rig.base()); r.scene.openSettings(); r.settle(900)
            r.render("$out/ayarlar-1.png")
            r.drag(180f, 600f, 150f, 14); r.drag(180f, 600f, 150f, 14)
            r.render("$out/ayarlar-2.png")
            val n = rig(Rig.base("night")); n.scene.openSettings(); n.settle(900)
            n.render("$out/ayarlar-gece.png")
        }
        if (want("sheet")) {
            val r = rig(Rig.base()); r.connectOk()
            r.scene.openDetails(Catalog.byId("quad9")!!); r.settle(700)
            r.render("$out/detay.png")
            val c = rig(Rig.base("sunset")); c.scene.openSettings(); c.settle(800)
            c.scene.openChoice(Strings.RULE_WIFI, null) {}; c.settle(700)
            c.render("$out/secici.png")
        }
        if (want("consent")) {
            val r = rig(Rig.base("ocean").copy(onboarded = false))
            r.model.tapOrb(); r.settle(900)
            r.render("$out/bilgilendirme.png")
        }
        if (want("pages")) {
            val r = rig(Rig.base("lavender")); r.scene.openSettings(); r.settle(700); r.scene.openLog(); r.settle(700)
            r.render("$out/gunluk.png")
            val h = rig(Rig.base("meadow")); h.scene.openSettings(); h.settle(700); h.scene.openHelp(); h.settle(700)
            h.render("$out/yardim.png")
        }
        if (want("toast")) {
            val r = rig(Rig.base()); r.connectOk()
            r.model.toast("En hızlı: Cloudflare · 18 ms", "Bağlan") {}; r.settle(500)
            r.render("$out/bildirim.png")
        }
        if (want("tablet")) {
            val r = rig(Rig.base("ocean"), 800, 1100); r.connectOk()
            r.render("$out/tablet.png", 1f)
        }
        if (want("large")) {
            val r = Rig(Rig.base("meadow"), 360, 780, metrics = awt, fontScale = 1.3f); r.connectOk()
            r.render("$out/buyuk-yazi.png")
        }
        if (want("lang")) {
            // Diğer dillerde ana ekran ve ayarlar.
            val saved = L.lang
            try {
                for ((lang, theme) in listOf(Lang.EN to "amoled", Lang.DE to "coral", Lang.RU to "mint", Lang.ES to "ocean",
                    Lang.ID to "sakura", Lang.VI to "honey", Lang.PL to "aurora", Lang.UK to "night")) {
                    L.set(lang)
                    val r = rig(Rig.base(theme).copy(lang = lang.code)); r.model.onLanguageChanged(); r.connectOk()
                    r.render("$out/dil-${lang.code}.png")
                }
                L.set(Lang.EN)
                val s = rig(Rig.base("coral").copy(lang = "en")); s.model.onLanguageChanged(); s.scene.openSettings(); s.settle(900)
                s.render("$out/dil-en-ayarlar.png")
            } finally { L.set(saved) }
        }
        if (want("new")) {
            // Yeni özellikler: hızlı seçim, geçmişli ayrıntı, şifreleme ayarı, yüksek kontrast, sade görünüm.
            val q = rig(Rig.base("mint")); q.connectOk(); q.scene.openQuickPick(); q.settle(700)
            q.render("$out/hizli-secim.png")
            val d = rig(Rig.base().copy(encryption = Encryption.DOT)); d.connectOk()
            for ((ms, loss) in listOf(21 to 0, 19 to 0, 26 to 0, 18 to 0, 33 to 20, 22 to 0, 20 to 0, 17 to 0)) d.model.onLatency("cloudflare", ms, loss)
            d.scene.openDetails(Catalog.byId("cloudflare")!!); d.settle(700)
            d.render("$out/detay-gecmis.png")
            val e = rig(Rig.base("amoled")); e.scene.openSettings(); e.settle(900)
            repeat(3) { e.drag(180f, 650f, 150f, 14) }; e.advance(1500)
            e.render("$out/ayarlar-gizlilik.png")
            val hc = rig(Rig.base().copy(highContrast = true)); hc.connectOk()
            hc.render("$out/yuksek-kontrast.png")
            val mn = rig(Rig.base("coral").copy(minimal = true, compact = true)); mn.connectOk()
            mn.render("$out/sade-gorunum.png")
        }
        if (want("v3")) {
            // 3. sürüm: bağlantı testi, oturum geçmişi, yenilikler, yeni temalar (ana ekranlar yukarıda), bildirim ayarları.
            val t = rig(Rig.base("aurora")); t.connectOk(); t.scene.openTest(); t.settle(700)
            t.model.onTestResult(SelfTestResult(true, 23, Proto.DOT, "cloudflare", DnssecResult.VALIDATING, AdBlockResult.NOT_BLOCKED))
            t.settle(700)
            t.render("$out/baglanti-testi.png")
            val now = 1_800_000_000_000L
            val list = listOf(
                Session("cloudflare", Proto.DOT, now - 7_200_000, now - 3_600_000, EndReason.USER, 1840),
                Session("quad9", Proto.DOH, now - 90_000_000, now - 86_400_000, EndReason.SWITCH, 920),
                Session("adguard", Proto.PLAIN, now - 200_000_000, now - 190_000_000, EndReason.DROP, 310),
            )
            val se = rig(Rig.base("sakura").copy(sessions = SessionLog.encode(list))); se.scene.openSettings(); se.settle(700)
            se.scene.openSessions(); se.settle(800)
            se.render("$out/oturumlar.png")
            val w = rig(Rig.base("honey")); w.scene.openSettings(); w.settle(700); w.scene.openWhatsNew(); w.settle(800)
            w.render("$out/yenilikler.png")
            val n = rig(Rig.base("aurora")); n.scene.openSettings(); n.settle(900)
            repeat(5) { n.drag(180f, 650f, 150f, 14) }; n.advance(1500)
            n.render("$out/ayarlar-bildirim.png")
        }
        println("önizlemeler: $out")
    }
}
