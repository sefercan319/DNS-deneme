package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Yol komutlarını toplayan basit gezgin (testler için). */
private class PathProbe : PathSink {
    var moves = 0; var lines = 0; var quads = 0; var cubics = 0; var closes = 0
    var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
    var firstX = Float.NaN; var firstY = Float.NaN; var lastX = Float.NaN; var lastY = Float.NaN
    var allFinite = true
    val cubicList = ArrayList<FloatArray>()
    private var px = 0f; private var py = 0f

    private fun p(x: Float, y: Float) {
        if (!x.isFinite() || !y.isFinite()) allFinite = false
        minX = minOf(minX, x); maxX = maxOf(maxX, x); minY = minOf(minY, y); maxY = maxOf(maxY, y)
        if (firstX.isNaN()) { firstX = x; firstY = y }
        lastX = x; lastY = y
    }
    override fun move(x: Float, y: Float) { moves++; p(x, y); px = x; py = y }
    override fun line(x: Float, y: Float) { lines++; p(x, y); px = x; py = y }
    override fun quad(cx: Float, cy: Float, x: Float, y: Float) { quads++; p(cx, cy); p(x, y); px = x; py = y }
    override fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float) {
        cubics++; cubicList.add(floatArrayOf(px, py, c1x, c1y, c2x, c2y, x, y)); p(c1x, c1y); p(c2x, c2y); p(x, y); px = x; py = y
    }
    override fun close() { closes++ }
}

private fun probe(path: GPath): PathProbe = PathProbe().also { path.visit(it) }

private fun near(a: Float, b: Float, eps: Float = 0.02f) = abs(a - b) <= eps

fun testGPath() {
    T.group("GPath: yay ve yuvarlak köşe")

    // çeyrek daire: (10,0) -> (0,10), orta nokta yarıçapa çok yakın
    val q = GPath().arc(0f, 0f, 10f, 10f, 0f, 90f, false)
    val pq = probe(q)
    T.check("çeyrek yay başlangıcı", near(pq.firstX, 10f) && near(pq.firstY, 0f))
    T.check("çeyrek yay sonu", near(pq.lastX, 0f) && near(pq.lastY, 10f))
    T.check("çeyrek yay tek parça", pq.cubics == 1 && pq.moves == 1)
    val c = pq.cubicList[0]
    val mx = (c[0] + 3 * c[2] + 3 * c[4] + c[6]) / 8f
    val my = (c[1] + 3 * c[3] + 3 * c[5] + c[7]) / 8f
    T.check("çeyrek yay orta noktası yarıçapta", near(hypot(mx, my), 10f, 0.03f), "r=${hypot(mx, my)}")

    // 280° (güç simgesi yayı): 4 parça, bitiş açısı 225°
    val p280 = probe(GPath().arc(12f, 12f, 8f, 8f, -55f, 290f, false))
    val endA = (-55.0 + 290.0) * PI / 180.0
    T.check("290° yay 4 parça", p280.cubics == 4, "${p280.cubics}")
    T.check("290° yay bitişi", near(p280.lastX, (12 + 8 * cos(endA)).toFloat()) && near(p280.lastY, (12 + 8 * sin(endA)).toFloat()))

    // saat yönünün tersi (negatif süpürme)
    val ccw = probe(GPath().arc(0f, 0f, 10f, 10f, 90f, -90f, false))
    T.check("negatif süpürme: (0,10) -> (10,0)", near(ccw.firstX, 0f) && near(ccw.firstY, 10f) && near(ccw.lastX, 10f) && near(ccw.lastY, 0f))

    // tam daire kapanıyor ve elips sınırı doğru
    val full = probe(GPath().arc(5f, 5f, 4f, 2f, 0f, 360f, false))
    T.check("tam elips kapanıyor", near(full.lastX, full.firstX) && near(full.lastY, full.firstY))
    T.check("tam elips sınırları", near(full.minX, 1f, 0.2f) && near(full.maxX, 9f, 0.2f) && near(full.minY, 3f, 0.2f) && near(full.maxY, 7f, 0.2f))

    // sıfır süpürme: bozuk sayı üretmez
    T.check("sıfır süpürme sonlu", probe(GPath().arc(0f, 0f, 5f, 5f, 10f, 0f, false)).allFinite)

    // connect=true: mevcut yola çizgi ile bağlanır
    val joined = GPath().moveTo(0f, 0f).arc(10f, 10f, 5f, 5f, 0f, 90f, true)
    val pj = probe(joined)
    T.check("connect=true çizgi ekler", pj.moves == 1 && pj.lines == 1)

    // yuvarlak dikdörtgen
    val rr = probe(GPath().roundRect(10f, 20f, 110f, 70f, 12f))
    T.check("roundRect sınırları", near(rr.minX, 10f, 0.05f) && near(rr.maxX, 110f, 0.05f) && near(rr.minY, 20f, 0.05f) && near(rr.maxY, 70f, 0.05f), "${rr.minX},${rr.minY},${rr.maxX},${rr.maxY}")
    T.check("roundRect kapalı ve 4 yay", rr.closes == 1 && rr.cubics == 4)
    val pill = probe(GPath().roundRect(0f, 0f, 100f, 40f, 999f))
    T.check("aşırı yarıçap yarım kenara kırpılır", near(pill.minY, 0f, 0.05f) && near(pill.maxY, 40f, 0.05f) && pill.allFinite)
    val degenerate = probe(GPath().roundRect(0f, 0f, 0f, 0f, 5f))
    T.check("sıfır boyutlu roundRect sonlu", degenerate.allFinite)

    // poly
    val tri = probe(GPath().poly(0f, 0f, 10f, 0f, 5f, 8f, closed = true))
    T.check("poly: 1 move, 2 line, kapalı", tri.moves == 1 && tri.lines == 2 && tri.closes == 1)
    T.check("poly tek sayı koordinat yok sayılır", probe(GPath().poly(1f, 2f, 3f)).moves == 1)

    // sürüm: her değişiklikte artar, reset de artırır; boş yol
    val g = GPath()
    val v0 = g.version
    g.moveTo(1f, 1f)
    val v1 = g.version
    g.lineTo(2f, 2f)
    T.check("sürüm artıyor", v1 > v0 && g.version > v1)
    g.reset()
    T.check("reset boşaltır ve sürümü artırır", g.isEmpty && g.version > v1 && g.size == 0)

    // büyüme: çok komut
    val big = GPath()
    for (i in 0 until 1000) big.lineTo(i.toFloat(), i.toFloat())
    T.check("1000 komuta büyür", big.size == 1000 && probe(big).lines == 1000)
}

fun testFills() {
    T.group("Fill")
    val l = Fill.linear(0f, 0f, 0f, 10f, 1, 2)
    T.check("iki duraklı doğrusal", l is Fill.Linear && l.colors.size == 2 && l.stops[0] == 0f && l.stops[1] == 1f)
    val l3 = Fill.linear(0f, 0f, 0f, 10f, 1, 2, 3, 0.4f)
    T.check("üç duraklı", (l3 as Fill.Linear).stops.size == 3 && near(l3.stops[1], 0.4f))
    val clamped = Fill.linear(0f, 0f, 0f, 10f, 1, 2, 3, 5f) as Fill.Linear
    T.check("orta durak 0..1 aralığına kırpılır", clamped.stops[1] < 1f && clamped.stops[1] > 0f)
    val r = Fill.radial(1f, 2f, 3f, 1, 2)
    T.check("radyal", r is Fill.Radial && r.r == 3f && r.cx == 1f)
    T.check("native başta boş", l.native == null)
}

fun testLongCache() {
    T.group("LongCache")
    val c = LongCache<String>(40)
    T.check("boşken null", c[5L] == null)
    c[5L] = "a"
    T.check("eklenen okunur", c[5L] == "a" && c.size == 1)
    c[5L] = "b"
    T.check("aynı anahtar değiştirir", c[5L] == "b" && c.size == 1)

    // rastgele işlemler, HashMap modeliyle karşılaştır (kapasite taşmadan)
    val rnd = Random(7)
    val model = HashMap<Long, String>()
    val big = LongCache<String>(400)   // en çok ~300 ayrı anahtar üretilir: hiç boşaltma olmaz
    var ok = true
    for (i in 0 until 5000) {
        val k = (rnd.nextInt(150) - 20).toLong() * (if (rnd.nextBoolean()) 1L else 1_000_003L)
        if (rnd.nextInt(3) == 0) { val v = "v$i"; big[k] = v; model[k] = v }
        else if (big[k] != model[k]) { ok = false; break }
    }
    T.check("rastgele işlemler HashMap ile aynı", ok)

    // dolunca boşaltır, sonrasında çalışmaya devam eder
    val small = LongCache<Int>(4)
    for (i in 0 until 4) small[i.toLong()] = i
    small[100L] = 100
    T.check("dolunca temizlenir, yeni değer durur", small[100L] == 100 && small.size == 1 && small[0L] == null)
    for (i in 0 until 100) small[(i * 977).toLong()] = i
    T.check("taşmadan sonra tutarlı", small.size <= 4 && small[(99 * 977).toLong()] == 99)

    // negatif ve uç anahtarlar
    val e = LongCache<String>(8)
    e[Long.MIN_VALUE] = "min"; e[Long.MAX_VALUE] = "max"; e[-1L] = "neg"; e[0L] = "zero"
    T.check("uç anahtarlar", e[Long.MIN_VALUE] == "min" && e[Long.MAX_VALUE] == "max" && e[-1L] == "neg" && e[0L] == "zero")

    // arama kutulama yapmaz. Yoğun CPU yükünde JIT/GC kaynaklı tek seferlik birkaç KB'lık sapma görülebilir;
    // gerçek bir kutulama her aramada ≥16 bayt (≈3 MB) ayırırdı, bu yüzden 5 denemenin en iyisi sayılır.
    val tmx = java.lang.management.ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
    val id = Thread.currentThread().id
    val warm = LongCache<String>(16); warm[3L] = "x"
    repeat(20000) { warm[3L]; warm[4L] }
    var used = Long.MAX_VALUE
    repeat(5) {
        val before = tmx.getThreadAllocatedBytes(id)
        repeat(100000) { warm[3L]; warm[4L] }
        used = minOf(used, tmx.getThreadAllocatedBytes(id) - before)
    }
    T.check("100 bin arama bellek ayırmaz", used < 2048, "$used bayt")
}

fun testTextFit() {
    T.group("TextFit")
    val m = FixedMetrics
    val size = 14f
    fun w(s: String, bold: Boolean = false) = m.textWidth(s, size, bold)

    T.check("sığan metin aynen döner", TextFit.ellipsize(m, "Merhaba", 500f, size, false) == "Merhaba")
    T.check("boş metin", TextFit.ellipsize(m, "", 10f, size, false) == "")
    val cut = TextFit.ellipsize(m, "Bu çok uzun bir sunucu açıklaması", 120f, size, false)
    T.check("uzun metin kısalır ve … ile biter", cut.endsWith("…") && cut.length < 34)
    T.check("kısaltılmış metin sığar", w(cut) <= 120f + 0.01f)
    T.check("çok dar alanda yalnızca …", TextFit.ellipsize(m, "abcdef", 1f, size, false) == "…")

    val rnd = Random(3)
    val alphabet = "abcçdefgğhıijklmnoöprsştuüvyz ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ0123456789"
    var allFit = true; var prefixOk = true; var idem = true
    for (i in 0 until 600) {
        val len = rnd.nextInt(60)
        val s = buildString { repeat(len) { append(alphabet[rnd.nextInt(alphabet.length)]) } }
        val maxW = 20f + rnd.nextInt(300)
        val bold = rnd.nextBoolean()
        val e = TextFit.ellipsize(m, s, maxW, size, bold)
        if (m.textWidth(e, size, bold) > maxW + 0.01f && e != "…") allFit = false
        if (e != s && !(e == "…" || s.startsWith(e.removeSuffix("…")))) prefixOk = false
        if (TextFit.ellipsize(m, e, maxW, size, bold) != e) idem = false
    }
    T.check("rastgele: sonuç her zaman sığar", allFit)
    T.check("rastgele: sonuç öneki korur", prefixOk)
    T.check("rastgele: tekrar kısaltma değiştirmez", idem)

    // wrap
    val lines = TextFit.wrap(m, "bir iki üç dört beş altı yedi sekiz dokuz on", 90f, size, false)
    T.check("wrap: çok satır", lines.size > 1)
    T.check("wrap: her satır sığar", lines.all { w(it) <= 90f + 0.01f })
    T.check("wrap: sözcük sırası korunur", lines.joinToString(" ") == "bir iki üç dört beş altı yedi sekiz dokuz on")
    T.check("wrap: \\n zorunlu satır sonu", TextFit.wrap(m, "a\nb", 500f, size, false) == listOf("a", "b"))
    T.check("wrap: boş paragraf boş satır", TextFit.wrap(m, "a\n\nb", 500f, size, false) == listOf("a", "", "b"))
    val long = TextFit.wrap(m, "kısa uzuncabirsözcükbirazdahauzun kısa", 80f, size, false)
    T.check("wrap: satıra sığmayan sözcük kaybolmaz, satırlara bölünür",
        long.none { it.endsWith("…") } && long.all { w(it) <= 80.01f } && long.size >= 3 &&
            long.joinToString("").replace(" ", "") == "kısauzuncabirsözcükbirazdahauzunkısa", long.toString())
    T.check("wrap: boş metin", TextFit.wrap(m, "", 80f, size, false) == listOf(""))
    T.check("wrap: çoklu boşluk tek sayılır", TextFit.wrap(m, "a    b", 500f, size, false) == listOf("a b"))

    var wrapOk = true
    for (i in 0 until 300) {
        val words = (0 until rnd.nextInt(14)).map { buildString { repeat(1 + rnd.nextInt(9)) { append(alphabet[rnd.nextInt(26)]) } } }
        val maxW = 60f + rnd.nextInt(200)
        val ls = TextFit.wrap(m, words.joinToString(" "), maxW, size, false)
        if (ls.any { m.textWidth(it, size, false) > maxW + 0.01f }) wrapOk = false
    }
    T.check("rastgele wrap: hiçbir satır taşmaz", wrapOk)
}

fun testIconsAndArt() {
    T.group("Simgeler")
    for (icon in Icon.values()) {
        val g = CountingGfx()
        Icons.draw(g, icon, 50f, 50f, 24f, 0xFF000000.toInt(), 2f, if (icon == Icon.STAR) 0xFFFFC21F.toInt() else 0)
        T.check("$icon çizilir", g.shapes > 0 && g.depth == 0 && !g.underflow && g.bad == 0)
        val p = probe(Icons.path(icon))
        T.check("$icon 24x24 kutusunda", p.allFinite && p.minX >= -0.5f && p.minY >= -0.5f && p.maxX <= 24.5f && p.maxY <= 24.5f, "${p.minX},${p.minY},${p.maxX},${p.maxY}")
    }
    T.check("her etiket için bir simge", Tag.values().all { Icons.forTags(setOf(it)) != Icon.GLOBE } && Icons.forTags(emptySet()) == Icon.GLOBE)
    T.check("simge önceliği: Aile > Reklam", Icons.forTags(setOf(Tag.FAMILY, Tag.ADS)) == Icon.HEART)
    T.check("simge yolu önbelleği aynı nesneyi verir", Icons.path(Icon.POWER) === Icons.path(Icon.POWER))

    T.group("AeroArt: tüm temalar ve uç değerler")
    val sizes = floatArrayOf(0f, 0.5f, 1f, 2f, 17f, 44f, 120f, 340f, 1000f)
    for (th in Themes.all) {
        for (glass in floatArrayOf(0f, 0.55f, 1f)) {
            val art = AeroArt(th, glass)
            val g = CountingGfx()
            art.sky(g, 360f, 780f)
            art.sky(g, 1f, 1f)
            art.sky(g, 800f, 1280f)
            art.bubble(g, 10f, 10f, 20f, 1f); art.bubble(g, 10f, 10f, 0f, 1f); art.bubble(g, 10f, 10f, 5f, 0f)
            for (w in sizes) for (h in sizes) {
                art.card(g, 0f, 0f, w, h, 22f)
                art.card(g, 3f, 4f, 3f + w, 4f + h, 22f, selected = 1f, press = 1f, strong = 1f, shadow = 0f)
                art.pill(g, 0f, 0f, w, h, 0.5f, 1f)
            }
            for (r in floatArrayOf(0.5f, 17f, 30f, 44f, 92f)) for (lv in floatArrayOf(0f, 0.01f, 0.4f, 0.66f, 1f)) {
                art.orb(g, 100f, 100f, r, lv, 12.3f, 1f, 0f, 0f)
                art.orb(g, 100f, 100f, r, lv, -3f, 0.5f, 1f, 1f)
            }
            for (on in floatArrayOf(0f, 0.5f, 1f)) art.switch(g, 0f, 0f, 52f, 30f, on, 1f)
            for (v in floatArrayOf(-1f, 0f, 0.5f, 1f, 3f)) art.slider(g, 16f, 20f, 300f, v, 1f)
            for (n in 1..4) for (pos in floatArrayOf(-1f, 0f, 1.5f, 9f)) art.segmented(g, 0f, 0f, 300f, 38f, n, pos)
            art.swatch(g, 30f, 30f, 17f, null, 1f)
            for (t2 in Themes.all) art.swatch(g, 30f, 30f, 17f, t2, 0.5f)
            for (lv in -1..9) art.bars(g, 0f, 20f, lv, lv % 2 == 0)
            art.iconDisc(g, 20f, 20f, 18f); art.badge(g, 20f, 20f, 7f)
            art.bar(g, 360f, 84f, 1f, 780f); art.bar(g, 360f, 84f, 0f, 780f); art.grabber(g, 100f, 10f)
            T.check("${th.id} cam=$glass: tüm parçalar çizildi", g.calls > 500 && g.bad == 0 && g.depth == 0 && !g.underflow, "bad=${g.bad} depth=${g.depth} calls=${g.calls}")
        }
    }

    // aynı boyut tekrar tekrar çizilince yeni nesne üretmez (önbellek çalışıyor)
    val art = AeroArt(Themes.aqua, 0.55f)
    val g = CountingGfx()
    repeat(300) { art.card(g, 0f, 0f, 320f, 68f, 22f); art.pill(g, 0f, 0f, 90f, 38f); art.orb(g, 0f, 0f, 92f, 0.5f, 1f, 1f, 0f, 0f) }
    val tmx = java.lang.management.ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
    val id = Thread.currentThread().id
    var perCall = Double.MAX_VALUE   // tek seferlik JIT/GC sapmasına karşı 5 denemenin en iyisi (gerçek ayırma her denemede görünür)
    repeat(5) {
        val before = tmx.getThreadAllocatedBytes(id)
        repeat(1000) { art.card(g, 0f, 0f, 320f, 68f, 22f, selected = 0.5f, press = 0.3f); art.pill(g, 0f, 0f, 90f, 38f); art.orb(g, 0f, 0f, 92f, 0.5f, 1f, 1f, 0f, 0f); art.switch(g, 0f, 0f, 52f, 30f, 0.5f, 0f) }
        perCall = minOf(perCall, (tmx.getThreadAllocatedBytes(id) - before) / 1000.0)
    }
    T.check("bileşenler kare başına bellek ayırmaz", perCall < 16.0, "%.1f bayt/döngü".format(perCall))
}

fun testBubbleField() {
    T.group("Kabarcık alanı")
    val f = BubbleField(5L)
    f.setCount(15)
    T.check("istenen sayıda", f.items.size == 15)
    f.setCount(4)
    T.check("azaltılabilir", f.items.size == 4)
    f.setCount(0)
    T.check("sıfıra inebilir", f.items.isEmpty())
    f.setCount(10)
    var ok = true
    for (i in 0 until 6000) {
        f.update(0.016f)
        for (b in f.items) {
            if (!b.x.isFinite() || !b.y.isFinite() || b.r < 1f || b.alpha !in 0f..1f || b.y < -0.2f || b.y > 1.5f || b.x !in 0f..1f) ok = false
        }
    }
    T.check("100 sn sonra hâlâ sınırlar içinde ve sonlu", ok)
    val y0 = f.items.map { it.y }
    f.update(0f)
    T.check("dt=0 hareket ettirmez", f.items.map { it.y } == y0)
    f.update(100f)
    T.check("çok büyük dt kırpılır", f.items.all { it.y.isFinite() && it.y > -0.2f })
    val a = BubbleField(9L).also { it.setCount(5) }
    val b2 = BubbleField(9L).also { it.setCount(5) }
    T.check("aynı tohum aynı dağılım", a.items.map { it.x } == b2.items.map { it.x })
}

fun runGfxTests() {
    testGPath()
    testFills()
    testLongCache()
    testTextFit()
    testIconsAndArt()
    testBubbleField()
}
