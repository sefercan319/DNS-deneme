package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

private fun newModel(s: AppSettings = Rig.base(), lat: Map<String, Latency> = emptyMap()): Pair<AppModel, FakeHost> {
    val h = FakeHost()
    return AppModel(h, s, lat) to h
}

fun testModelConnect() {
    T.group("Model: bağlan / kes")
    run {
        val (m, h) = newModel()
        m.tapOrb()
        T.check("küre: seçili sunucuya bağlanır", h.calls == listOf("connect:cloudflare"))
        T.check("hemen 'bağlanıyor' durumuna geçer", m.vpn.state == OrbState.CONNECTING && m.vpn.serverId == "cloudflare")
        T.check("seçim kaydedilir", h.saved?.lastServer == "cloudflare")
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 20))
        T.check("bağlıyken connectedId", m.connectedId() == "cloudflare")
        m.tapOrb()
        T.check("küre: bağlıyken keser", h.calls.last() == "disconnect")
        T.check("kesince bildirim", m.toast?.text == Strings.DISCONNECTED)
        m.onVpn(VpnUi(OrbState.OFF))
        T.check("kapalıyken connectedId boş", m.connectedId() == null)
    }
    run {
        val (m, h) = newModel(Rig.base().copy(lastServer = "quad9"))
        m.tapOrb()
        T.check("son seçilen sunucuya bağlanır", h.calls == listOf("connect:quad9"))
    }
    run {
        val (m, h) = newModel(Rig.base().copy(lastServer = null))
        m.tapOrb()
        T.check("seçim yoksa varsayılan (Cloudflare)", h.calls == listOf("connect:${Catalog.DEFAULT_ID}"))
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 20))
        m.tapServer("quad9")
        T.check("bağlıyken başka sunucu: kesintisiz geçiş çağrısı", h.calls == listOf("connect:quad9"))
        T.check("geçiş bildirimi", m.toast?.text == Strings.switched("Quad9"))
        T.check("durum bağlı kalır", m.vpn.state == OrbState.ON)
        T.check("seçim kaydedildi", m.settings.lastServer == "quad9")
        m.tapServer("quad9")
        T.check("zaten bağlı olana dokunmak bir şey yapmaz", h.calls.size == 1)
        m.onVpn(VpnUi(OrbState.ON, "quad9", h.now, 0, 0, 20))
        m.tapServer("quad9")
        T.check("sunucu değişince de aynısı", h.calls.size == 1)
    }
    run {
        val (m, h) = newModel()
        m.tapServer("yok-boyle-bir-sunucu")
        T.check("bilinmeyen sunucu yok sayılır", h.calls.isEmpty() && m.vpn.state == OrbState.OFF)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.CONNECTING, "cloudflare", h.now))
        T.check("bağlanıyorken küre keser", run { m.tapOrb(); h.calls.last() == "disconnect" })
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, "Neden"))
        m.tapOrb()
        T.check("hata durumunda küre yeniden dener", h.calls == listOf("connect:cloudflare"))
    }
}

fun testModelConsent() {
    T.group("Model: ilk açılış bilgilendirmesi")
    run {
        val (m, h) = newModel(Rig.base().copy(onboarded = false))
        m.tapOrb()
        T.check("kabul edilmeden bağlanmaz", h.calls.isEmpty() && m.consentOpen)
        T.check("durum kapalı kalır", m.vpn.state == OrbState.OFF)
        m.acceptConsent()
        T.check("kabulden sonra bağlanır", h.calls == listOf("connect:cloudflare") && !m.consentOpen)
        T.check("kabul kalıcı kaydedilir", h.saved?.onboarded == true && m.settings.onboarded)
    }
    run {
        val (m, h) = newModel(Rig.base().copy(onboarded = false))
        m.tapServer("quad9")
        m.acceptConsent()
        T.check("beklemedeki sunucu korunur", h.calls == listOf("connect:quad9"))
    }
    run {
        val (m, h) = newModel(Rig.base().copy(onboarded = false))
        m.tapOrb()
        m.dismissConsent()
        T.check("vazgeçilirse bağlanmaz", h.calls.isEmpty() && !m.consentOpen && !m.settings.onboarded)
        m.acceptConsent()
        T.check("beklemesiz kabul bağlanmaz ama kaydeder", h.calls.isEmpty() && m.settings.onboarded)
    }
    run {
        val (m, h) = newModel()
        m.tapOrb()
        T.check("kabul edilmişse bilgilendirme açılmaz", !m.consentOpen)
    }
}

fun testModelList() {
    T.group("Model: liste, favori, sıralama")
    run {
        val (m, h) = newModel(Rig.base().copy(favorites = setOf("quad9", "google")))
        val v0 = m.version
        m.setFilter(Filter.ALL)
        T.check("aynı süzgeç sürümü artırmaz", m.version == v0)
        m.setFilter(Filter.FAVORITES)
        T.check("favoriler süzgeci yalnızca favorileri gösterir", m.visibleServers().map { it.id }.toSet() == setOf("quad9", "google"))
        m.setFilter(Filter.ADS)
        T.check("etiket süzgeci", m.visibleServers().isNotEmpty() && m.visibleServers().all { Tag.ADS in it.tags })
        T.check("süzgeçte favoriler üstte", run { m.setFilter(Filter.ALL); m.visibleServers().take(2).map { it.id }.toSet() == setOf("quad9", "google") })
        for (f in Filter.values()) {
            m.setFilter(f)
            T.check("süzgeç ${f.name} boş değil ya da favori", m.visibleServers().isNotEmpty() || f == Filter.FAVORITES)
        }
        m.setFilter(Filter.ALL)
        m.toggleFavorite("cloudflare")
        T.check("favori eklenir ve kaydedilir", "cloudflare" in m.settings.favorites && h.saved?.favorites?.contains("cloudflare") == true)
        m.toggleFavorite("cloudflare")
        T.check("favori kaldırılır", "cloudflare" !in m.settings.favorites)
        val n = h.savedCount
        m.toggleFavorite("yok")
        T.check("bilinmeyen favori yok sayılır", h.savedCount == n)
        m.setFilter(Filter.FAVORITES)
        for (id in listOf("quad9", "google")) m.toggleFavorite(id)
        T.check("favori yokken liste boş", m.visibleServers().isEmpty())
    }
    run {
        val lat = mapOf(
            "cloudflare" to Latency(18, 0), "quad9" to Latency(41, 0), "google" to Latency(24, 0),
            "controld" to Latency(29, 0), "adguard" to Latency(33, 0), "verisign" to Latency(null, 0),
        )
        val (m, h) = newModel(Rig.base().copy(favorites = setOf("quad9", "cloudflare")), lat)
        m.toggleSort()
        val ids = m.visibleServers().map { it.id }
        T.check("hıza göre sıralama: favoriler önce, hızlıdan yavaşa", ids.take(2) == listOf("cloudflare", "quad9"))
        T.check("ardından ölçülmüşler hız sırasıyla", ids.subList(2, 5) == listOf("google", "controld", "adguard"))
        T.check("cevapsız sunucu en sonda", ids.last() == "verisign")
        T.check("tüm sunucular listede", ids.size == Catalog.all.size && ids.toSet().size == ids.size)
        T.check("sıralama kaydedilir", h.saved?.sortBySpeed == true)
        m.toggleSort()
        T.check("sıralama kapanınca katalog sırası", m.visibleServers().map { it.id }.drop(2).take(3) == Catalog.all.map { it.id }.filter { it != "quad9" && it != "cloudflare" }.take(3))
    }
    run {
        val (m, h) = newModel()
        val n = h.savedCount
        m.update { it }
        T.check("değişmeyen ayar kaydedilmez", h.savedCount == n)
        val v = m.version
        m.update { it.copy(glass = 0.9f) }
        T.check("değişen ayar kaydedilir ve sürüm artar", h.savedCount == n + 1 && m.version > v && m.settings.glass == 0.9f)
    }
}

fun testModelMeasure() {
    T.group("Model: hız ölçümü")
    run {
        val (m, h) = newModel()
        m.measureAll()
        T.check("tüm sunucular ölçülür", h.calls == listOf("measure:${Catalog.all.size}") && m.measuring)
        m.measureAll()
        T.check("ölçüm sürerken yenisi başlamaz", h.calls.size == 1)
        m.onLatency("cloudflare", 18)
        m.onLatency("google", 24)
        m.onLatency("quad9", null)
        m.onLatency("yok", 5)
        T.check("gecikmeler kaydedilir", m.latencies["cloudflare"]?.ms == 18 && m.latencies["quad9"]?.ms == null && m.latencies.containsKey("quad9") && !m.latencies.containsKey("yok"))
        T.check("gecikme metni", m.latencyText("cloudflare") == "18 ms" && m.latencyText("quad9") == "—" && m.latencyText("mullvad") == null)
        m.onMeasureDone()
        T.check("ölçüm bitince durum kapanır ve kaydedilir", !m.measuring && h.savedLatencies?.size == 3)
        T.check("en hızlı için eylemli bildirim", m.toast?.text == Strings.fastest("Cloudflare", 18) && m.toast?.action == Strings.CONNECT)
        m.toast?.onAction?.invoke()
        T.check("bildirim eylemi en hızlıya bağlanır", h.calls.last() == "connect:cloudflare")
        val c = h.calls.size
        m.onMeasureDone()
        T.check("ölçüm yokken bitiş çağrısı etkisiz", h.calls.size == c)
    }
    run {
        val (m, h) = newModel()
        m.measure(listOf("google"))
        m.onLatency("google", null)
        m.onMeasureDone()
        T.check("hiç yanıt yoksa bildirim", m.toast?.text == Strings.NO_REPLY && m.toast?.action == null)
        m.measure(emptyList())
        T.check("boş liste ölçülmez", !m.measuring)
    }
    run {
        val (m, h) = newModel()
        m.connectFastest()
        T.check("ölçüm yokken uyarı", m.toast?.text == Strings.MEASURE_FIRST && h.calls.isEmpty())
        m.onLatency("opendns", 70); m.onLatency("google", 20)
        m.connectFastest()
        T.check("en hızlıya bağlanır", h.calls == listOf("connect:google"))
    }
}

fun testModelStatus() {
    T.group("Model: durum metinleri ve geri bildirim")
    run {
        val (m, h) = newModel()
        T.check("kapalı: başlık/alt/ipucu", m.statusTitle() == "Bağlı değil" && m.statusSub() == "Cloudflare seçili" && m.statusHint() == "Bağlanmak için küreye dokun")
        m.onVpn(VpnUi(OrbState.CONNECTING, "quad9", h.now))
        T.check("bağlanıyor", m.statusTitle() == "Bağlanıyor…" && m.statusSub() == "Quad9")
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now - 754_000, 1342, 511, 23))
        T.check("bağlı: ad ve gecikme", m.statusTitle() == "Bağlı" && m.statusSub() == "Cloudflare · 23 ms")
        T.check("bağlı: süre, sorgu, önbellek", m.statusHint() == "12:34 · 1,3 bin sorgu · %38 önbellek", m.statusHint())
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 0))
        T.check("sorgu yokken yüzde 0 ve gecikme gizli", m.statusSub() == "Cloudflare" && m.statusHint().endsWith("%0 önbellek"))
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now + 5_000_000, 10, 99, 0))
        T.check("saat geriye giderse süre negatif olmaz", m.statusHint().startsWith("00:00"), m.statusHint())
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 10, 99, 0))
        T.check("önbellek yüzdesi 100'ü aşmaz", m.statusHint().contains("%100"), m.statusHint())
        m.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, "Başka bir VPN açık"))
        T.check("hata: neden gösterilir", m.statusTitle() == "Bağlanamadı" && m.statusSub() == "Başka bir VPN açık" && m.statusHint() == Strings.HINT_ERROR)
        m.onVpn(VpnUi(OrbState.ERROR))
        T.check("hata: varsayılan neden", m.statusSub() == Strings.ERR_DEFAULT)
        m.onVpn(VpnUi(OrbState.ON, "bilinmeyen", h.now, 0, 0, 0))
        T.check("bilinmeyen sunucu kimliği çökertmez", m.statusSub() == "Cloudflare")
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.CONNECTING, "cloudflare", h.now))
        T.check("bağlanırken titreşim yok", h.haptics == 0)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        T.check("bağlanınca güçlü titreşim", h.strongHaptics == 1)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 5))
        T.check("aynı durum tekrar titretmez", h.strongHaptics == 1)
        m.onVpn(VpnUi(OrbState.ERROR))
        T.check("hatada titreşim", h.strongHaptics == 2)
        m.onVpn(VpnUi(OrbState.OFF))
        T.check("kapanınca titreşim yok", h.strongHaptics == 2)
    }
    run {
        val (m, h) = newModel(Rig.base().copy(haptics = false))
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        T.check("titreşim kapalıysa titretmez", h.haptics == 0)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        val seq = m.toastSeq
        m.onVpn(VpnUi(OrbState.ON, "quad9", h.now, onBackup = true))
        T.check("yedek sunucuya geçince bildirim", m.toast?.text == Strings.BACKUP && m.toastSeq == seq + 1)
        m.onVpn(VpnUi(OrbState.ON, "quad9", h.now, onBackup = true))
        T.check("bildirim yalnızca geçişte", m.toastSeq == seq + 1)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        val seq = m.toastSeq
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, error = "Quad9 yanıt vermedi"))
        T.check("bağlıyken gelen hata bir kez bildirilir", m.toast?.text == "Quad9 yanıt vermedi" && m.toastSeq == seq + 1)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, error = "Quad9 yanıt vermedi"))
        T.check("aynı hata tekrar bildirilmez", m.toastSeq == seq + 1)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, error = "Quad9 yanıt vermedi"))
        T.check("hata temizlenip yine gelirse yeniden bildirilir", m.toastSeq == seq + 2)
        T.check("bağlı durum bozulmadı", m.vpn.state == OrbState.ON && m.statusTitle() == Strings.ON)
        m.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, "Başka bir VPN açık"))
        T.check("hata durumunda ayrıca bildirim açılmaz (neden küre altında yazar)", m.toastSeq == seq + 2)
    }
    run {
        val (m, h) = newModel()
        val v = m.version
        m.replaceSettings(m.settings)
        T.check("aynı ayarlar sürümü artırmaz", m.version == v)
        val n = h.savedCount
        m.replaceSettings(m.settings.copy(totalQueries = 9))
        T.check("depodan gelen ayar kaydedilmez ama görünür", m.version > v && h.savedCount == n && m.settings.totalQueries == 9L)
        T.check("önbellek yüzdesi: sorgu yokken 0", newModel(Rig.base().copy(totalQueries = 0, totalHits = 5)).first.hitPercentTotal() == 0)
        T.check("önbellek yüzdesi", newModel(Rig.base()).first.hitPercentTotal() == 35)
        T.check("önbellek yüzdesi 100'ü aşmaz", newModel(Rig.base().copy(totalQueries = 5, totalHits = 50)).first.hitPercentTotal() == 100)
    }
    run {
        val (m, h) = newModel()
        m.copy("1.1.1.1")
        T.check("kopyalama panoya yazar ve bildirir", h.clipboard == "1.1.1.1" && m.toast?.text == Strings.COPIED)
    }
}

fun runModelTests() {
    testModelConnect()
    testModelConsent()
    testModelList()
    testModelMeasure()
    testModelStatus()
}
